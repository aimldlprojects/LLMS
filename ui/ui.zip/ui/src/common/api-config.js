// const BASIC_GATEWAY = "http://localhost:8000/api/v1/";
const BASIC_GATEWAY = " http://127.0.0.1:8000/";
// upload

export const uploadEndpoint = () => (`${BASIC_GATEWAY}upload-xml`)
// snomed-to-meddra
export const extractionEndpoint = (caseNarrative) => (`${BASIC_GATEWAY}snomed-to-meddra?case_narative='${caseNarrative}'`)
export const analyzedDocsEndPoint = () => (`${BASIC_GATEWAY}analysed_docs`)
export const viewNarrativeEndpoint = () => (`${BASIC_GATEWAY}view_narrative`)
export const getXMLContentEndpoint = () => (`${BASIC_GATEWAY}xml`)
export const viewOutEndpoint = () => (`${BASIC_GATEWAY}output`)
export const submittedComparisionEndpoint = () => (`${BASIC_GATEWAY}submitted_comparision`)
