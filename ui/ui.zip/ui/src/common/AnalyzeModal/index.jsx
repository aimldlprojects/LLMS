import React, { useState } from "react";
import { PropTypes } from "prop-types";
import { useNavigate } from "react-router-dom";
import Xcircle from './../../assets/XCircle.svg'
import styled from "styled-components";
import '../model/model.css';

export const ModalContainer = styled.div`
  width: 100%;
  height: 100%;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  margin: auto;
  position: fixed;
  background-color: rgba(0, 0, 0, 0.2);
  transition: all 0.4s cubic-bezier(0.25, 0.8, 0.25, 1);
  z-index: 9999;
  outline: none;

`;

export const ModalWrapper = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  height: auto;
`;

export const StyledModalContainer = styled.div`
  display: flex;
  flex-direction: column;
  height: 300px;
  overflow-y: auto;
  width: ${(props) => props.popupWidth};
  background-color: ${(props) =>
    props.backgroundColor ? props.backgroundColor : "#1e2d3d"};
  border: 1px solid
    ${(props) => (props.borderColor ? props.borderColor : "#54A03D")};
  padding: ${(props) => props.popupPadding};
  margin-top: 200px;
  border-radius: 4px;
`;

export const ModalContent = styled.div`
  display: flex;
  flex-direction: column;
  padding: 20px;
  color: ${(props) => (props.color ? props.color : "#54A03D")};
  & div:first-child {
    font-weight: bold;
    font-size: 18px;
    line-height: 24px;
  }
  & div:last-child {
    font-size: 14px;
    line-height: 21px;
    margin-top: 0px;

    .btn-primary {
      font-family: "Poppins", sans-serif;
      text-shadow: 0px 0px 0px rgb(0 0 0 / 0%);
      border-color: rgba(0, 0, 0, 0);
      // background-color: #003152;
      background-color: #1e2d3d;
      border-radius: 4px;
      font-style: normal;
      line-height: 20px;
      font-weight: 600;
      padding: 12px 20px;
      color: rgb(255, 255, 255);
      font-size: 14px;
      width: auto;
    }
    .btn-secondary {
      border: 1px solid white;
      color: white;
      font-weight: 600;
      font-family: "Poppins";
      font-style: normal;
      box-sizing: border-box;
      border-radius: 4px;
      font-size: 14px;
      line-height: 32px;
      align-items: center;
      margin-left: 10px;
      background: #1e2d3d;
      text-shadow: 1px 1px 1px rgba(0, 0, 0, 0%);
      width: auto;
    }
  }
`;
export const ModalItem = styled.div``;

export const ModalTitle = styled.div`
  padding-top: 5px;
  color: #000;
`;

export const ModalMessage = styled.div`
  padding: 10px 50px;
  color: ${(props) => (props.color ? props.color : "#54A03D")};
`;

export const ModalButtons = styled.div`
  padding: 5px;
  & button {
    float: right;
    margin-left: 10px;
    cursor: pointer;
    position: relative;
  }
`;

const Modal = ({ openModal, type, close, popupPadding, popupWidth }) => {
  const [llm, setLLM] = useState(true)
  const [aws, setAWS] = useState(false)
  const [selectedText, setSelectedText] = useState("singleFile")
  const navigate = useNavigate();


  if (openModal === false) {
    return "";
  }

  let border_color = "#54A03D";
  let background_color = "#E3FCDC";
  let color = "#54A03D";
  switch (type) {
    case "theme":
      border_color = "#FFFFFF";
      background_color = "#FFFFFF";
      color = "#05322B";
      break;
    case "warning":
      border_color = "#96722E";
      background_color = "#FFF4DE";
      color = "#96722E";
      break;
    case "error":
      border_color = "#AB332F";
      background_color = "#FFF2E5";
      color = "#AB332F";
      break;
    case "info":
      border_color = "#4E82AD";
      background_color = "#24374a";
      color = "#4E82AD";
      break;

    default:
      break;
  }

  const selectLLM = (text) => {
    if (llm) {
      setSelectedText("")
      setLLM(false);
    } else {
      setSelectedText(text)
      setLLM(true);
      setAWS(false);
    }
  };

  const selectAWS = (text) => {
    if (aws) {
      setAWS(false);
      setSelectedText("")
    } else {
      setAWS(true);
      setSelectedText(text)
      setLLM(false);
    }
  };

  const analyze = () => {
    console.log(selectedText)
    if (selectedText === "singleFile") {
        navigate('/upload')
    } else if(selectedText === "urlPath") {
        navigate('/documentAnalyze')
    }
  }


  return (
    <ModalContainer>
      <ModalWrapper>
        <StyledModalContainer
          backgroundColor={"white"}
          borderColor={"white"}
          popupWidth={popupWidth}
          popupPadding={popupPadding}
        >
          <ModalContent color="#05322B">
            <div className="modal-container">
              <ModalTitle>Select Analyze Method</ModalTitle>
            </div>
            <hr></hr>
            <div>Please select the method</div>
            <div className="modal-container-1">
              <div className="radio-container-1" style={{ border: llm? "1px solid rgba(57, 67, 86, 1)": "1px solid rgba(57, 67, 86, 1)", backgroundColor: llm ?"rgba(214, 219, 227, 1)": null }}>
                <input
                  type="radio"
                  id="llmCheckbox"
                  className="rounded-checkbox ml-1"
                  checked={llm}
                  onClick={() => selectLLM("singleFile")}
                />
                <div htmlFor="llmCheckbox" className="singlefile" style={{color: llm ? "rgba(57, 67, 86, 1)" : "rgba(136, 136, 136, 1)"}}>&nbsp;Single File Processing</div>
              </div>
              <div className="radio-container" style={{ border: aws? "1px solid rgba(57, 67, 86, 1)": "1px solid rgba(57, 67, 86, 1)", backgroundColor: aws ?"rgba(214, 219, 227, 1)": null }}>
                <input
                  type="radio"
                  id="awsCheckbox"
                  className="rounded-checkbox ml-1"
                  checked={aws}
                  onClick={() => selectAWS("urlPath")}
                />
                <div htmlFor="awsCheckbox" className="singlefile" style={{color: aws ? "rgba(57, 67, 86, 1)" : "rgba(136, 136, 136, 1)"}}>&nbsp;Multi-File Processing</div>
              </div>
            </div>
            <button className="modal-button-confirm" onClick={() => analyze(selectedText)}>
              Confirm Selection
            </button>
          </ModalContent>
        </StyledModalContainer>
      </ModalWrapper>
    </ModalContainer>
  );
};

export default Modal;

Modal.propTypes = {
  title: PropTypes.string,
  message: PropTypes.string,
  type: PropTypes.string,
  buttons: PropTypes.arrayOf(
    PropTypes.shape({
      label: PropTypes.string,
      onClick: PropTypes.func,
      className: PropTypes.string,
    })
  ),
  status: PropTypes.string,
};