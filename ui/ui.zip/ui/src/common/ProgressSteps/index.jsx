import React from 'react';
import successIcon from '../../assets/Frame 74.svg';
import './ProgressSteps.css';

const ProgressSteps = (props) => {
    return (
        <div className="progress-steps-container" style={{width: props.width, marginTop: props.marginTop, marginBottom: props.marginBottom ? props.marginBottom : "40px" }}>
            <div className="step" onClick={() => props.onNavigate ? props.onNavigate() : null} style={{cursor: props.onNavigate ? "pointer" : ""}}>
                {
                    props.successStatus
                        ? <img src={successIcon} alt="successIcon" className='success-styles'/>
                        : <div className="step-circle steps-font" style={{ border: `2px solid ${props.uploadColor}`, color: props.uploadColor }}>01</div>
                }
                <div className="step-text progress-text" style={{ color: props.uploadColor }}>Upload Documents</div>
            </div>
            <div className="step-divider" style={{width: props.dividerWidth ? props.dividerWidth : "30px"}}></div>
            <div className="step" onClick={() => props.analyzeOnclick ? props.analyzeOnclick(): null} style={{cursor: props.analyzeOnclick ? "pointer" : ""}}>
                {
                     props.successAnalyzeStatus
                     ? <img src={successIcon} alt="successIcon" className='success-styles'/>
                     : <div className="step-circle steps-font" style={{ border: `2px solid ${props.analyzeColor}`, color: props.analyzeColor }}>02</div>
                }
                <div className="step-text progress-text" style={{ color: props.analyzeColor }}>Translate</div>
            </div>
            <div className="step-divider" style={{width: props.dividerWidth ? props.dividerWidth : "30px"}}></div>
            <div className="step" onClick={() => props.entityOnclick ? props.entityOnclick(): null} style={{cursor: props.entityOnclick ? "pointer" : ""}}>
            {
                     props.entityStatus
                     ? <img src={successIcon} alt="successIcon" className='success-styles'/>
                     : <div className="step-circle steps-font" style={{ border: `2px solid ${props.viewColor}`, color: props.viewColor }}>03</div>
                    }
                
                <div className="step-text progress-text" style={{ color: props.viewColor }}>Entity Extraction</div>
            </div>
            <div className="step-divider" style={{width: props.dividerWidth ? props.dividerWidth : "30px"}}></div>
            <div className="step" onClick={() => props.outputOnclick ? props.outputOnclick(): null} style={{cursor: props.outputOnclick ? "pointer" : ""}}>
            {
                     props.codeStatus
                     ? <img src={successIcon} alt="successIcon" className='success-styles'/>
                     :  <div className="step-circle steps-font" style={{ border: `2px solid ${props.entityColor}`, color: props.entityColor }}>04</div>
            }
               
                <div className="step-text progress-text" style={{ color: props.entityColor }}>Entity Coding</div>
            </div>
            <div className="step-divider" style={{width: props.dividerWidth ? props.dividerWidth : "30px"}}></div>
            <div className="step" onClick={() => props.codingOnclick ? props.codingOnclick(): null} style={{cursor: props.codingOnclick ? "pointer" : ""}}>
            {
                     props.outputStatus
                     ? <img src={successIcon} alt="successIcon" className='success-styles'/>
                     :<div className="step-circle steps-font" style={{ border: `2px solid ${props.outputColor}`, color: props.outputColor }}>05</div>
            }
                <div className="step-text progress-text" style={{ color: props.outputColor }}>Narrative Generation</div>
            </div>
        </div>
    )
}

export default ProgressSteps;
