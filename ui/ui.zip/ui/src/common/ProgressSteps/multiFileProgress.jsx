import React from 'react';
import successIcon from '../../assets/Frame 74.svg';
import './ProgressSteps.css';

const ProgressSteps = (props) => {
    return (

        <div className="progress-steps-container" style={{ width: props.width, marginTop: props.marginTop, marginBottom: props.marginBottom ? props.marginBottom : "40px" }}>
            <div className="step" onClick={() => props.onNavigate ? props.onNavigate() : null} style={{ cursor: props.onNavigate ? "pointer" : "" }}>
                {
                    props.successStatus
                        ? <img src={successIcon} alt="successIcon" className='success-styles' />
                        : <div className="step-circle steps-font" style={{ border: `2px solid ${props.uploadColor}`, color: props.uploadColor }}>01</div>
                }
                <div className="step-text progress-text ml-1" style={{ color: props.uploadColor }}>{props.progressStep1}</div>
            </div>
            <div className="step-divider" style={{width: props.dividerWidth ? props.dividerWidth : "150px"}}></div>
            <div className="step" onClick={() => props.analyzeOnclick ? props.analyzeOnclick() : null} style={{ cursor: props.analyzeOnclick ? "pointer" : "" }}>
                {
                    props.successAnalyzeStatus
                        ? <img src={successIcon} alt="successIcon" className='success-styles' />
                        : <div className="step-circle steps-font" style={{ border: `2px solid ${props.analyzeColor}`, color: props.analyzeColor }}>02</div>
                }
                <div className="step-text progress-text ml-1" style={{ color: props.analyzeColor }}>{props.progressStep2}</div>
            </div>
            <div className="step-divider" style={{width: props.dividerWidth ? props.dividerWidth : "150px"}}></div>
            <div className="step" onClick={() => props.entityOnclick ? props.entityOnclick() : null} style={{ cursor: props.entityOnclick ? "pointer" : "" }}>
                {
                    props.entityStatus
                        ? <img src={successIcon} alt="successIcon" className='success-styles' />
                        : <div className="step-circle steps-font" style={{ border: `2px solid ${props.viewColor}`, color: props.viewColor }}>03</div>
                }

                <div className="step-text progress-text ml-1" style={{ color: props.viewColor }}>{props.progressStep3}</div>
            </div>
            {
                props.progressStep4 ?
                    <>
                        <div className="step-divider" style={{width: props.dividerWidth ? props.dividerWidth : "150px"}}></div>
                        <div className="step" onClick={() => props.codingOnclick ? props.codingOnclick() : null} style={{ cursor: props.codingOnclick ? "pointer" : "" }}>
                            {
                                props.codingStatus
                                    ? <img src={successIcon} alt="successIcon" className='success-styles' />
                                    : <div className="step-circle steps-font" style={{ border: `2px solid ${props.entityColor}`, color: props.entityColor }}>04</div>
                            }

                            <div className="step-text progress-text ml-1" style={{ color: props.entityColor }}>Entity Coding</div>
                        </div>
                    </>
                    : null
            }
            {/* <div className="step-divider"></div> */}
            {/* <div className="step">
            {
                     props.outputStatus
                     ? <img src={successIcon} alt="successIcon" className='success-styles'/>
                     :<div className="step-circle steps-font" style={{ border: `2px solid ${props.outputColor}`, color: props.outputColor }}>05</div>
            }
                <div className="step-text progress-text" style={{ color: props.outputColor }}>View Output</div>
            </div> */}
        </div>
    )
}

export default ProgressSteps;
