import React from 'react';
import Navbar from '../../components/Navbar';
import { useNavigate } from 'react-router-dom';
import XMLViewer from 'react-xml-viewer';
import ProgressSteps from '../../common/ProgressSteps';
import backArrow from '../../assets/backarrow.svg';
import ChartDonut from "../../assets/ChartDonut.svg";
import XMLIcon from "../../assets/XML_icon.svg";
import Eye_blue from "../../assets/Eye_blue.svg";
import './narrativeInput.css';

const NarrativeInput = () => {
    const navigate = useNavigate();

    const uploadNavigate = () => {
        navigate('/upload')
    }
    const translateOnclick = () => {
        navigate('/translate')
    }
    const entityOnclick = () => {
        navigate('/documentAnalyzeN')
    }
    const onGenerateClick = () => {
        navigate('/narrativeCompare')
    }

    const goToSnomed = () => {
        navigate('/analyze')
    }

    return (
        <div className='narrative-container'>
            <Navbar />
            <div className='d-flex flex-column col-12 pl-0 pr-0 '>
                <div className="d-flex narrative-row align-items-center mt-2 pl-3">
                    <img src={backArrow} alt="img" />
                    <div className='ml-3'>Translate</div>
                </div>
                <div className='d-flex narrative-row m-3'>
                    <div className="first-half" style={{ border: "1px solid lightgrey", borderRadius: "4px" }}>
                        {localStorage.getItem("fileName") != "" ?
                            <>
                                <div style={{ marginTop: "10px" }}>
                                    <div style={{ border: "1px solid lightgrey", borderRadius: "8px", padding: "12px" }}>
                                        <div style={{ textAlign: "center" }}>
                                            <img src={XMLIcon} alt="User Icon" height="130px" />
                                        </div>
                                        <p style={{ textAlign: "center", wordWrap: "break-word" }}>{localStorage.getItem("fileName")}</p>
                                        <hr></hr>
                                        <p style={{ textAlign: "center", display: "flex", justifyContent: "center", alignItems: "center", color: "#3368CE", fontSize: "15px", color: "#003152", cursor: "pointer", fontWeight: 600 }} ><span style={{ marginRight: "10px" }}>
                                            <img src={Eye_blue} alt="User Icon" height="25px" width="25px" /></span>View Narrative</p>
                                    </div>
                                </div>
                                <div style={{ display: "flex", flexDirection: "column", marginTop: "10px" }}>
                                    <button className='active-button' style={{ marginBottom: "10px", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", cursor: "pointer" }}
                                    onClick={onGenerateClick}
                                    >
                                        {/* <img src={ChartDonut} alt="User Icon" /> */}
                                        <span style={{ marginLeft: "8px" }} >Generate Narrative</span>
                                    </button>
                                    <button className='border-button' style={{ cursor: "pointer" }}>XML Viewer</button>
                                </div>
                            </> : <></>}
                    </div>
                    <div className='narrative-part2 m-2'>
                        <div>
                        <ProgressSteps marginBottom="20px" 
                        uploadColor="rgba(41, 188, 118, 1)" 
                        outputColor="rgba(51, 104, 206, 1)" 
                        entityColor="rgba(41, 188, 118, 1)" 
                        analyzeColor="rgba(41, 188, 118, 1)" 
                        viewColor="rgba(41, 188, 118, 1)" 
                        successStatus={true} analyzeOnclick={translateOnclick} entityOnclick={entityOnclick} onNavigate={uploadNavigate} 

                        outputOnclick ={goToSnomed}
                        cursor={true} successAnalyzeStatus={true} entityStatus={true} codeStatus ={true} />
                        </div>
                        <div className='mt-3 bg-white' style={{ border: "1px solid rgba(0, 0, 0, 0.1)" }}>
                            <div className='p-2'>Input</div>
                            <hr className='w-100'></hr>
                            <div className='p-2'>
                                <XMLViewer
                                    xml={JSON.parse(localStorage.getItem("xmlContent"))}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
export default NarrativeInput;