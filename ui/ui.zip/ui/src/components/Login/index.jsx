import React, { useState } from 'react';
import report from '../../assets/Report-cuate 1.svg';
import logo from '../../assets/Logo_3-removebg-preview 1.svg';
import google from '../../assets/flat-color-icons_google.svg';
import microsoft from '../../assets/logos_microsoft-icon.svg';
import eyeIcon from '../../assets/eye-password.svg';
import apple from '../../assets/teenyicons_apple-solid.svg';
import { useAuth } from '../AuthContext';
import './Login.css';
import { useNavigate } from "react-router-dom";

const Login = () => {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);

    const list = [
        {
            icon: google,
            name: "Google"
        },
        {
            icon: microsoft,
            name: "Microsoft"
        },
        {
            icon: apple,
            name: "Apple"
        }
    ]

    const goToUpload = () => {
        // history.push('/upload')
        // navigate('/upload');

    }

    const getEmail = (event) => {
        if(event){
            setEmail(event.target.value)
        } 
    }
    const getPassword = (event) => {
        if(event){
            setPassword(event.target.value)
        } 
    }

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };
    const handleLogin = () => {
        login(email, password, navigate);
        // if(email === "pdepa@randomtrees.com"&& password === "Random@123"){
        //     toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
        //     navigate('/upload');
        // } else if(email === "lteja@randomtrees.com"&& password === "Random@123"){
        //     toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
        //     navigate('/upload');
        // } else if(email === "syam.ede@randomtrees.com"&& password === "Random@123"){
        //     toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
        //     navigate('/upload');
        // } else {
        //     toast.warning("Please provide valid Email & Password", { position: toast.POSITION.TOP_CENTER });
        // }
    }
    return (
        <div className="login-page-container">
            <div className="login-text-center">
                <div><img src={report} className='login-img' alt="img" /></div>
                <div className='login-box'>
                    <div className='login-column'>
                        <img src={logo} alt="logo" className='login-logo' />
                        <div className='login-head'>ICSR Extraction Sandbox</div>
                    </div>
                    <div className='login-text-1'>Login....</div>
                    <div className='login-flex-col login-mt-15'>
                        <div className='login-email'>Email Address</div>
                        <input type="text" className='login-input-email login-mt-1' placeholder='Ex abc@email.com' onChange={(event)=> getEmail(event)} value={email}/>
                    </div>
                    <div className='login-flex-col login-mt-15'>
                        <div className='login-email'>Password</div>
                        <div className='login-position-relative'>
                        <input type={showPassword? "text": "password"} className='login-input-email login-mt-1' placeholder='**********' onChange={(event) => getPassword(event)} value={password}/>
                        <img src={eyeIcon} alt="password" className='login-password-eyeIcon'  onClick={togglePasswordVisibility}/>
                        </div>
                    </div>
                    <div className='login-row flex-space-between login-mt-15'>
                        <div className='login-row'>
                            <input type="checkbox" />
                            <div className='login-email'>&nbsp;Remember me</div>
                        </div>
                        <div >
                            Forgot Password
                        </div>
                    </div>
                    <button className='login-button login-mt-15' onClick={() => handleLogin()}>
                        Login
                    </button>
                    <div className='login-dashed-line-container'>
                        <div className='login-dashed-line'></div>
                        <div className='login-text-2'>&nbsp;&nbsp;or&nbsp;&nbsp;</div>
                        <div className='login-dashed-line-1'></div>
                    </div>
                    <div className="login-row flex-space-between login-mt-5">
                        {
                            list.map((item) => (
                                <div className="login-row list-view">
                                    <img src={item.icon} alt="icons"/>
                                    <div>&nbsp;&nbsp;{item.name}</div>
                                </div>
                            ))
                        }
                    </div>
                </div>
            </div>
            <div className="top-row">
            </div>
            <div className="bottom-row">
            </div>
        </div>
    );
};

export default Login;
