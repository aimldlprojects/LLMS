import React, { useState, useEffect } from 'react';
import axios from "axios";
import "./XMLLoader.css";
import { toast } from 'react-toastify';
import ModalPopUpTable from '../../common/model';
import Navbar from '../Navbar';
import pdfIcon from "../../assets/pdfIcon.svg";
// import LoadingOverlay from 'react-loading-overlay';
import XMLIcon from "../../assets/XML_icon.svg";
import DataTable from "react-data-table-component";
import jsonResponse from "./jsonResponse.json";
import Eye_blue from "../../assets/Eye_blue.svg";
import empty from "../../assets/empty.svg";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';
import ChartDonut from "../../assets/ChartDonut.svg";
import downloadSimple from "../../assets/DownloadSimple.svg";
import funnelSimple from "../../assets/FunnelSimple.svg";
import funnelSimpleWhite from "../../assets/FunnelSimpleWhite.svg";
import XMLViewer from 'react-xml-viewer';
import refreshIcon from "../../assets/Refresh.svg";
import Select, { components } from "react-select";
import { default as ReactSelect } from "react-select";
import { useNavigate } from 'react-router-dom';
import ProgressSteps from '../../common/ProgressSteps';
import { extractionEndpoint } from '../../common/api-config';


function Translate() {
    console.log("ghjjhsbgj", JSON.parse(localStorage.getItem("xmlContent")))
    const staticResponse = jsonResponse.jsonResponse
    const navigate = useNavigate()
    const [xmlContent, setXMLContent] = useState('');
    const [fileName, setFileName] = useState('');
    const [open, setOpen] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [dropdownSelectedValue, setDropdownSelectedValue] = useState("")
    const [filteredData, setFilteredData] = useState([])
    const [dropdownStatus, setDropdownStatus] = useState(false)
    const [responseData, setResponseData] = useState([])
    const [APIResponse, setAPIResponse] = useState([])
    const [isActive, setActive] = useState(false)
    const envOptions = [
        { value: 'noMatched', label: 'Mapped' },
        { value: 'matched', label: 'Un mapped' },

    ]
    const llmOptions = [
        { value: 'noMatched', label: 'LLM' },
        { value: 'matched', label: 'AWS COMPREHEND MEDICAL' },

    ]

    const goToEntity = () => {
        navigate("/documentAnalyzeN")
    }
    const goToSnomed = () => {
        navigate("/analyze")
    }
    const goToNarrative = () => {
        navigate("/narrativeInput")
    }


    useEffect(() => {
        const xmlFileContent = JSON.parse(localStorage.getItem("xmlContent"))

        setXMLContent(xmlFileContent)
    }, [xmlContent])
    const Option = (props) => {
        return (
            <div>
                <components.Option {...props}>
                    <input
                        type="checkbox"
                        checked={props.isSelected}
                        onChange={() => null}
                    />{" "}
                    <label>{props.label}</label>
                </components.Option>
            </div>
        );
    };


    const customStylesFiltered = {
        option: (provided, state) => ({
            ...provided,
            // borderBottom: '1px dotted pink',
            color: state.isSelected ? '#003152' : '#003152',
            width: 200,
        }),
        container: provided => ({
            ...provided,
            width: 200,
        }),
        control: () => ({
            border: 'none',
            display: 'none',
            width: 0,
        }),
    };

    const handleFileUpload = (event) => {
        const file = event.target.files[0];

        console.log("file", file)
        setFileName(file.name)
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                setXMLContent(e.target.result);
            };
            reader.readAsText(file);
        }
    };


    const customStyles = {
        // rows: {
        //     style: {
        //         minHeight: '72px', // override the row height

        //         color:"yellow"
        //     },
        // },

        rows: {

            style: {
                border: 'none',
                ':nth-of-type(even)': {
                    backgroundColor: "#F1F7FF"
                },
                fontFamily: "Poppins !important",

                borderRadius: 8,
                marginTop: 8
            }
        },

        headCells: {
            style: {
                backgroundColor: "#394356",
                color: "#fff",
                fontFamily: "Poppins !important",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 600
            },

        },
        cells: {
            style: {
                color: "#000000",
                fontFamily: "Poppins",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 400
            },

        },
    };

    const colourStyles = {
        control: (provided, state) => ({
            ...provided,
            border: state.isFocused ? "1px solid #555555" : "1px solid #555555",
            backgroundColor: '#555555', // Replace with your desired background color
            "&:hover": {
                border: "1px solid #555555",
                // boxShadow: "0px 0px 6px #ff8b67"
            }
        }),
        option: (styles, { data, isDisabled, isFocused, isSelected }) => {
            return {
                ...styles,
                backgroundColor: "#555555",
                border: "0px solid #555555",
                color: '#FFF',
                cursor: 'default',
                fontSize: "14px",
            };
        },
        singleValue: (styles, { data }) => ({
            ...styles,
            color: "#FFF",
            fontSize: "14px",
        }),
        placeholder: (styles, { data }) => ({
            ...styles,
            color: "#FFF",
            fontSize: "14px",
        }),
        menu: (styles) => ({
            ...styles,
            marginTop: 0,
            marginBottom: 0,
            borderRadius: 0,
            boxShadow: "none",
            border: "1px solid #1E2D3D",
            backgroundColor: "#555555", // Set the background color of the menu

            fontSize: "14px",
        }),
        menuList: (styles) => ({
            ...styles,
            padding: 0,
            borderRadius: 0,
            borderTop: "none",
            borderBottom: "none",
            fontSize: "14px",
        }),
    }




    const getFeatures = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Text)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getType = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Type)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getCategory = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Category)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getSnomed_Code = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Snomed_Code)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getMedDRA_Code = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.MedDRA_Code)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getpt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.pt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const gethlt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.hlt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const gethlgt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.hlgt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getsoc_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.soc_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getsoc_abbrev = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.soc_abbrev)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }


    let outputText = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Text'] !== item['Text']);
        return [...filtered, item];
    }, []);

    const textOptions = outputText.map((item) => {
        return (
            { value: `${item.Text}`, label: `${item.Text}` }
        );
    });

    let outputType = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Type'] !== item['Type']);
        return [...filtered, item];
    }, []);

    const typeOptions = outputType.map((item) => {
        return (
            { value: `${item.Type}`, label: `${item.Type}` }
        );
    });

    let outputCategory = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Category'] !== item['Category']);
        return [...filtered, item];
    }, []);

    const categoryOptions = outputCategory.map((item) => {
        return (
            { value: `${item.Category}`, label: `${item.Category}` }
        );
    });

    let outputSnomed_Code = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Snomed_Code'] !== item['Snomed_Code']);
        return [...filtered, item];
    }, []);

    const Snomed_CodeOptions = outputType.map((item) => {
        return (
            { value: `${item.Snomed_Code}`, label: `${item.Snomed_Code}` }
        );
    });

    let outputMedDRA_Code = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['MedDRA_Code'] !== item['MedDRA_Code']);
        return [...filtered, item];
    }, []);

    const MedDRA_CodeOptions = outputMedDRA_Code.map((item) => {
        return (
            { value: `${item.MedDRA_Code}`, label: `${item.MedDRA_Code}` }
        );
    });

    let outputpt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['pt_name'] !== item['pt_name']);
        return [...filtered, item];
    }, []);

    const pt_nameOptions = outputpt_name.map((item) => {
        return (
            { value: `${item.pt_name}`, label: `${item.pt_name}` }
        );
    });

    let outputhlt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['hlt_name'] !== item['hlt_name']);
        return [...filtered, item];
    }, []);

    const hlt_nameOptions = outputhlt_name.map((item) => {
        return (
            { value: `${item.hlt_name}`, label: `${item.hlt_name}` }
        );
    });

    let outputhlgt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['hlgt_name'] !== item['hlgt_name']);
        return [...filtered, item];
    }, []);

    const hlgt_nameOptions = outputhlgt_name.map((item) => {
        return (
            { value: `${item.hlgt_name}`, label: `${item.hlgt_name}` }
        );
    });

    let outputsoc_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['soc_name'] !== item['soc_name']);
        return [...filtered, item];
    }, []);

    const soc_nameOptions = outputsoc_name.map((item) => {
        return (
            { value: `${item.soc_name}`, label: `${item.soc_name}` }
        );
    });

    let outputsoc_abbrev = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['soc_abbrev'] !== item['soc_abbrev']);
        return [...filtered, item];
    }, []);

    const soc_abbrevOptions = outputsoc_abbrev.map((item) => {
        return (
            { value: `${item.soc_abbrev}`, label: `${item.soc_abbrev}` }
        );
    });

    const openMultiDropdown = (e) => {
        setDropdownSelectedValue(e)

    }



    const columns = [

        {
            name:
                (
                    <span style={{ display: "flex" }}>
                        Text
                        <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Text")} alt="User Icon" />
                    </span>
                ),
            selector: row => row.Text,
            sortable: true

        },
        {
            name:
                (
                    <span style={{ display: "flex" }}>
                        Type
                        <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Type")} alt="User Icon" />
                    </span>
                ),
            selector: row => row.Type,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    Category
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Category")} alt="User Icon" />
                </span>
            ),
            selector: row => row.Category,
            sortable: true
        },
        {
            name: "Description",
            selector: row => row.Description,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    Snomed Code
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Snowmed_Code")} alt="User Icon" />
                </span>
            ),
            selector: row => row.Snomed_Code,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA Code
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("MedDRA_Code")} alt="User Icon" />
                </span>
            ),
            selector: row => row.MedDRA_Code,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    pt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("pt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.pt_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    hlt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hgt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.hlt_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    hlgt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hlt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.hlgt_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    soc_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.soc_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    soc_abbrev
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_abbrev")} alt="User Icon" />
                </span>
            ),
            selector: row => row.soc_abbrev,
            sortable: true
        },


    ]
    const [isPopupVisible, setIsPopupVisible] = useState(false);
    const [envType, setEnvType] = useState('');
    // const [filteredTableData, setFilteredTableData] = useState(tableData);
    const [enableNarrative, setEnableNarrative] = useState(false);

    const openPopup = (event) => {
        setIsPopupVisible(true)
    }

    const onTranslateClick = () => {
        // getData();
        // setEnableNarrative(true)
        // setIsModalOpen(true)

        navigate("/compare")
    }


    const onViewOutputClick = async () => {
        setIsModalOpen(false);
        const getReponse = await getData();
        setActive(false)
        console.log(getReponse, "getReponse")
        if (responseData.length) {
            setAPIResponse(responseData)
        } else {

            setAPIResponse(staticResponse)

        }
        setEnableNarrative(true)
    }

    const closePopup = (event) => {
        setIsPopupVisible(false)
    }

    const getEnvType = (event) => {
        if (event != null) {
            setEnvType(event);
            setDropdownStatus(true)
            if (event.value === "matched") {
                const filteredData = APIResponse.filter((item) => {
                    return item.MedDRA_Code === "No Meddra Mapping Found\/desc Found";
                });
                // setFilteredTableData(filteredData)
                setFilteredData(filteredData)

            } else {

                const filteredData = APIResponse.filter((item) => {
                    return item.MedDRA_Code !== "No Meddra Mapping Found\/desc Found";
                });
                // setFilteredTableData(filteredData)
                setFilteredData(filteredData)


            }

        } else {

            setEnvType([]);
        }
    }



    const openNewTab = () => {
        const xmlBlob = new Blob([JSON.parse(localStorage.getItem("xmlContent"))], { type: 'application/xml' });
        const xmlUrl = URL.createObjectURL(xmlBlob);
        window.open(xmlUrl, '_blank');
    };


    const getData = async () => {
        setActive(true)

        console.log(localStorage.getItem("narrativeString"))
        // toast.success("Fetched Data Successfully", { position: toast.POSITION.TOP_CENTER });
        const narrativeString = "This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.\n\nDrugs and latency: \n1. covid-19 vaccin pfizer orig/omic ba.1 injvlst\nchills: 10 hours after start\nheadache: 10 hours after start\nnausea: 10 hours after start\nmyalgia: 3 hours after start\nmalaise: 5 hours after start\nfatigue: 10 hours after start\ngeneralized joint pain: 6 hours after start\ninjection site warmth: 1 days after start\ninjection site pain: 1 days after start\ninjection site swelling: 1 days after start\ninjection site inflammation: 1 days after start\nhyperpyrexia: 10 hours after start\n\n\n\n\nPast drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml"
        const caseNarrative = localStorage.getItem("narrativeString") == null || undefined ? narrativeString : localStorage.getItem("narrativeString")
        await axios
            .get(extractionEndpoint(caseNarrative))
            .then((response) => {

                console.log("response.data", response?.data)
                // if (response?.data?.status_code == 200) {
                // const dataParsed=JSON.parse(response?.data)

                const dataParsed = JSON.parse(response?.data)
                console.log("dataParsed", dataParsed)
                setResponseData(dataParsed)


                // setTableData(response?.data?.overview)

                toast.success("Fetched Data Successfully", { position: toast.POSITION.TOP_CENTER });

                // } else {
                //     toast.error("Found error", { position: toast.POSITION.TOP_CENTER });
                // }

            })
            .catch((err) => {
                console.log(err.message);
            });




    }


    const uploadNavigate = () => {
        navigate('/upload')
    }
    const closeModal = () => {
        setIsModalOpen(false);
    };
    const refresh = () => {
        setOpen(false)
        setDropdownStatus(false);
        setDropdownSelectedValue("")

    };

    const conditionalRendering = (value) => {
        console.log("value", value)
        switch (value) {
            case "Text":
                return (
                    <ReactSelect
                        options={textOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getFeatures}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Text"}
                    />
                )
            case "Type":
                return (
                    <ReactSelect
                        options={typeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getType}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Type"}
                    />
                )
            case "Category":
                return (
                    <ReactSelect
                        options={categoryOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getCategory}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Category"}
                    />
                )
            case "Snowmed_Code":
                return (
                    <ReactSelect
                        options={Snomed_CodeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getSnomed_Code}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Snomed_Code"}
                    />
                )
            case "MedDRA_Code":
                return (
                    <ReactSelect
                        options={MedDRA_CodeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getMedDRA_Code}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by MedDRA_Code"}
                    />
                )
            case "pt_name":
                return (
                    <ReactSelect
                        options={pt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getpt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by pt_name"}
                    />
                )
            case "hgt_name":
                return (

                    <ReactSelect
                        options={hlt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={gethlt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by hlt_name"}
                    />
                )
            case "hlt_name":
                return (
                    <ReactSelect
                        options={hlgt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={gethlgt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by hlgt_name"}
                    />

                )
            case "soc_name":
                return (
                    <ReactSelect
                        options={soc_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getsoc_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by soc_name"}
                    />
                )
            case "soc_abbrev":
                return (
                    <ReactSelect
                        options={soc_abbrevOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getsoc_abbrev}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by soc_abbrev"}
                    />
                )

            default:
                return <></>
        }
    }

    const analyzeOnClick = () => {
        setIsModalOpen(true)
    }

    return (
        <>
            {/* <LoadingOverlay
                active={isActive}
                spinner
                text='Loading ...'
            > */}
            <Navbar />
            <div className="d-flex flex-row" style={{ marginTop: "30px" }}>
                <div className="first-half" style={{ margin: "10px", border: "1px solid lightgrey", borderRadius: "4px" }}>
                    <div style={{ width: "100%" }}>
                        <input id="myFile"
                            type="file"
                            accept=".xml"
                            hidden
                            onChange={handleFileUpload}

                        />
                        {/* <button className='active-button' style={{ width: "100%", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center" }}
                            onClick={() => { document.getElementById("myFile").click() }}>
                            <span style={{ marginRight: "10px" }}><img src={uploadpngWhite} alt="User Icon" height="25px" width="25px" /></span>
                            <span>Upload XML File</span>
                        </button> */}
                    </div>

                    {localStorage.getItem(fileName) != "" ?
                        <>
                            <div style={{ marginTop: "20px" }}>
                                <div style={{ border: "1px solid lightgrey", borderRadius: "8px", padding: "12px" }}>

                                    {/* <div style={{height:"100vh", overflowY:"auto"}}> */}
                                    <div style={{ textAlign: "center" }}>
                                        <img src={XMLIcon} alt="User Icon" height="130px" />
                                        {/* <img src={pdfIcon} alt="User Icon" /> */}
                                        {/* <XMLViewer xml={xmlContent} /> */}

                                    </div>
                                    <p style={{ textAlign: "center", wordWrap: "break-word" }}>{localStorage.getItem("fileName")}</p>


                                    {enableNarrative ?
                                        <>
                                            <hr></hr>
                                            <p style={{ textAlign: "center", display: "flex", justifyContent: "center", alignItems: "center", color: "#3368CE", fontSize: "15px", color: "#003152", cursor: "pointer", fontWeight: 600 }} onClick={openPopup}><span style={{ marginRight: "10px" }}>
                                                <img src={Eye_blue} alt="User Icon" height="25px" width="25px" /></span>View Narrative</p>
                                        </> : <></>

                                    }


                                </div>


                            </div>
                            <div style={{ display: "flex", flexDirection: "column", marginTop: "10px" }}>
                                <button className='active-button' style={{ marginBottom: "10px", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", cursor: "pointer" }}
                                    onClick={onTranslateClick}
                                >
                                    <img src={ChartDonut} alt="User Icon" /><span style={{ marginLeft: "8px" }}>Translate</span>
                                </button>
                                <button className='border-button' style={{ cursor: "pointer" }} onClick={openNewTab}>XML Viewer</button>
                            </div>
                        </> : <></>}


                </div>

                {
                    // fileName != "" && enableNarrative !== false ?
                    enableNarrative !== false ?

                        // !fileName ?
                        <div className="half">
                            <ProgressSteps uploadColor="rgba(41, 188, 118, 1)" dividerWidth="10px" entityColor="rgba(136, 136, 136, 1)" outputColor="rgba(136, 136, 136, 1)" width="98%" analyzeColor="rgba(41, 188, 118, 1)" viewColor="rgba(51, 104, 206, 1)" successStatus={true} successAnalyzeStatus={true} 
                                onNavigate={uploadNavigate} cursor={true} 
                                analyzeOnclick={analyzeOnClick} 
                                entityOnclick ={goToEntity}
                                codingOnclick ={goToNarrative}
                                outputOnclick ={goToSnomed}
                            />
                            {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li className="nav-item document-border-tab1">
                                    <a className="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Translate</a>
                                </li>
                                <li className="nav-item document-border-tab2">
                                    <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={goToEntity}>Entity Extraction</a>
                                </li>
                                <li className="nav-item document-border-tab3">
                                    <a className="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false" onClick={goToSnowmed}>Snomed to MedDra</a>
                                </li>
                            </ul> */}
                            <div>

                                <div style={{ display: "flex", marginBottom: "20px" }}>
                                    <div style={{ height: "20px", display: "flex", alignItems: "center", width: "50%" }}>
                                        <Select

                                            options={llmOptions}
                                            // menuIsOpen={open}
                                            className='fullWidth'
                                            placeholder="Select by Medium"
                                        />
                                    </div>
                                    <div style={{ width: "50%", marginTop: "-9px", display: "flex", justifyContent: "flex-end" }}>
                                        {open &&

                                            <Select

                                                options={envOptions}

                                                value={envType}

                                                onChange={getEnvType}
                                                styles={customStylesFiltered}
                                                placeholder="Filter by"
                                                menuIsOpen={open}

                                            />}

                                        <img src={refreshIcon} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => refresh()} height="30px" width="30px" alt="User Icon" />
                                        <img src={funnelSimple} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => setOpen(!open)} height="30px" width="30px" alt="User Icon" />


                                        <img src={downloadSimple} style={{ marginTop: "-6px", cursor: "pointer" }} height="30px" width="30px" alt="User Icon" />


                                    </div>



                                </div>


                                {/* <hr></hr> */}

                                <div className='Dcap-tableWrap'>
                                    <div style={{ marginBottom: "10px" }}>
                                        {conditionalRendering(dropdownSelectedValue)}
                                        {/* {openText ?

                                            <ReactSelect
                                                options={textOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getFeatures}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by Text"}
                                            /> :
                                            openType ?

                                            <ReactSelect
                                                options={typeOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getType}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by Type"}
                                            />:
                                            openCategory ?

                                            <ReactSelect
                                                options={categoryOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getCategory}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by Category"}
                                            />:openSnomed_Code ?

                                            <ReactSelect
                                                options={Snomed_CodeOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getSnomed_Code}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by Snomed_Code"}
                                            />:
                                            openMedDRA_Code ?

                                            <ReactSelect
                                                options={MedDRA_CodeOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getMedDRA_Code}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by MedDRA_Code"}
                                            />:openpt_name ?

                                            <ReactSelect
                                                options={pt_nameOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getpt_name}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by pt_name"}
                                            />:
                                            openhlt_name ?

                                            <ReactSelect
                                                options={hlt_nameOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={gethlt_name}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by hlt_name"}
                                            />:
                                            openhlgt_name ?

                                            <ReactSelect
                                                options={hlgt_nameOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={gethlgt_name}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by hlgt_name"}
                                            />:
                                            opensoc_name ?

                                            <ReactSelect
                                                options={soc_nameOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getsoc_name}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by soc_name"}
                                            />:opensoc_abbrev ?

                                            <ReactSelect
                                                options={soc_abbrevOptions}
                                                isMulti
                                                closeMenuOnSelect={false}
                                                hideSelectedOptions={false}
                                                components={{
                                                    Option
                                                }}
                                                onChange={getsoc_abbrev}
                                                allowSelectAll={true}
                                                // value={selectedFeatures}
                                                placeholder={"Filter by soc_abbrev"}
                                            />:<></>
                                        } */}

                                    </div>

                                    <DataTable
                                        customStyles={customStyles}
                                        columns={columns}
                                        // data={APIResponse}
                                        data={dropdownStatus ? filteredData : APIResponse}
                                        // conditionalRowStyles={conditionalRowStyles}
                                        pagination
                                    />

                                </div>



                            </div>

                            {isPopupVisible && (
                                <div className="popup">
                                    <div className="popup-content">
                                        {/* Your popup content here */}
                                        <div className='narrative'>
                                            <p style={{
                                                color: "#003152",
                                                fontSize: "18px",
                                                fontWeight: 600,
                                                textAlign: "center"
                                            }}>Narrative Data</p>
                                            {/* <div><button className='button-popup' onClick={closePopup}><FontAwesomeIcon icon={faTimes} /></button></div> */}
                                            <div style={{
                                                border: "1px solid lightgrey",
                                                borderRadius: "4px",
                                                marginTop: "25px"
                                            }}>
                                                <p style={{ padding: "0px 10px 10px 10px", fontSize: "14px", lineHeight: "25px" }}>
                                                    Pt is 87 yo woman, highschool teacher with past medical history that includes
                                                    - status post cardiac catheterization in April 2019.
                                                    She presents today with palpitations and chest pressure.
                                                    HPI : Sleeping trouble on present dosage of Clonidine. Severe Rash  on face and leg, slightly itchy.
                                                    Meds : Vyvanse 50 mgs po at breakfast daily,
                                                    Clonidine 0.2 mgs -- 1 and 1 / 2 tabs po qhs
                                                    HEENT : Boggy inferior turbinates, No oropharyngeal lesion.
                                                    Lungs : clear.
                                                    Heart : Regular rhythm.
                                                    Skin :  Mild erythematous eruption to hairline.

                                                    Follow-up as scheduled
                                                </p>
                                                {/* <p >This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.

                                                    Drugs and latency:
                                                    1. covid-19 vaccin pfizer orig/omic ba.1 injvlst
                                                    chills: 10 hours after start
                                                    headache: 10 hours after start
                                                    nausea: 10 hours after start
                                                    myalgia: 3 hours after start
                                                    malaise: 5 hours after start
                                                    fatigue: 10 hours after start
                                                    generalized joint pain: 6 hours after start
                                                    injection site warmth: 1 days after start
                                                    injection site pain: 1 days after start
                                                    injection site swelling: 1 days after start
                                                    injection site inflammation: 1 days after start
                                                    hyperpyrexia: 10 hours after start



                                                    Past drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml</p> */}
                                            </div>

                                            <button className='button-popup' onClick={closePopup}><FontAwesomeIcon icon={faTimes} /></button>
                                        </div>

                                    </div>
                                </div>
                            )}

                        </div> :
                        <>
                            <div className="half">

                                {/* <div style={{ margin:"10px" }}> */}
                                <ProgressSteps uploadColor="rgba(41, 188, 118, 1)" dividerWidth="10px" entityColor="rgba(136, 136, 136, 1)" outputColor="rgba(136, 136, 136, 1)" analyzeColor="rgba(51, 104, 206, 1)" viewColor="rgba(136, 136, 136, 1)" 
                                successStatus={true} 
                                onNavigate={uploadNavigate} cursor={true} 
                                analyzeOnclick={analyzeOnClick} 
                                entityOnclick ={goToEntity}
                                codingOnclick ={goToNarrative}
                                outputOnclick ={goToSnomed}
                                />
                                
                                {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                    <li className="nav-item document-border-tab1">
                                        <a className="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Translate</a>
                                    </li>
                                    <li className="nav-item document-border-tab2">
                                        <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={goToEntity}>Entity Extraction</a>
                                    </li>
                                    <li className="nav-item document-border-tab3">
                                        <a className="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false" onClick={goToSnowmed}>Snomed to MedDra</a>
                                    </li>
                                </ul> */}
                                {/* <img src={analyzeStep} alt="User Icon" tyle={{ width: "100%", marginBottom: "10px" }} /> */}
                                {/* </div> */}

                                <div style={{ marginLeft: "5px", marginRight: "30px", width: "100%", border: "1px solid lightgrey", borderRadius: "4px" }}>
                                    {/* <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}> */}
                                    {/* <img src={empty} alt="User Icon" /> */}
                                    <div style={{
                                        margin: "10px",
                                        fontSize: "16px",
                                        fontWeight: 600,
                                    }}>Input</div>
                                    <hr></hr>
                                    <div> <XMLViewer
                                        xml={xmlContent}
                                    // theme ={customTheme}
                                    /></div>
                                    {/* </div> */}

                                </div>

                            </div>
                        </>


                }

            </div>
            <ModalPopUpTable
                getData={onViewOutputClick}
                openModal={isModalOpen}
                popupWidth={"600px"}
                buttonTop={"4px"}
                close={closeModal}
                type="info"
            />
            {/* </LoadingOverlay> */}
        </>

    );
}

export default Translate;
