import React, { useState, useEffect } from 'react';
import axios from "axios";
import "./XMLLoader.css";
import { toast } from 'react-toastify';
import ModalPopUpTable from '../../common/model';
import Navbar from '../Navbar';
import { ClipLoader } from 'react-spinners';
import pdfIcon from "../../assets/pdfIcon.svg";
// import LoadingOverlay from 'react-loading-overlay';
import XMLIcon from "../../assets/XML_icon.svg";
import DataTable from "react-data-table-component";
import Eye_blue from "../../assets/Eye_blue.svg";
import empty from "../../assets/empty.svg";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';
import ChartDonut from "../../assets/ChartDonut.svg";
import downloadSimple from "../../assets/DownloadSimple.svg";
import funnelSimple from "../../assets/FunnelSimple.svg";
import funnelSimpleWhite from "../../assets/FunnelSimpleWhite.svg";

import refreshIcon from "../../assets/Refresh.svg";
import Select, { components } from "react-select";
import { default as ReactSelect } from "react-select";
import { useNavigate } from 'react-router-dom';
import ProgressSteps from '../../common/ProgressSteps';
import { extractionEndpoint } from '../../common/api-config';


function XMLFileUploader() {
    const navigate = useNavigate()
    const [xmlContent, setXMLContent] = useState('');
    const [fileName, setFileName] = useState('');
    const [open, setOpen] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [dropdownSelectedValue, setDropdownSelectedValue] = useState("")
    const [filteredData, setFilteredData] = useState([])
    const [dropdownStatus, setDropdownStatus] = useState(false)
    const [responseData, setResponseData] = useState([])
    const [APIResponse, setAPIResponse] = useState([])
    const [isActive, setActive] = useState(false)
    let [loading, setLoading] = useState(false);
    const envOptions = [
        { value: 'noMatched', label: 'Mapped' },
        { value: 'matched', label: 'Un mapped' },

    ]
    const llmOptions = [
        { value: 'noMatched', label: 'LLM' },
        { value: 'matched', label: 'AWS COMPREHEND MEDICAL' },

    ]

    const Option = (props) => {
        return (
            <div>
                <components.Option {...props}>
                    <input
                        type="checkbox"
                        checked={props.isSelected}
                        onChange={() => null}
                    />{" "}
                    <label>{props.label}</label>
                </components.Option>
            </div>
        );
    };


    const customStylesFiltered = {
        option: (provided, state) => ({
            ...provided,
            // borderBottom: '1px dotted pink',
            color: state.isSelected ? '#003152' : '#003152',
            width: 200,
        }),
        container: provided => ({
            ...provided,
            width: 200,
        }),
        control: () => ({
            border: 'none',
            display: 'none',
            width: 0,
        }),
    };

    const handleFileUpload = (event) => {
        const file = event.target.files[0];

        console.log("file", file)
        setFileName(file.name)
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                setXMLContent(e.target.result);
            };
            reader.readAsText(file);
        }
    };


    const customStyles = {
        // rows: {
        //     style: {
        //         minHeight: '72px', // override the row height

        //         color:"yellow"
        //     },
        // },

        rows: {

            style: {
                border: 'none',
                ':nth-of-type(even)': {
                    backgroundColor: "#F1F7FF"
                },
                fontFamily: "Poppins !important",

                borderRadius: 8,
                marginTop: 8
            }
        },

        headCells: {
            style: {
                backgroundColor: "#394356",
                color: "#fff",
                fontFamily: "Poppins !important",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 600
            },

        },
        cells: {
            style: {
                color: "#000000",
                fontFamily: "Poppins",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 400
            },

        },
    };

    const colourStyles = {
        control: (provided, state) => ({
            ...provided,
            border: state.isFocused ? "1px solid #555555" : "1px solid #555555",
            backgroundColor: '#555555', // Replace with your desired background color
            "&:hover": {
                border: "1px solid #555555",
                // boxShadow: "0px 0px 6px #ff8b67"
            }
        }),
        option: (styles, { data, isDisabled, isFocused, isSelected }) => {
            return {
                ...styles,
                backgroundColor: "#555555",
                border: "0px solid #555555",
                color: '#FFF',
                cursor: 'default',
                fontSize: "14px",
            };
        },
        singleValue: (styles, { data }) => ({
            ...styles,
            color: "#FFF",
            fontSize: "14px",
        }),
        placeholder: (styles, { data }) => ({
            ...styles,
            color: "#FFF",
            fontSize: "14px",
        }),
        menu: (styles) => ({
            ...styles,
            marginTop: 0,
            marginBottom: 0,
            borderRadius: 0,
            boxShadow: "none",
            border: "1px solid #1E2D3D",
            backgroundColor: "#555555", // Set the background color of the menu

            fontSize: "14px",
        }),
        menuList: (styles) => ({
            ...styles,
            padding: 0,
            borderRadius: 0,
            borderTop: "none",
            borderBottom: "none",
            fontSize: "14px",
        }),
    }




    const getFeatures = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Text)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getType = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Type)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getCategory = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Category)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getSnomed_Code = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Snomed_Code)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getMedDRA_Code = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.MedDRA_Code)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getpt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.pt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const gethlt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.hlt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const gethlgt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.hlgt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getsoc_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.soc_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getsoc_abbrev = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.soc_abbrev)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }


    let outputText = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Text'] !== item['Text']);
        return [...filtered, item];
    }, []);

    const textOptions = outputText.map((item) => {
        return (
            { value: `${item.Text}`, label: `${item.Text}` }
        );
    });

    let outputType = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Type'] !== item['Type']);
        return [...filtered, item];
    }, []);

    const typeOptions = outputType.map((item) => {
        return (
            { value: `${item.Type}`, label: `${item.Type}` }
        );
    });

    let outputCategory = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Category'] !== item['Category']);
        return [...filtered, item];
    }, []);

    const categoryOptions = outputCategory.map((item) => {
        return (
            { value: `${item.Category}`, label: `${item.Category}` }
        );
    });

    let outputSnomed_Code = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Snomed_Code'] !== item['Snomed_Code']);
        return [...filtered, item];
    }, []);

    const Snomed_CodeOptions = outputType.map((item) => {
        return (
            { value: `${item.Snomed_Code}`, label: `${item.Snomed_Code}` }
        );
    });

    let outputMedDRA_Code = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['MedDRA_Code'] !== item['MedDRA_Code']);
        return [...filtered, item];
    }, []);

    const MedDRA_CodeOptions = outputMedDRA_Code.map((item) => {
        return (
            { value: `${item.MedDRA_Code}`, label: `${item.MedDRA_Code}` }
        );
    });

    let outputpt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['pt_name'] !== item['pt_name']);
        return [...filtered, item];
    }, []);

    const pt_nameOptions = outputpt_name.map((item) => {
        return (
            { value: `${item.pt_name}`, label: `${item.pt_name}` }
        );
    });

    let outputhlt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['hlt_name'] !== item['hlt_name']);
        return [...filtered, item];
    }, []);

    const hlt_nameOptions = outputhlt_name.map((item) => {
        return (
            { value: `${item.hlt_name}`, label: `${item.hlt_name}` }
        );
    });

    let outputhlgt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['hlgt_name'] !== item['hlgt_name']);
        return [...filtered, item];
    }, []);

    const hlgt_nameOptions = outputhlgt_name.map((item) => {
        return (
            { value: `${item.hlgt_name}`, label: `${item.hlgt_name}` }
        );
    });

    let outputsoc_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['soc_name'] !== item['soc_name']);
        return [...filtered, item];
    }, []);

    const soc_nameOptions = outputsoc_name.map((item) => {
        return (
            { value: `${item.soc_name}`, label: `${item.soc_name}` }
        );
    });

    let outputsoc_abbrev = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['soc_abbrev'] !== item['soc_abbrev']);
        return [...filtered, item];
    }, []);

    const soc_abbrevOptions = outputsoc_abbrev.map((item) => {
        return (
            { value: `${item.soc_abbrev}`, label: `${item.soc_abbrev}` }
        );
    });

    const openMultiDropdown = (e) => {
        setDropdownSelectedValue(e)

    }



    const columns = [

        {
            name:
                (
                    <span style={{ display: "flex" }}>
                        Text
                        <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Text")} alt="User Icon" />
                    </span>
                ),
            selector: row => row.Text,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            },

        },
        {
            name:
                (
                    <span style={{ display: "flex" }}>
                        Type
                        <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Type")} alt="User Icon" />
                    </span>
                ),
            selector: row => row.Type,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            },
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    Category
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Category")} alt="User Icon" />
                </span>
            ),
            selector: row => row.Category,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            },
        },
        {
            name: "Description",
            selector: row => row.Description,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            },
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    Snomed Code
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Snowmed_Code")} alt="User Icon" />
                </span>
            ),
            selector: row => row.Snomed_Code,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            },
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA Code
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("MedDRA_Code")} alt="User Icon" />
                </span>
            ),
            selector: row => row.MedDRA_Code,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",

            },
            // wrap:true,

            conditionalCellStyles: [
                {
                    when: row => row.MedDRA_Code !== "No Meddra Mapping Found\/desc Found",
                    style: {
                        backgroundColor: "#21AC69",
                        color: 'white',
                        '&:hover': {
                            cursor: 'pointer',
                        },
                    },
                },


            ],
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA_pt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("pt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.pt_name,
            sortable: true,

            style: {
                backgroundColor: "aliceblue",

            },
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA_hlt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hgt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.hlt_name,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",

            },
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA_hlgt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hlt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.hlgt_name,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",

            },
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA_soc_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.soc_name,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",

            },
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA_soc_abbrev
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_abbrev")} alt="User Icon" />
                </span>
            ),
            selector: row => row.soc_abbrev,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",

            },
        },


    ]
    const [isPopupVisible, setIsPopupVisible] = useState(false);
    const [envType, setEnvType] = useState('');
    // const [filteredTableData, setFilteredTableData] = useState(tableData);
    const [enableNarrative, setEnableNarrative] = useState(false);

    const openPopup = (event) => {
        setIsPopupVisible(true)
    }

    const onAnalyzeClick = () => {
        // getData();
        // setEnableNarrative(true)
        setIsModalOpen(true)
    }

    const onViewOutputClick = async () => {
        setIsModalOpen(false);
        await getData();
        setActive(false)
        setLoading(false)

        // console.log("responseData", responseData)
        // if (responseData) {
        //     setAPIResponse(responseData)
        // }
        setEnableNarrative(true)
    }

    const closePopup = (event) => {
        setIsPopupVisible(false)
    }

    const getEnvType = (event) => {
        if (event != null) {
            setEnvType(event);
            setDropdownStatus(true)
            if (event.value === "matched") {
                const filteredData = APIResponse.filter((item) => {
                    return item.MedDRA_Code === "No Meddra Mapping Found\/desc Found";
                });
                // setFilteredTableData(filteredData)
                setFilteredData(filteredData)

            } else {

                const filteredData = APIResponse.filter((item) => {
                    return item.MedDRA_Code !== "No Meddra Mapping Found\/desc Found";
                });
                // setFilteredTableData(filteredData)
                setFilteredData(filteredData)


            }

        } else {

            setEnvType([]);
        }
    }



    const openNewTab = () => {
        const xmlBlob = new Blob([xmlContent === "" ? JSON.parse(localStorage.getItem("xmlContent")) : xmlContent], { type: 'application/xml' });
        const xmlUrl = URL.createObjectURL(xmlBlob);
        window.open(xmlUrl, '_blank');
    };


    const getData = async () => {
        setActive(true)
        setLoading(true)


        console.log(localStorage.getItem("narrativeString"))
        // toast.success("Fetched Data Successfully", { position: toast.POSITION.TOP_CENTER });
        const caseNarrative = localStorage.getItem("narrativeString")
        await axios
            .get(extractionEndpoint(caseNarrative))
            .then((response) => {

                console.log("response.data", response?.data)
                // if (response?.data?.status_code == 200) {
                // const dataParsed=JSON.parse(response?.data)

                const dataParsed = JSON.parse(response?.data)
                console.log("dataParsed", dataParsed)
                setResponseData(dataParsed)
                setAPIResponse(dataParsed)


                // setTableData(response?.data?.overview)

                toast.success("Fetched Data Successfully", { position: toast.POSITION.TOP_CENTER });

                // } else {
                //     toast.error("Found error", { position: toast.POSITION.TOP_CENTER });
                // }

            })
            .catch((err) => {
                console.log(err.message);
            });




    }


    const uploadNavigate = () => {
        navigate('/upload')
    }
    const goToTranslate = () => {
        navigate("/translate")
    }


    const goToEntity = () => {
        navigate("/documentAnalyzeN")
    }

    const goToNarrative = () => {
        navigate("/narrativeInput")
    }

    const closeModal = () => {
        setIsModalOpen(false);
    };
    const refresh = () => {
        setOpen(false)
        setDropdownStatus(false);
        setDropdownSelectedValue("")

    };

    const conditionalRendering = (value) => {
        console.log("value", value)
        switch (value) {
            case "Text":
                return (
                    <ReactSelect
                        options={textOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getFeatures}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Text"}
                    />
                )
            case "Type":
                return (
                    <ReactSelect
                        options={typeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getType}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Type"}
                    />
                )
            case "Category":
                return (
                    <ReactSelect
                        options={categoryOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getCategory}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Category"}
                    />
                )
            case "Snowmed_Code":
                return (
                    <ReactSelect
                        options={Snomed_CodeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getSnomed_Code}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Snomed_Code"}
                    />
                )
            case "MedDRA_Code":
                return (
                    <ReactSelect
                        options={MedDRA_CodeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getMedDRA_Code}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by MedDRA_Code"}
                    />
                )
            case "pt_name":
                return (
                    <ReactSelect
                        options={pt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getpt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by pt_name"}
                    />
                )
            case "hgt_name":
                return (

                    <ReactSelect
                        options={hlt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={gethlt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by hlt_name"}
                    />
                )
            case "hlt_name":
                return (
                    <ReactSelect
                        options={hlgt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={gethlgt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by hlgt_name"}
                    />

                )
            case "soc_name":
                return (
                    <ReactSelect
                        options={soc_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getsoc_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by soc_name"}
                    />
                )
            case "soc_abbrev":
                return (
                    <ReactSelect
                        options={soc_abbrevOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getsoc_abbrev}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by soc_abbrev"}
                    />
                )

            default:
                return <></>
        }
    }

    const analyzeOnClick = () => {
        setIsModalOpen(true)
    }

    // console.log("APIS", APIResponse)

    return (
        <>
            {/* <LoadingOverlay
                active={isActive}
                spinner
                text='Loading ...'
            > */}
            <Navbar />
            <div className="d-flex flex-row" style={{ marginTop: "30px" }}>
                <div className="first-half" style={{ margin: "10px", border: "1px solid lightgrey", borderRadius: "4px" }}>
                    <div style={{ width: "100%" }}>
                        <input id="myFile"
                            type="file"
                            accept=".xml"
                            hidden
                            onChange={handleFileUpload}

                        />
                        {/* <button className='active-button' style={{ width: "100%", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center" }}
                            onClick={() => { document.getElementById("myFile").click() }}>
                            <span style={{ marginRight: "10px" }}><img src={uploadpngWhite} alt="User Icon" height="25px" width="25px" /></span>
                            <span>Upload XML File</span>
                        </button> */}
                    </div>

                    {localStorage.getItem(fileName) != "" ?
                        <>
                            <div style={{ marginTop: "20px" }}>
                                <div style={{ border: "1px solid lightgrey", borderRadius: "8px", padding: "12px" }}>

                                    {/* <div style={{height:"100vh", overflowY:"auto"}}> */}
                                    <div style={{ textAlign: "center" }}>
                                        <img src={XMLIcon} alt="User Icon" height="130px" />
                                        {/* <img src={pdfIcon} alt="User Icon" /> */}
                                        {/* <XMLViewer xml={xmlContent} /> */}

                                    </div>
                                    <p style={{ textAlign: "center", wordWrap: "break-word" }}>{localStorage.getItem("fileName")}</p>


                                    {enableNarrative ?
                                        <>
                                            <hr></hr>
                                            <p style={{ textAlign: "center", display: "flex", justifyContent: "center", alignItems: "center", color: "#3368CE", fontSize: "15px", color: "#003152", cursor: "pointer", fontWeight: 600 }} onClick={openPopup}><span style={{ marginRight: "10px" }}>
                                                <img src={Eye_blue} alt="User Icon" height="25px" width="25px" /></span>View Narrative</p>
                                        </> : <></>

                                    }


                                </div>


                            </div>
                            <div style={{ display: "flex", flexDirection: "column", marginTop: "10px" }}>
                                <button className='active-button' style={{ marginBottom: "10px", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", cursor: "pointer" }}
                                    onClick={onAnalyzeClick}
                                >
                                    <img src={ChartDonut} alt="User Icon" /><span style={{ marginLeft: "8px" }}>Analyze</span>
                                </button>
                                <button className='border-button' style={{ cursor: "pointer" }} onClick={openNewTab}>XML Viewer</button>
                            </div>
                        </> : <></>}


                </div>

                {
                    // fileName != "" && enableNarrative !== false ?
                    enableNarrative !== false ?

                        // !fileName ?
                        <div className="half">

                            <ProgressSteps marginBottom="15px"
                                uploadColor="rgba(41, 188, 118, 1)"
                                entityColor="rgba(51, 104, 206, 1)"
                                outputColor="rgba(136, 136, 136, 1)"
                                analyzeColor="rgba(41, 188, 118, 1)"
                                viewColor="rgba(41, 188, 118, 1)"

                                successStatus={true}
                                analyzeOnclick={goToTranslate}
                                entityOnclick={goToEntity}
                                onNavigate={uploadNavigate}
                                codingOnclick={goToNarrative}

                                // outputOnclick ={goToSnomed}
                                cursor={true} successAnalyzeStatus={true} entityStatus={true} />

                            {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                    <li className="nav-item document-border-tab1">
                                        <a className="nav-link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true" onClick={goToTranslate}>Translate</a>
                                    </li>
                                    <li className="nav-item document-border-tab2">
                                        <a className="nav-link active" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={goToEntity}>Entity Extraction</a>
                                    </li>
                                    <li className="nav-item document-border-tab3">
                                        <a className="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Snomed to MedDra</a>
                                    </li>
                                </ul> */}
                            <div>

                                <div style={{ display: "flex", marginBottom: "20px" }}>
                                    <div style={{ height: "20px", display: "flex", alignItems: "center", width: "50%" }}>
                                        <Select

                                            options={llmOptions}
                                            // menuIsOpen={open}
                                            className='fullWidth'
                                            placeholder="Select by Medium"
                                        />
                                    </div>
                                    <div style={{ width: "50%", marginTop: "-9px", display: "flex", justifyContent: "flex-end" }}>
                                        {open &&

                                            <Select

                                                options={envOptions}

                                                value={envType}

                                                onChange={getEnvType}
                                                styles={customStylesFiltered}
                                                placeholder="Filter by"
                                                menuIsOpen={open}

                                            />}

                                        <img src={refreshIcon} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => refresh()} height="30px" width="30px" alt="User Icon" />
                                        <img src={funnelSimple} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => setOpen(!open)} height="30px" width="30px" alt="User Icon" />


                                        <img src={downloadSimple} style={{ marginTop: "-6px", cursor: "pointer" }} height="30px" width="30px" alt="User Icon" />


                                    </div>



                                </div>


                                {/* <hr></hr> */}

                                <div className='Dcap-tableWrap'>
                                    <div style={{ marginBottom: "10px" }}>
                                        {conditionalRendering(dropdownSelectedValue)}


                                    </div>

                                    <DataTable
                                        customStyles={customStyles}
                                        columns={columns}
                                        // data={APIResponse}
                                        data={dropdownStatus ? filteredData : APIResponse}
                                        // conditionalRowStyles={conditionalRowStyles}
                                        pagination
                                    />

                                </div>



                            </div>

                            {isPopupVisible && (
                                <div className="popup">
                                    <div className="popup-content">

                                        <div className='narrative'>
                                            <p style={{
                                                color: "#003152",
                                                fontSize: "18px",
                                                fontWeight: 600,
                                                textAlign: "center"
                                            }}>Narrative Data</p>
                                            {/* <div><button className='button-popup' onClick={closePopup}><FontAwesomeIcon icon={faTimes} /></button></div> */}
                                            <div style={{
                                                border: "1px solid lightgrey",
                                                borderRadius: "4px",
                                                marginTop: "25px",
                                                height: "310px",
                                                overflowY: "auto"
                                            }}>
                                                <p style={{ padding: "0px 10px 10px 10px", fontSize: "14px", lineHeight: "25px" }}>
                                                    {localStorage.getItem("narrativeString")}
                                                </p>

                                            </div>

                                            <button className='button-popup' onClick={closePopup}><FontAwesomeIcon icon={faTimes} /></button>
                                        </div>

                                    </div>
                                </div>
                            )}

                        </div> :
                        <>
                            <div className="half">


                                <ProgressSteps marginBottom="15px"
                                    uploadColor="rgba(41, 188, 118, 1)"
                                    entityColor="rgba(51, 104, 206, 1)"
                                    outputColor="rgba(136, 136, 136, 1)"
                                    analyzeColor="rgba(41, 188, 118, 1)"
                                    viewColor="rgba(41, 188, 118, 1)"

                                    successStatus={true}
                                    analyzeOnclick={goToTranslate}
                                    entityOnclick={goToEntity}
                                    onNavigate={uploadNavigate}
                                    codingOnclick={goToNarrative}

                                    // outputOnclick ={goToSnomed}
                                    cursor={true} successAnalyzeStatus={true} entityStatus={true} />

                                {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                    <li className="nav-item document-border-tab1">
                                        <a className="nav-link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true" onClick={goToTranslate}>Translate</a>
                                    </li>
                                    <li className="nav-item document-border-tab2">
                                        <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={goToEntity}>Entity Extraction</a>
                                    </li>
                                    <li className="nav-item document-border-tab3">
                                        <a className="nav-link active" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Snomed to MedDra</a>
                                    </li>
                                </ul> */}
                                <div style={{ marginLeft: "5px", marginRight: "30px", width: "100%", border: "1px solid lightgrey", borderRadius: "4px" }}>
                                    <div style={{ display: "flex", alignItems: "center", justifyContent: "center" }}><img src={empty} alt="User Icon" /></div>

                                </div>

                            </div>
                        </>


                }

            </div>
            <ModalPopUpTable
                getData={onViewOutputClick}
                openModal={isModalOpen}
                popupWidth={"600px"}
                buttonTop={"4px"}
                close={closeModal}
                type="info"
            />
            {loading && (
                <div
                    style={{
                        position: 'fixed',
                        top: '0',
                        left: '0',
                        width: '100%',
                        height: '100%',
                        display: 'flex',
                        justifyContent: 'center',
                        alignItems: 'center',
                        background: 'rgba(0, 0, 0, 0.5)',
                        zIndex: '9999',
                    }}
                >
                    <ClipLoader color="#ffffff" size={80} />
                </div>)}
            {/* </LoadingOverlay> */}
        </>

    );
}

export default XMLFileUploader;
