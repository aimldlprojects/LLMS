import React, { useState, useEffect } from 'react';
import axios from "axios";
import "./XMLLoader.css";
import { toast } from 'react-toastify';
import ModalPopUpTable from '../../common/model';
import Navbar from '../Navbar';
import pdfIcon from "../../assets/pdfIcon.svg";
// import LoadingOverlay from 'react-loading-overlay';
import XMLIcon from "../../assets/XML_icon.svg";
import DataTable from "react-data-table-component";
import jsonResponse from "./jsonResponse.json";
import Eye_blue from "../../assets/Eye_blue.svg";
import empty from "../../assets/empty.svg";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';
import ChartDonut from "../../assets/ChartDonut.svg";
import downloadSimple from "../../assets/DownloadSimple.svg";
import funnelSimple from "../../assets/FunnelSimple.svg";
import funnelSimpleWhite from "../../assets/FunnelSimpleWhite.svg";
import XMLViewer from 'react-xml-viewer';
import refreshIcon from "../../assets/Refresh.svg";
import Select, { components } from "react-select";
import { default as ReactSelect } from "react-select";
import { useNavigate } from 'react-router-dom';
import ProgressSteps from '../../common/ProgressSteps';
import { extractionEndpoint } from '../../common/api-config';


function TranslateCompare() {
    const staticResponse = jsonResponse.jsonResponse
    const navigate = useNavigate()
    const [xmlContent, setXMLContent] = useState('');
    const [fileName, setFileName] = useState('');
    const [open, setOpen] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [dropdownSelectedValue, setDropdownSelectedValue] = useState("")
    const [filteredData, setFilteredData] = useState([])
    const [dropdownStatus, setDropdownStatus] = useState(false)
    const [responseData, setResponseData] = useState([])
    const [APIResponse, setAPIResponse] = useState([])
    const [isActive, setActive] = useState(false)
    const envOptions = [
        { value: 'noMatched', label: 'Mapped' },
        { value: 'matched', label: 'Un mapped' },

    ]
    const llmOptions = [
        { value: 'noMatched', label: 'LLM' },
        { value: 'matched', label: 'AWS COMPREHEND MEDICAL' },

    ]

    const Option = (props) => {
        return (
            <div>
                <components.Option {...props}>
                    <input
                        type="checkbox"
                        checked={props.isSelected}
                        onChange={() => null}
                    />{" "}
                    <label>{props.label}</label>
                </components.Option>
            </div>
        );
    };


    const customStylesFiltered = {
        option: (provided, state) => ({
            ...provided,
            // borderBottom: '1px dotted pink',
            color: state.isSelected ? '#003152' : '#003152',
            width: 200,
        }),
        container: provided => ({
            ...provided,
            width: 200,
        }),
        control: () => ({
            border: 'none',
            display: 'none',
            width: 0,
        }),
    };

    const handleFileUpload = (event) => {
        const file = event.target.files[0];

        console.log("file", file)
        setFileName(file.name)
        if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
                setXMLContent(e.target.result);
            };
            reader.readAsText(file);
        }
    };


    const customStyles = {
        // rows: {
        //     style: {
        //         minHeight: '72px', // override the row height

        //         color:"yellow"
        //     },
        // },

        rows: {

            style: {
                border: 'none',
                ':nth-of-type(even)': {
                    backgroundColor: "#F1F7FF"
                },
                fontFamily: "Poppins !important",

                borderRadius: 8,
                marginTop: 8
            }
        },

        headCells: {
            style: {
                backgroundColor: "#394356",
                color: "#fff",
                fontFamily: "Poppins !important",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 600
            },

        },
        cells: {
            style: {
                color: "#000000",
                fontFamily: "Poppins",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 400
            },

        },
    };

    const colourStyles = {
        control: (provided, state) => ({
            ...provided,
            border: state.isFocused ? "1px solid #555555" : "1px solid #555555",
            backgroundColor: '#555555', // Replace with your desired background color
            "&:hover": {
                border: "1px solid #555555",
                // boxShadow: "0px 0px 6px #ff8b67"
            }
        }),
        option: (styles, { data, isDisabled, isFocused, isSelected }) => {
            return {
                ...styles,
                backgroundColor: "#555555",
                border: "0px solid #555555",
                color: '#FFF',
                cursor: 'default',
                fontSize: "14px",
            };
        },
        singleValue: (styles, { data }) => ({
            ...styles,
            color: "#FFF",
            fontSize: "14px",
        }),
        placeholder: (styles, { data }) => ({
            ...styles,
            color: "#FFF",
            fontSize: "14px",
        }),
        menu: (styles) => ({
            ...styles,
            marginTop: 0,
            marginBottom: 0,
            borderRadius: 0,
            boxShadow: "none",
            border: "1px solid #1E2D3D",
            backgroundColor: "#555555", // Set the background color of the menu

            fontSize: "14px",
        }),
        menuList: (styles) => ({
            ...styles,
            padding: 0,
            borderRadius: 0,
            borderTop: "none",
            borderBottom: "none",
            fontSize: "14px",
        }),
    }




    const getFeatures = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Text)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getType = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Type)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getCategory = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Category)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getSnomed_Code = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.Snomed_Code)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getMedDRA_Code = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.MedDRA_Code)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getpt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.pt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const gethlt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.hlt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const gethlgt_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.hlgt_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getsoc_name = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.soc_name)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }
    const getsoc_abbrev = (event) => {
        console.log(event)
        if (event.length >= 1) {
            setDropdownStatus(true)
            const filteredTable = APIResponse.filter((item) =>
                event.some(dataItem => dataItem.value === item.soc_abbrev)
            )
            setFilteredData(filteredTable)
        } else {
            setDropdownStatus(false)
        }
    }


    let outputText = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Text'] !== item['Text']);
        return [...filtered, item];
    }, []);

    const textOptions = outputText.map((item) => {
        return (
            { value: `${item.Text}`, label: `${item.Text}` }
        );
    });

    let outputType = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Type'] !== item['Type']);
        return [...filtered, item];
    }, []);

    const typeOptions = outputType.map((item) => {
        return (
            { value: `${item.Type}`, label: `${item.Type}` }
        );
    });

    let outputCategory = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Category'] !== item['Category']);
        return [...filtered, item];
    }, []);

    const categoryOptions = outputCategory.map((item) => {
        return (
            { value: `${item.Category}`, label: `${item.Category}` }
        );
    });

    let outputSnomed_Code = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['Snomed_Code'] !== item['Snomed_Code']);
        return [...filtered, item];
    }, []);

    const Snomed_CodeOptions = outputType.map((item) => {
        return (
            { value: `${item.Snomed_Code}`, label: `${item.Snomed_Code}` }
        );
    });

    let outputMedDRA_Code = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['MedDRA_Code'] !== item['MedDRA_Code']);
        return [...filtered, item];
    }, []);

    const MedDRA_CodeOptions = outputMedDRA_Code.map((item) => {
        return (
            { value: `${item.MedDRA_Code}`, label: `${item.MedDRA_Code}` }
        );
    });

    let outputpt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['pt_name'] !== item['pt_name']);
        return [...filtered, item];
    }, []);

    const pt_nameOptions = outputpt_name.map((item) => {
        return (
            { value: `${item.pt_name}`, label: `${item.pt_name}` }
        );
    });

    let outputhlt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['hlt_name'] !== item['hlt_name']);
        return [...filtered, item];
    }, []);

    const hlt_nameOptions = outputhlt_name.map((item) => {
        return (
            { value: `${item.hlt_name}`, label: `${item.hlt_name}` }
        );
    });

    let outputhlgt_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['hlgt_name'] !== item['hlgt_name']);
        return [...filtered, item];
    }, []);

    const hlgt_nameOptions = outputhlgt_name.map((item) => {
        return (
            { value: `${item.hlgt_name}`, label: `${item.hlgt_name}` }
        );
    });

    let outputsoc_name = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['soc_name'] !== item['soc_name']);
        return [...filtered, item];
    }, []);

    const soc_nameOptions = outputsoc_name.map((item) => {
        return (
            { value: `${item.soc_name}`, label: `${item.soc_name}` }
        );
    });

    let outputsoc_abbrev = APIResponse.reduce((arr, item) => {
        const filtered = arr.filter(i => i['soc_abbrev'] !== item['soc_abbrev']);
        return [...filtered, item];
    }, []);

    const soc_abbrevOptions = outputsoc_abbrev.map((item) => {
        return (
            { value: `${item.soc_abbrev}`, label: `${item.soc_abbrev}` }
        );
    });

    const openMultiDropdown = (e) => {
        setDropdownSelectedValue(e)

    }



    const columns = [

        {
            name:
                (
                    <span style={{ display: "flex" }}>
                        Text
                        <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Text")} alt="User Icon" />
                    </span>
                ),
            selector: row => row.Text,
            sortable: true

        },
        {
            name:
                (
                    <span style={{ display: "flex" }}>
                        Type
                        <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Type")} alt="User Icon" />
                    </span>
                ),
            selector: row => row.Type,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    Category
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Category")} alt="User Icon" />
                </span>
            ),
            selector: row => row.Category,
            sortable: true
        },
        {
            name: "Description",
            selector: row => row.Description,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    Snomed Code
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Snowmed_Code")} alt="User Icon" />
                </span>
            ),
            selector: row => row.Snomed_Code,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    MedDRA Code
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("MedDRA_Code")} alt="User Icon" />
                </span>
            ),
            selector: row => row.MedDRA_Code,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    pt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("pt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.pt_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    hlt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hgt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.hlt_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    hlgt_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hlt_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.hlgt_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    soc_name
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_name")} alt="User Icon" />
                </span>
            ),
            selector: row => row.soc_name,
            sortable: true
        },
        {
            name: (
                <span style={{ display: "flex" }}>
                    soc_abbrev
                    <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_abbrev")} alt="User Icon" />
                </span>
            ),
            selector: row => row.soc_abbrev,
            sortable: true
        },


    ]
    const [isPopupVisible, setIsPopupVisible] = useState(false);
    const [envType, setEnvType] = useState('');
    // const [filteredTableData, setFilteredTableData] = useState(tableData);
    const [enableNarrative, setEnableNarrative] = useState(false);

    const openPopup = (event) => {
        setIsPopupVisible(true)
    }

    const onAnalyzeClick = () => {
        // getData();
        // setEnableNarrative(true)
        // setIsModalOpen(true)
    }

    const onViewOutputClick = async () => {
        setIsModalOpen(false);
        const getReponse = await getData();
        setActive(false)
        console.log(getReponse, "getReponse")
        if (responseData.length) {
            setAPIResponse(responseData)
        } else {

            setAPIResponse(staticResponse)

        }
        setEnableNarrative(true)
    }

    const closePopup = (event) => {
        setIsPopupVisible(false)
    }

    const getEnvType = (event) => {
        if (event != null) {
            setEnvType(event);
            setDropdownStatus(true)
            if (event.value === "matched") {
                const filteredData = APIResponse.filter((item) => {
                    return item.MedDRA_Code === "No Meddra Mapping Found\/desc Found";
                });
                // setFilteredTableData(filteredData)
                setFilteredData(filteredData)

            } else {

                const filteredData = APIResponse.filter((item) => {
                    return item.MedDRA_Code !== "No Meddra Mapping Found\/desc Found";
                });
                // setFilteredTableData(filteredData)
                setFilteredData(filteredData)


            }

        } else {

            setEnvType([]);
        }
    }



    const openNewTab = () => {
        const xmlBlob = new Blob([xmlContent === "" ? JSON.parse(localStorage.getItem("xmlContent")) : xmlContent], { type: 'application/xml' });
        const xmlUrl = URL.createObjectURL(xmlBlob);
        window.open(xmlUrl, '_blank');
    };


    const getData = async () => {
        setActive(true)

        console.log(localStorage.getItem("narrativeString"))
        // toast.success("Fetched Data Successfully", { position: toast.POSITION.TOP_CENTER });
        const narrativeString = "This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.\n\nDrugs and latency: \n1. covid-19 vaccin pfizer orig/omic ba.1 injvlst\nchills: 10 hours after start\nheadache: 10 hours after start\nnausea: 10 hours after start\nmyalgia: 3 hours after start\nmalaise: 5 hours after start\nfatigue: 10 hours after start\ngeneralized joint pain: 6 hours after start\ninjection site warmth: 1 days after start\ninjection site pain: 1 days after start\ninjection site swelling: 1 days after start\ninjection site inflammation: 1 days after start\nhyperpyrexia: 10 hours after start\n\n\n\n\nPast drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml"
        const caseNarrative = localStorage.getItem("narrativeString") == null || undefined ? narrativeString : localStorage.getItem("narrativeString")
        await axios
            .get(extractionEndpoint(caseNarrative))
            .then((response) => {

                console.log("response.data", response?.data)
                // if (response?.data?.status_code == 200) {
                // const dataParsed=JSON.parse(response?.data)

                const dataParsed = JSON.parse(response?.data)
                console.log("dataParsed", dataParsed)
                setResponseData(dataParsed)


                // setTableData(response?.data?.overview)

                toast.success("Fetched Data Successfully", { position: toast.POSITION.TOP_CENTER });

                // } else {
                //     toast.error("Found error", { position: toast.POSITION.TOP_CENTER });
                // }

            })
            .catch((err) => {
                console.log(err.message);
            });




    }


    const uploadNavigate = () => {
        navigate('/upload')
    }
    const goToEntity = () => {
        navigate("/documentAnalyzeN")
    }
    const goToSnomed = () => {
        navigate("/analyze")
    }
    const goToNarrative = () => {
        navigate("/narrativeInput")
    }
    const closeModal = () => {
        setIsModalOpen(false);
    };
    const refresh = () => {
        setOpen(false)
        setDropdownStatus(false);
        setDropdownSelectedValue("")

    };

    const conditionalRendering = (value) => {
        console.log("value", value)
        switch (value) {
            case "Text":
                return (
                    <ReactSelect
                        options={textOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getFeatures}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Text"}
                    />
                )
            case "Type":
                return (
                    <ReactSelect
                        options={typeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getType}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Type"}
                    />
                )
            case "Category":
                return (
                    <ReactSelect
                        options={categoryOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getCategory}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Category"}
                    />
                )
            case "Snowmed_Code":
                return (
                    <ReactSelect
                        options={Snomed_CodeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getSnomed_Code}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by Snomed_Code"}
                    />
                )
            case "MedDRA_Code":
                return (
                    <ReactSelect
                        options={MedDRA_CodeOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getMedDRA_Code}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by MedDRA_Code"}
                    />
                )
            case "pt_name":
                return (
                    <ReactSelect
                        options={pt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getpt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by pt_name"}
                    />
                )
            case "hgt_name":
                return (

                    <ReactSelect
                        options={hlt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={gethlt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by hlt_name"}
                    />
                )
            case "hlt_name":
                return (
                    <ReactSelect
                        options={hlgt_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={gethlgt_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by hlgt_name"}
                    />

                )
            case "soc_name":
                return (
                    <ReactSelect
                        options={soc_nameOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getsoc_name}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by soc_name"}
                    />
                )
            case "soc_abbrev":
                return (
                    <ReactSelect
                        options={soc_abbrevOptions}
                        isMulti
                        closeMenuOnSelect={false}
                        hideSelectedOptions={false}
                        components={{
                            Option
                        }}
                        onChange={getsoc_abbrev}
                        allowSelectAll={true}
                        // value={selectedFeatures}
                        placeholder={"Filter by soc_abbrev"}
                    />
                )

            default:
                return <></>
        }
    }

    const analyzeOnClick = () => {
        setIsModalOpen(true)
    }

    const goToAcknowledge = () => {
        navigate("/acknowledge")
    }

    return (
        <>
            {/* <LoadingOverlay
                active={isActive}
                spinner
                text='Loading ...'
            > */}
            <Navbar />
            <div className="d-flex flex-row" style={{ marginTop: "30px" }}>
                <div className="first-half" style={{ margin: "10px", border: "1px solid lightgrey", borderRadius: "4px" }}>
                    <div style={{ width: "100%" }}>
                        <input id="myFile"
                            type="file"
                            accept=".xml"
                            hidden
                            onChange={handleFileUpload}

                        />
                        {/* <button className='active-button' style={{ width: "100%", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center" }}
                            onClick={() => { document.getElementById("myFile").click() }}>
                            <span style={{ marginRight: "10px" }}><img src={uploadpngWhite} alt="User Icon" height="25px" width="25px" /></span>
                            <span>Upload XML File</span>
                        </button> */}
                    </div>

                    {localStorage.getItem(fileName) != "" ?
                        <>
                            <div style={{ marginTop: "20px" }}>
                                <div style={{ border: "1px solid lightgrey", borderRadius: "8px", padding: "12px" }}>

                                    {/* <div style={{height:"100vh", overflowY:"auto"}}> */}
                                    <div style={{ textAlign: "center" }}>
                                        <img src={XMLIcon} alt="User Icon" height="130px" />
                                        {/* <img src={pdfIcon} alt="User Icon" /> */}
                                        {/* <XMLViewer xml={xmlContent} /> */}

                                    </div>
                                    <p style={{ textAlign: "center", wordWrap: "break-word" }}>{localStorage.getItem("fileName")}</p>


                                    {enableNarrative ?
                                        <>
                                            <hr></hr>
                                            <p style={{ textAlign: "center", display: "flex", justifyContent: "center", alignItems: "center", color: "#3368CE", fontSize: "15px", color: "#003152", cursor: "pointer", fontWeight: 600 }} onClick={openPopup}><span style={{ marginRight: "10px" }}>
                                                <img src={Eye_blue} alt="User Icon" height="25px" width="25px" /></span>View Narrative</p>
                                        </> : <></>

                                    }


                                </div>


                            </div>
                            <div style={{ display: "flex", flexDirection: "column", marginTop: "10px" }}>
                                <button className='active-button' style={{ marginBottom: "10px", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", cursor: "pointer" }}
                                    onClick={onAnalyzeClick}
                                >
                                    <img src={ChartDonut} alt="User Icon" /><span style={{ marginLeft: "8px" }} onClick={goToAcknowledge}>Acknowledge</span>
                                </button>
                                <button className='border-button' style={{ cursor: "pointer" }} onClick={openNewTab}>XML Viewer</button>
                            </div>
                        </> : <></>}


                </div>

                {
                    // fileName != "" && enableNarrative !== false ?
                    enableNarrative !== false ?

                        // !fileName ?
                        <div className="half">
                            <ProgressSteps uploadColor="rgba(41, 188, 118, 1)" width="98%" analyzeColor="rgba(41, 188, 118, 1)" viewColor="rgba(51, 104, 206, 1)" successStatus={true} successAnalyzeStatus={true}
                                onNavigate={uploadNavigate} cursor={true}
                                // analyzeOnclick={analyzeOnClick} 
                                entityOnclick={goToEntity}
                                codingOnclick={goToNarrative}
                                outputOnclick={goToSnomed}
                            />
                            {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li className="nav-item document-border-tab1">
                                    <a className="nav-link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true" onClick={goToEntity}>Entity Extraction</a>
                                </li>
                                <li className="nav-item document-border-tab2">
                                    <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={goToSnowmed}>Snomed to MedDra</a>
                                </li>
                                <li className="nav-item document-border-tab3">
                                    <a className="nav-link active" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Translate</a>
                                </li>
                            </ul> */}
                            {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li className="nav-item document-border-tab1">
                                    <a className="nav-link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Entity Extraction</a>
                                </li>
                                <li className="nav-item document-border-tab2">
                                    <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Snomed to MedDra</a>
                                </li>
                                <li className="nav-item document-border-tab3">
                                    <a className="nav-link active" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Translate</a>
                                </li>
                            </ul> */}
                            <div>

                                <div style={{ display: "flex", marginBottom: "20px" }}>
                                    <div style={{ height: "20px", display: "flex", alignItems: "center", width: "50%" }}>
                                        <Select

                                            options={llmOptions}
                                            // menuIsOpen={open}
                                            className='fullWidth'
                                            placeholder="Select by Medium"
                                        />
                                    </div>
                                    <div style={{ width: "50%", marginTop: "-9px", display: "flex", justifyContent: "flex-end" }}>
                                        {open &&

                                            <Select

                                                options={envOptions}

                                                value={envType}

                                                onChange={getEnvType}
                                                styles={customStylesFiltered}
                                                placeholder="Filter by"
                                                menuIsOpen={open}

                                            />}

                                        <img src={refreshIcon} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => refresh()} height="30px" width="30px" alt="User Icon" />
                                        <img src={funnelSimple} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => setOpen(!open)} height="30px" width="30px" alt="User Icon" />


                                        <img src={downloadSimple} style={{ marginTop: "-6px", cursor: "pointer" }} height="30px" width="30px" alt="User Icon" />


                                    </div>



                                </div>


                                <div className='Dcap-tableWrap'>
                                    <div style={{ marginBottom: "10px" }}>
                                        {conditionalRendering(dropdownSelectedValue)}


                                    </div>

                                    <DataTable
                                        customStyles={customStyles}
                                        columns={columns}
                                        // data={APIResponse}
                                        data={dropdownStatus ? filteredData : APIResponse}
                                        // conditionalRowStyles={conditionalRowStyles}
                                        pagination
                                    />

                                </div>





                            </div>

                            {isPopupVisible && (
                                <div className="popup">
                                    <div className="popup-content">
                                        {/* Your popup content here */}
                                        <div className='narrative'>
                                            <p style={{
                                                color: "#003152",
                                                fontSize: "18px",
                                                fontWeight: 600,
                                                textAlign: "center"
                                            }}>Narrative Data</p>
                                            {/* <div><button className='button-popup' onClick={closePopup}><FontAwesomeIcon icon={faTimes} /></button></div> */}
                                            <div style={{
                                                border: "1px solid lightgrey",
                                                borderRadius: "4px",
                                                marginTop: "25px"
                                            }}>
                                                <p style={{ padding: "0px 10px 10px 10px", fontSize: "14px", lineHeight: "25px" }}>
                                                    Pt is 87 yo woman, highschool teacher with past medical history that includes
                                                    - status post cardiac catheterization in April 2019.
                                                    She presents today with palpitations and chest pressure.
                                                    HPI : Sleeping trouble on present dosage of Clonidine. Severe Rash  on face and leg, slightly itchy.
                                                    Meds : Vyvanse 50 mgs po at breakfast daily,
                                                    Clonidine 0.2 mgs -- 1 and 1 / 2 tabs po qhs
                                                    HEENT : Boggy inferior turbinates, No oropharyngeal lesion.
                                                    Lungs : clear.
                                                    Heart : Regular rhythm.
                                                    Skin :  Mild erythematous eruption to hairline.

                                                    Follow-up as scheduled
                                                </p>
                                                {/* <p >This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.

                                                    Drugs and latency:
                                                    1. covid-19 vaccin pfizer orig/omic ba.1 injvlst
                                                    chills: 10 hours after start
                                                    headache: 10 hours after start
                                                    nausea: 10 hours after start
                                                    myalgia: 3 hours after start
                                                    malaise: 5 hours after start
                                                    fatigue: 10 hours after start
                                                    generalized joint pain: 6 hours after start
                                                    injection site warmth: 1 days after start
                                                    injection site pain: 1 days after start
                                                    injection site swelling: 1 days after start
                                                    injection site inflammation: 1 days after start
                                                    hyperpyrexia: 10 hours after start



                                                    Past drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml</p> */}
                                            </div>

                                            <button className='button-popup' onClick={closePopup}><FontAwesomeIcon icon={faTimes} /></button>
                                        </div>

                                    </div>
                                </div>
                            )}

                        </div> :
                        <>
                            <div className="half">

                                {/* <div style={{ margin:"10px" }}> */}
                                <ProgressSteps uploadColor="rgba(41, 188, 118, 1)" entityColor="rgba(136, 136, 136, 1)" outputColor="rgba(136, 136, 136, 1)" analyzeColor="rgba(51, 104, 206, 1)" viewColor="rgba(136, 136, 136, 1)" successStatus={true}
                                    onNavigate={uploadNavigate} cursor={true}
                                    // analyzeOnclick={analyzeOnClick} 
                                    entityOnclick={goToEntity}
                                    codingOnclick={goToNarrative}
                                    outputOnclick={goToSnomed}
                                />
                                {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                    <li className="nav-item document-border-tab1">
                                        <a className="nav-link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true" onClick={goToEntity}>Entity Extraction</a>
                                    </li>
                                    <li className="nav-item document-border-tab2">
                                        <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={goToSnowmed}>Snomed to MedDra</a>
                                    </li>
                                    <li className="nav-item document-border-tab3">
                                        <a className="nav-link active" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Translate</a>
                                    </li>
                                </ul> */}
                                <div className="col-12 pl-0 pr-0" style={{ display: "flex", flexDirection: "row" }}>

                                    <div className="col-6 pl-0 pr-0" style={{ width: "100%", border: "1px solid lightgrey", borderRadius: "4px" }}>
                                        <div style={{
                                            margin: "10px",
                                            fontSize: "16px",
                                            fontWeight: 600,
                                        }}>Input</div>
                                        <hr></hr>
                                        <div style={{ padding: "10px" }}> <XMLViewer
                                            xml={JSON.parse(localStorage.getItem("xmlContent"))}
                                        // theme ={customTheme}
                                        /></div>

                                    </div>
                                    <div className="col-6 pl-0 pr-0" style={{ marginRight: "30px", marginLeft: "5px", width: "100%", border: "1px solid lightgrey", borderRadius: "4px" }}>
                                        <div style={{
                                            margin: "10px",
                                            fontSize: "16px",
                                            fontWeight: 600,
                                        }}>Translated Data</div>
                                        <hr></hr>
                                        <div style={{ padding: "10px" }}>
                                            {/* <XMLViewer
                                            xml={JSON.parse(localStorage.getItem("xmlContent"))}
                                        // theme ={customTheme}
                                        /> */}

                                            <p>Tag: icsreport, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: ichicsrmessageheader, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: messagesenderidentifier, Original Text: EVNETHERLANDS, Detected Language: en, Translated Text: EVNETHERLANDS
                                                Tag: messagereceiveridentifier, Original Text: PFIZERINC, Detected Language: en, Translated Text: PFIZERINC
                                                Tag: messagecreationdate, Original Text: 20221015170042+0200, Detected Language: en, Translated Text: 20221015170042+0200
                                                Tag: safetyreport, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: safetyreportid, Original Text: NL-LRB-00839381, Detected Language: mt, Translated Text: NL-LRB-00839381
                                                Tag: transmissiondater3, Original Text: 20221015000000, Detected Language: en, Translated Text: 20221015000000
                                                Tag: reporttype, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: receivedater3, Original Text: 20221015000000+0200, Detected Language: en, Translated Text: 20221015000000+0200
                                                Tag: receiptdater3, Original Text: 20221015000000+0200, Detected Language: en, Translated Text: 20221015000000+0200
                                                Tag: additionaldocumentr3, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: companynumb, Original Text: NL-LRB-00839381, Detected Language: mt, Translated Text: NL-LRB-00839381
                                                Tag: casesendertype, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: duplicater3, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: primarysource, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reportercountryr3, Original Text: NL, Detected Language: en, Translated Text: NL
                                                Tag: qualificationr3, Original Text: 5, Detected Language: en, Translated Text: 5
                                                Tag: primarysourceregpurpose, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: sender, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: sendertype, Original Text: 2, Detected Language: en, Translated Text: 2
                                                Tag: senderorganization, Original Text: CBGMEB, Detected Language: en, Translated Text: CBGMEB
                                                Tag: patient, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: patientonsetage, Original Text: 21, Detected Language: en, Translated Text: 21
                                                Tag: patientonsetageunitr3, Original Text: a, Detected Language: en, Translated Text: a
                                                Tag: patientweight, Original Text: 80, Detected Language: en, Translated Text: 80
                                                Tag: patientheight, Original Text: 176, Detected Language: en, Translated Text: 176
                                                Tag: patientsexr3, Original Text: 2, Detected Language: en, Translated Text: 2
                                                Tag: patientpastdrugtherapy, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: patientdrugname, Original Text: AstraZeneca vaccin (Vaxzevria), Detected Language: fr, Translated Text: AstraZeneca vaccin (Vaxzevria)
                                                Tag: patientinventedname, Original Text: COVID-19 VACCIN ASTRAZENECA INJVLST, Detected Language: en, Translated Text: COVID-19 VACCIN ASTRAZENECA INJVLST
                                                Tag: patientdrugstartdater3, Original Text: 20210515, Detected Language: en, Translated Text: 20210515
                                                Tag: patientpastdrugtherapy, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: patientdrugname, Original Text: AstraZeneca vaccin (Vaxzevria), Detected Language: fr, Translated Text: AstraZeneca vaccin (Vaxzevria)
                                                Tag: patientinventedname, Original Text: COVID-19 VACCIN ASTRAZENECA INJVLST, Detected Language: en, Translated Text: COVID-19 VACCIN ASTRAZENECA INJVLST
                                                Tag: patientdrugstartdater3, Original Text: 20210227, Detected Language: en, Translated Text: 20210227
                                                Tag: patientpastdrugtherapy, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: patientdrugname, Original Text: BioNTech/Pfizer vaccin (Comirnaty), Detected Language: en, Translated Text: BioNTech/Pfizer vaccin (Comirnaty)
                                                Tag: patientinventedname, Original Text: COVID-19 VACCIN PFIZER INJVLST 0,3ML, Detected Language: en, Translated Text: COVID-19 VACCIN PFIZER INJVLST 0,3ML
                                                Tag: patientdrugstartdater3, Original Text: 20211125, Detected Language: en, Translated Text: 20211125
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 93911da3-d45a-37f5-9cfb-37e9a5e47b5c, Detected Language: en, Translated Text: 93911da3-d45a-37f5-9cfb-37e9a5e47b5c
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Vermoeidheid, Detected Language: en, Translated Text: Vermoeidheid
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10016256, Detected Language: en, Translated Text: 10016256
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 17063330-1f4d-3f65-a779-0d9fe0656afa, Detected Language: en, Translated Text: 17063330-1f4d-3f65-a779-0d9fe0656afa
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Hoofdpijn, Detected Language: nl, Translated Text: Headache
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10019211, Detected Language: en, Translated Text: 10019211
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 12d5a6e3-5663-3673-9e32-c6b2603debd2, Detected Language: en, Translated Text: 12d5a6e3-5663-3673-9e32-c6b2603debd2
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Ontstekingsreactie op de reactieplaats: warmte, pijn, zwelling, ontstaan binnen een week na de vaccinatie, Detected Language: nl, Translated Text: Inflammatory reaction at the reaction site: warmth, pain, swelling, occurring within a week after vaccination
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10022078, Detected Language: en, Translated Text: 10022078
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: f13ace24-7576-327f-92e9-f0ac6ae1dc0e, Detected Language: en, Translated Text: f13ace24-7576-327f-92e9-f0ac6ae1dc0e
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Reactie op of rond de injectieplaats: pijn, Detected Language: nl, Translated Text: Reaction at or around the injection site: pain
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10022086, Detected Language: en, Translated Text: 10022086
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 3041bc18-a9b9-3a6d-a7c6-5ef86fb58967, Detected Language: en, Translated Text: 3041bc18-a9b9-3a6d-a7c6-5ef86fb58967
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Reactie op of rond de injectieplaats: zwelling, ontstaan binnen een week na de vaccinatie, Detected Language: nl, Translated Text: Reaction at or around the injection site: swelling, occurring within a week after vaccination
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10053425, Detected Language: en, Translated Text: 10053425
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: cbcb3a73-b636-36b1-92df-6ffccbd5eb44, Detected Language: en, Translated Text: cbcb3a73-b636-36b1-92df-6ffccbd5eb44
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Koorts: 40.5 tot en met 42 graden Celcius, Detected Language: nl, Translated Text: Fever: 40.5 to 42 degrees Celsius
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10020741, Detected Language: en, Translated Text: 10020741
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 2, Detected Language: en, Translated Text: 2
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: cf7ead4c-e51e-3cf9-b6f4-54ccb72b55d7, Detected Language: en, Translated Text: cf7ead4c-e51e-3cf9-b6f4-54ccb72b55d7
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Pijn in de gewrichten, Detected Language: nl, Translated Text: Pain in the joints
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10062438, Detected Language: en, Translated Text: 10062438
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 31ee05f6-5ffb-3c55-b4d4-c3d4cb24e41e, Detected Language: en, Translated Text: 31ee05f6-5ffb-3c55-b4d4-c3d4cb24e41e
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Spierpijn, Detected Language: nl, Translated Text: muscle strain
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10028411, Detected Language: en, Translated Text: 10028411
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 2, Detected Language: en, Translated Text: 2
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 9287920e-4771-36ce-846e-88a33bd86a35, Detected Language: en, Translated Text: 9287920e-4771-36ce-846e-88a33bd86a35
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Reactie op of rond de injectieplaats: warmte, Detected Language: nl, Translated Text: Reaction at or around the injection site: warmth
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10022112, Detected Language: en, Translated Text: 10022112
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 14b9c8cc-2758-380f-9bd1-8714cc1848f4, Detected Language: en, Translated Text: 14b9c8cc-2758-380f-9bd1-8714cc1848f4
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Misselijkheid, Detected Language: nl, Translated Text: Nausea
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10028813, Detected Language: en, Translated Text: 10028813
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 2, Detected Language: en, Translated Text: 2
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: 939db665-f91c-3f8c-9764-ef544640fa7d, Detected Language: en, Translated Text: 939db665-f91c-3f8c-9764-ef544640fa7d
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Niet lekker voelen, Detected Language: nl, Translated Text: Not feeling well
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10025482, Detected Language: en, Translated Text: 10025482
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: reaction, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: reactionuniversallyuniqueid, Original Text: a306a076-26bd-3ed0-9836-6efadec556a0, Detected Language: en, Translated Text: a306a076-26bd-3ed0-9836-6efadec556a0
                                                Tag: primarysrcreactreportedlang, Original Text: nld, Detected Language: en, Translated Text: nld
                                                Tag: primarysrcreactinnativelang, Original Text: Koude rillingen, Detected Language: nl, Translated Text: Cold shivers
                                                Tag: reactionmeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: reactionmeddrallt, Original Text: 10008531, Detected Language: en, Translated Text: 10008531
                                                Tag: seriousnessdeath, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesslifethreatening, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesshospitalization, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessdisabling, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnesscongenitalanomali, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: seriousnessother, Original Text: [NI], Detected Language: en, Translated Text: [NI]
                                                Tag: reactionoutcome, Original Text: 2, Detected Language: en, Translated Text: 2
                                                Tag: medicallyconfirm, Original Text: false, Detected Language: en, Translated Text: false
                                                Tag: test, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: testdater3, Original Text: 20221015, Detected Language: en, Translated Text: 20221015
                                                Tag: testname, Original Text: hyperpyrexia, Detected Language: en, Translated Text: hyperpyrexia
                                                Tag: testnamemeddraversionllt, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: testnamellt, Original Text: 10020741, Detected Language: en, Translated Text: 10020741
                                                Tag: testresulttext, Original Text: Koorts: 40.5 tot en met 42 graden Celcius, Detected Language: nl, Translated Text: Fever: 40.5 to 42 degrees Celsius
                                                Tag: drug, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: druguniversallyuniqueid, Original Text: a7cd6ffa-7b3f-3480-9d74-95353eb961e1, Detected Language: en, Translated Text: a7cd6ffa-7b3f-3480-9d74-95353eb961e1
                                                Tag: drugcharacterization, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: medicinalproduct, Original Text: COVID-19 VACCIN PFIZER ORIG/OMIC BA.1 INJVLST / COVID-19 VACCIN PFIZER ORIG/OMICRON BA.1 INJ 0,3ML, Detected Language: sl, Translated Text: COVID-19 VACCIN PFIZER ORIG/OMIC BA.1 INJVLST / COVID-19 VACCIN PFIZER ORIG/OMICRON BA.1 INJ 0,3ML
                                                Tag: druginventedname, Original Text: COVID-19 VACCIN PFIZER ORIG/OMICRON BA.1 INJ 0,3ML, Detected Language: en, Translated Text: COVID-19 VACCIN PFIZER ORIG/OMICRON BA.1 INJ 0,3ML
                                                Tag: drugscientificname, Original Text: COVID-19 VACCIN PFIZER ORIG/OMIC BA.1 INJVLST, Detected Language: en, Translated Text: COVID-19 VACCIN PFIZER ORIG/OMIC BA.1 INJVLST
                                                Tag: actiondrug, Original Text: 9, Detected Language: en, Translated Text: 9
                                                Tag: dosageinformation, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: drugstructuredosagenumb, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: drugstructuredosageunit, Original Text: DF, Detected Language: en, Translated Text: DF
                                                Tag: drugstartdate, Original Text: 20221014, Detected Language: en, Translated Text: 20221014
                                                Tag: drugbatchnumb, Original Text: [ASKU], Detected Language: fi, Translated Text: [ASKU]
                                                Tag: drugindicationr3, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: drugindicationprimarysource, Original Text: COVID-19 vaccinatie, Detected Language: es, Translated Text: COVID-19 vaccination
                                                Tag: drugindicationmeddraversion, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: drugindicationmeddracode, Original Text: 10084457, Detected Language: en, Translated Text: 10084457
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 93911da3-d45a-37f5-9cfb-37e9a5e47b5c, Detected Language: en, Translated Text: 93911da3-d45a-37f5-9cfb-37e9a5e47b5c
                                                Tag: drugstartperiod, Original Text: 10, Detected Language: en, Translated Text: 10
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 17063330-1f4d-3f65-a779-0d9fe0656afa, Detected Language: en, Translated Text: 17063330-1f4d-3f65-a779-0d9fe0656afa
                                                Tag: drugstartperiod, Original Text: 10, Detected Language: en, Translated Text: 10
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 12d5a6e3-5663-3673-9e32-c6b2603debd2, Detected Language: en, Translated Text: 12d5a6e3-5663-3673-9e32-c6b2603debd2
                                                Tag: drugstartperiod, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: drugstartperiodunit, Original Text: d, Detected Language: en, Translated Text: d
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: f13ace24-7576-327f-92e9-f0ac6ae1dc0e, Detected Language: en, Translated Text: f13ace24-7576-327f-92e9-f0ac6ae1dc0e
                                                Tag: drugstartperiod, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: drugstartperiodunit, Original Text: d, Detected Language: en, Translated Text: d
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 3041bc18-a9b9-3a6d-a7c6-5ef86fb58967, Detected Language: en, Translated Text: 3041bc18-a9b9-3a6d-a7c6-5ef86fb58967
                                                Tag: drugstartperiod, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: drugstartperiodunit, Original Text: d, Detected Language: en, Translated Text: d
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: cbcb3a73-b636-36b1-92df-6ffccbd5eb44, Detected Language: en, Translated Text: cbcb3a73-b636-36b1-92df-6ffccbd5eb44
                                                Tag: drugstartperiod, Original Text: 10, Detected Language: en, Translated Text: 10
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: cf7ead4c-e51e-3cf9-b6f4-54ccb72b55d7, Detected Language: en, Translated Text: cf7ead4c-e51e-3cf9-b6f4-54ccb72b55d7
                                                Tag: drugstartperiod, Original Text: 6, Detected Language: en, Translated Text: 6
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 31ee05f6-5ffb-3c55-b4d4-c3d4cb24e41e, Detected Language: en, Translated Text: 31ee05f6-5ffb-3c55-b4d4-c3d4cb24e41e
                                                Tag: drugstartperiod, Original Text: 3, Detected Language: en, Translated Text: 3
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 9287920e-4771-36ce-846e-88a33bd86a35, Detected Language: en, Translated Text: 9287920e-4771-36ce-846e-88a33bd86a35
                                                Tag: drugstartperiod, Original Text: 1, Detected Language: en, Translated Text: 1
                                                Tag: drugstartperiodunit, Original Text: d, Detected Language: en, Translated Text: d
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 14b9c8cc-2758-380f-9bd1-8714cc1848f4, Detected Language: en, Translated Text: 14b9c8cc-2758-380f-9bd1-8714cc1848f4
                                                Tag: drugstartperiod, Original Text: 10, Detected Language: en, Translated Text: 10
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: 939db665-f91c-3f8c-9764-ef544640fa7d, Detected Language: en, Translated Text: 939db665-f91c-3f8c-9764-ef544640fa7d
                                                Tag: drugstartperiod, Original Text: 5, Detected Language: en, Translated Text: 5
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: drugeventmatrix, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: eventuniversallyuniqueid, Original Text: a306a076-26bd-3ed0-9836-6efadec556a0, Detected Language: en, Translated Text: a306a076-26bd-3ed0-9836-6efadec556a0
                                                Tag: drugstartperiod, Original Text: 10, Detected Language: en, Translated Text: 10
                                                Tag: drugstartperiodunit, Original Text: h, Detected Language: en, Translated Text: h
                                                Tag: summary, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: narrativeincludeclinical, Original Text: This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.

                                                Drugs and latency:
                                                1. covid-19 vaccin pfizer orig/omic ba.1 injvlst
                                                chills: 10 hours after start
                                                headache: 10 hours after start
                                                nausea: 10 hours after start
                                                myalgia: 3 hours after start
                                                malaise: 5 hours after start
                                                fatigue: 10 hours after start
                                                generalized joint pain: 6 hours after start
                                                injection site warmth: 1 days after start
                                                injection site pain: 1 days after start
                                                injection site swelling: 1 days after start
                                                injection site inflammation: 1 days after start
                                                hyperpyrexia: 10 hours after start




                                                Past drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml, Detected Language: en, Translated Text: This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.

                                                Drugs and latency:
                                                1. covid-19 vaccin pfizer orig/omic ba.1 injvlst
                                                chills: 10 hours after start
                                                headache: 10 hours after start
                                                nausea: 10 hours after start
                                                myalgia: 3 hours after start
                                                malaise: 5 hours after start
                                                fatigue: 10 hours after start
                                                generalized joint pain: 6 hours after start
                                                injection site warmth: 1 days after start
                                                injection site pain: 1 days after start
                                                injection site swelling: 1 days after start
                                                injection site inflammation: 1 days after start
                                                hyperpyrexia: 10 hours after start




                                                Past drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml
                                                Tag: senderdiagnosisinfo, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: senderdiagnosismeddraversion, Original Text: 25.0, Detected Language: en, Translated Text: 25.0
                                                Tag: senderdiagnosismeddracode, Original Text: 10022078, Detected Language: en, Translated Text: 10022078
                                                Tag: casesummarynarrative, Original Text:
                                                , Detected Language: en, Translated Text:

                                                Tag: casesummary, Original Text: ---------- Vierde coronavaccinatie ----------------------
                                                Injection moment: Vierde coronavaccinatie

                                                ---------- Medication ----------------------
                                                concomitant medication: no

                                                ---------- Roodheid or Zwelling ----------------------
                                                Extensive swelling of vaccinated limb: no

                                                ----------  ----------------------
                                                BSN available: yes

                                                ---------- COVID19 ----------------------
                                                Previous COVID-19 infection: No, Detected Language: en, Translated Text: ---------- Vierde coronavaccinatie ----------------------
                                                Injection moment: Vierde coronavaccinatie

                                                ---------- Medication ----------------------
                                                concomitant medication: no

                                                ---------- Roodheid or Zwelling ----------------------
                                                Extensive swelling of vaccinated limb: no

                                                ----------  ----------------------
                                                BSN available: yes

                                                ---------- COVID19 ----------------------
                                                Previous COVID-19 infection: No</p>

                                        </div>

                                    </div>

                                </div>
                                {/* <button className='active-button' style={{ cursor: "pointer", float: "right", marginTop: "15px" }} onClick={goToAcknowledge}>Acknowledge</button> */}

                                {/* </div> */}

                                {/* </div> */}

                            </div>
                        </>


                }

            </div>
            <ModalPopUpTable
                getData={onViewOutputClick}
                openModal={isModalOpen}
                popupWidth={"600px"}
                buttonTop={"4px"}
                close={closeModal}
                type="info"
            />
            {/* </LoadingOverlay> */}
        </>

    );
}

export default TranslateCompare;
