import React, { useRef, useEffect } from 'react';
import Navbar from '../Navbar';
import ProgressSteps from '../../common/ProgressSteps';
import upload from '../../assets/upload.svg';
import './XMLLoader.css';
import { useNavigate } from 'react-router-dom';
import axios from "axios";
import { toast } from 'react-toastify';
import {uploadEndpoint} from '../../common/api-config';


function UploadFile() {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);


  const handleFileClick = () => {
    fileInputRef.current.click();
  };

  useEffect(() => {
    localStorage.removeItem("fileName")
    localStorage.removeItem("xmlContent")
    localStorage.removeItem("narrativeString")
  },[])
  


  const handleFileUpload =(event) => {

    const file = event.target.files[0];
    const formData = new FormData();
    formData.append('file', file);
    try {
      axios.post(uploadEndpoint(), formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }).then((response) => { 
        console.log("response,", response)
        if(response?.data?.length > 0){
          localStorage.setItem("fileName", file.name)
          if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
              localStorage.setItem("xmlContent", JSON.stringify(e.target.result))
            };
            reader.readAsText(file);
          }
          localStorage.setItem("narrativeString", response?.data[0])
          toast.success("File uploaded successfully", { position: toast.POSITION.TOP_CENTER });
          navigate('/translate');

  
        }else{
  
          toast.error("File upload failed", { position: toast.POSITION.TOP_CENTER });
  
        }          
    })
     
      
    } catch (error) {
      console.error('Error uploading file:', error);
    }
   

  };

  return (
    <>
      <Navbar />
      <div className="upload-container">
        <ProgressSteps uploadColor="rgba(51, 104, 206, 1)"  entityColor="rgba(136, 136, 136, 1)" outputColor="rgba(136, 136, 136, 1)" marginTop="40px" width="75%"analyzeColor="rgba(136, 136, 136, 1)" viewColor="rgba(136, 136, 136, 1)" />
        <div
          className="upload-box"
          onClick={handleFileClick}
        >
          <div style={{ marginBottom: "10px", fontSize: "24px", fontWeight: 600 }}>Drag & Drop file here</div>
          <div style={{ marginBottom: "20px", fontSize: "20px", fontWeight: 500 }}>OR</div>
          <img src={upload} alt="upload" height="80px" />
          <div style={{ marginTop: "20px", fontSize: "20px", fontWeight: 500, color: "gray" }}>Please select XML File</div>
          {/* <div className="mt-1">PDFs, Notes, Text Files, JPEG, JPG & PNG</div> */}
          <input
            type="file"
            ref={fileInputRef}
            style={{ display: 'none' }}
            accept=".xml"
            onChange={handleFileUpload}
          />
        </div>
      </div>
    </>
  );
}

export default UploadFile;
