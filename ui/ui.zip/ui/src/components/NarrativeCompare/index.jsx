import React, { useState } from 'react';
import Navbar from '../../components/Navbar';
import { useNavigate } from 'react-router-dom';
import edit from '../../assets/project_edit.svg';
import ProgressSteps from '../../common/ProgressSteps';
import backArrow from '../../assets/backarrow.svg';
import ChartDonut from "../../assets/ChartDonut.svg";
import XMLIcon from "../../assets/XML_icon.svg";
import Eye_blue from "../../assets/Eye_blue.svg";
import './narrativeCompare.css';


const NarrativeCompare = () => {
    const navigate = useNavigate();
    const [narrativeStatus, setNarrativeStatus] = useState(false)
    // const [editGenerateNarrative, setEditGenerateNarrative] = useState("")
    const [editGenerateNarrative, setEditGenerateNarrative] = useState("");
    const [generatedNarrative, setGeneratedNarrative] = useState(
        `This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.`
    );

    const toggleEdit = () => {
        setEditGenerateNarrative(prevState => !prevState);
    };

    const handleInputChange = (event) => {
        setGeneratedNarrative(event.target.value);
    };



    const uploadNavigate = () => {
        navigate('/upload')
    }
    const translateOnclick = () => {
        navigate('/translate')
    }
    const entityOnclick = () => {
        navigate('/documentAnalyzeN')
    }
    const goToSnomed = () => {
        navigate('/analyze')
    }
    const onNarrativeSelect = () => {
        setNarrativeStatus(true)
    }
    const onNarrativeCompare = () => {
        setNarrativeStatus(false)
    }
    const editNarrative = (type) => {
        setEditGenerateNarrative(type)
    }
    return (
        <div className='narrative-container'>
            <Navbar />
            <div className='d-flex flex-column col-12 pl-0 pr-0 '>
                <div className="d-flex narrative-row align-items-center mt-2 pl-3">
                    <img src={backArrow} alt="img" />
                    <div className='ml-3'>Translate</div>
                </div>
                <div className='d-flex narrative-row m-3'>
                    <div className="first-half" style={{ border: "1px solid lightgrey", borderRadius: "4px" }}>
                        {localStorage.getItem("fileName") != "" ?
                            <>
                                <div style={{ marginTop: "10px" }}>
                                    <div style={{ border: "1px solid lightgrey", borderRadius: "8px", padding: "12px" }}>
                                        <div style={{ textAlign: "center" }}>
                                            <img src={XMLIcon} alt="User Icon" height="130px" />
                                        </div>
                                        <p style={{ textAlign: "center", wordWrap: "break-word" }}>{localStorage.getItem("fileName")}</p>
                                        <hr></hr>
                                        <p style={{ textAlign: "center", display: "flex", justifyContent: "center", alignItems: "center", color: "#3368CE", fontSize: "15px", color: "#003152", cursor: "pointer", fontWeight: 600 }} ><span style={{ marginRight: "10px" }}>
                                            <img src={Eye_blue} alt="User Icon" height="25px" width="25px" /></span>View Narrative</p>
                                    </div>
                                </div>
                                <div style={{ display: "flex", flexDirection: "column", marginTop: "10px" }}>
                                    <button className='active-button' style={{ marginBottom: "10px", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", cursor: "pointer" }}
                                    // onClick={onAnalyzeClick}
                                    >
                                        {/* <img src={ChartDonut} alt="User Icon" /> */}
                                        <span style={{ marginLeft: "8px" }} >Generate Narrative</span>
                                    </button>
                                    <button className='border-button' style={{ cursor: "pointer" }}>XML Viewer</button>
                                </div>
                            </> : <></>}
                    </div>
                    <div className='narrative-part2 ml-3'>
                        <div>
                        <ProgressSteps marginBottom="20px" 
                        uploadColor="rgba(41, 188, 118, 1)" 
                        outputColor="rgba(51, 104, 206, 1)" 
                        entityColor="rgba(41, 188, 118, 1)" 
                        analyzeColor="rgba(41, 188, 118, 1)" 
                        viewColor="rgba(41, 188, 118, 1)" 
                        successStatus={true} analyzeOnclick={translateOnclick} entityOnclick={entityOnclick} onNavigate={uploadNavigate} 

                        outputOnclick ={goToSnomed}
                        cursor={true} successAnalyzeStatus={true} entityStatus={true} codeStatus ={true} />
                        </div>
                        <div>
                            <div className='d-flex compare-row justify-content-between'>
                                <div>
                                    <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                        <li className="nav-item document-border-tab1">
                                            <a className="nav-link active" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={onNarrativeCompare}>Narrative Compare</a>
                                        </li>
                                        <li className="nav-item document-border-tab3">
                                            <a className="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false" onClick={onNarrativeSelect}>Narrative Review</a>
                                        </li>
                                    </ul>
                                </div>
                                {
                                    narrativeStatus
                                        ? <div>
                                            <ul class="nav justify-content-end">
                                                <li class="nav-item">
                                                    <button class="border-button" id="button1">Save</button>
                                                </li>
                                                <li class="nav-item">
                                                    <button class="active-button ml-2" id="button2">Submit</button>
                                                </li>
                                            </ul>
                                        </div>
                                        : <></>
                                }

                            </div>
                            <div className="tab-content mt-3" id="pills-tabContent">
                                <div className="tab-pane fade show active " id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
                                    <div className='d-flex compare-row'>
                                        <div className='container1-compare mr-4 p-3 bg-white' style={{ border: "1px solid lightgrey" }}>
                                            <div className='mb-2  d-flex flex-wrap'>Submitted Narrative</div>
                                            <hr className='mb-0 mt-0' />
                                            <p className='mt-2 d-flex flex-wrap'>
                                            This is a spontaneous report received from a contactable reporter(s) (Consumer or other non HCP) from the European Medicines Agency (EMA) EudraVigilance-WEB. Regulatory number: NL-LRB-00840427 (LRB).

 

A 66-year-old male patient received BNT162b2 (COMIRNATY), on 03Jan2022 as dose 3 (booster), single (Batch/Lot number: unknown) for covid-19 immunisation. The patient's relevant medical history included: "COVID-19", start date: 15Mar2021 (not ongoing), notes: hospitalization: no. There were no concomitant medications. Vaccination history included: spikevax (DOSE 1, SINGLE), administration date: 05Mar2021, for Covid-19 immunisation; vaxzevria(DOSE 2, SINGLE), administration date: 31May2021, for Covid-19 immunisation.

The following information was reported: INTERCHANGE OF VACCINE PRODUCTS (medically significant) with onset 03Jan2022, outcome "unknown"; PERICARDITIS (medically significant), 4 months after the suspect product(s) administration, outcome "recovered"; POLYMYALGIA RHEUMATICA (medically significant), 3 months after the suspect product(s) administration, outcome "not recovered"; BURSITIS (non-serious), 7 months after the suspect product(s) administration, outcome "not recovered", described as "Bursitis shoulder". The patient underwent the following laboratory tests and procedures: Body mass index: (unspecified date) 27.8kg/m^2.; SARS-CoV-2 test: (15Mar2021) Positive. Therapeutic measures were taken as a result ofpericarditis, polymyalgia rheumatica, bursitis.

 

Clinical course: Bursitis is treated with physiotherapy and a cortisone injection, pericarditis is treated with colchinine, and polymyalgia rheumatica is treated with prednisolon.  Onset latency reported with  third dose as polymyalgia rheumatica: 3 months after start, pericarditis: 4 months after start and bursitis: 7 months after start.

 

No follow-up attempts are possible; information about lot/batch number cannot be obtained. No further information is expected.
                                            </p>
                                            {/* <p className='mt-2  d-flex flex-wrap'>
                                                Drugs and latency:
                                                1. covid-19 vaccin pfizer orig/omic ba.1 injvlst
                                                chills: 10 hours after
                                                startheadache: 10 hours after
                                                startnausea: 10 hours after
                                                startmyalgia: 3 hours after start
                                                malaise: 5 hours after start
                                                fatigue: 10 hours after start
                                                generalized joint pain: 6 hours after start
                                                injection site warmth: 1 days after start
                                                injection site pain: 1 days after start
                                                injection site swelling: 1 days after start
                                                injection site inflammation: 1 days after start
                                                hyperpyrexia: 10 hours after start
                                            </p> */}
                                        </div>
                                        <div className='container1-compare ml-4 p-3 bg-white' style={{ border: "1px solid lightgrey" }}>
                                            <div className='mb-2 d-flex flex-wrap'>Generated Narrative</div>
                                            <hr className='mb-0 mt-0' />
                                            <p className='mt-2 d-flex flex-wrap'>
                                            This is a spontaneous report received from a contactable reporter (Consumer or other non-health professional) from the European Medicines Agency (EMA) EudraVigilance-WEB. Regulatory number: NL-LRB-00844197 (LRB).

 

A 66-year-old male patient received AstraZeneca vaccin (Vaxzevria), on 06Jul2021 as dose 3, single (Batch/Lot number: unknown) for COVID-19 immunization. The patient's relevant medical history included polymyalgia rheumatica, pericarditis, and bursitis. There were no concomitant medications. Vaccination history included: AstraZeneca vaccin (Dose 1, Single, Strength: 0.5 ml), administration date: 01Jun2021, for COVID-19 immunization.

 

The patient experienced polymyalgia rheumatica, pericarditis, and bursitis after receiving the vaccine. The events were reported as non-serious. The patient was treated with fysiotherapy and a cortisone injection for bursitis, colchinine for pericarditis, and prednisolon for polymyalgia rheumatica. The patient has not recovered from bursitis, polymyalgia rheumatica, and pericarditis.

 

Laboratory results included a blood test that could not find anything. Diagnostic procedures included a visit to the family doctor and a cortisone injection. No follow-up attempts are possible; information about the lot/batch number cannot be obtained.

 

No further information is expected.
                                            </p>
                                            {/* <p className='mt-2  d-flex flex-wrap'>
                                                Drugs and latency:
                                                1. covid-19 vaccin pfizer orig/omic ba.1 injvlst
                                                chills: 10 hours after
                                                startheadache: 10 hours after
                                                startnausea: 10 hours after
                                                startmyalgia: 3 hours after start
                                                malaise: 5 hours after start
                                                fatigue: 10 hours after start
                                                generalized joint pain: 6 hours after start
                                                injection site warmth: 1 days after start
                                                injection site pain: 1 days after start
                                                injection site swelling: 1 days after start
                                                injection site inflammation: 1 days after start
                                                hyperpyrexia: 10 hours after start
                                            </p> */}
                                        </div>
                                    </div>
                                </div>
                                <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
                                    <div className='d-flex compare-row'>
                                        <div className='container1-compare mr-4 p-3 bg-white' style={{ border: "1px solid lightgrey" }}>
                                            <div className='mb-2  d-flex flex-wrap'>Generate Narrative</div>
                                            <hr className='mb-0 mt-0' />
                                            <p className='mt-2 d-flex flex-wrap'>
                                            This is a spontaneous report received from a contactable reporter(s) (Consumer or other non HCP) from the European Medicines Agency (EMA) EudraVigilance-WEB. Regulatory number: NL-LRB-00840427 (LRB).

 

A 66-year-old male patient received BNT162b2 (COMIRNATY), on 03Jan2022 as dose 3 (booster), single (Batch/Lot number: unknown) for covid-19 immunisation. The patient's relevant medical history included: "COVID-19", start date: 15Mar2021 (not ongoing), notes: hospitalization: no. There were no concomitant medications. Vaccination history included: spikevax (DOSE 1, SINGLE), administration date: 05Mar2021, for Covid-19 immunisation; vaxzevria(DOSE 2, SINGLE), administration date: 31May2021, for Covid-19 immunisation.

The following information was reported: INTERCHANGE OF VACCINE PRODUCTS (medically significant) with onset 03Jan2022, outcome "unknown"; PERICARDITIS (medically significant), 4 months after the suspect product(s) administration, outcome "recovered"; POLYMYALGIA RHEUMATICA (medically significant), 3 months after the suspect product(s) administration, outcome "not recovered"; BURSITIS (non-serious), 7 months after the suspect product(s) administration, outcome "not recovered", described as "Bursitis shoulder". The patient underwent the following laboratory tests and procedures: Body mass index: (unspecified date) 27.8kg/m^2.; SARS-CoV-2 test: (15Mar2021) Positive. Therapeutic measures were taken as a result ofpericarditis, polymyalgia rheumatica, bursitis.

 

Clinical course: Bursitis is treated with physiotherapy and a cortisone injection, pericarditis is treated with colchinine, and polymyalgia rheumatica is treated with prednisolon.  Onset latency reported with  third dose as polymyalgia rheumatica: 3 months after start, pericarditis: 4 months after start and bursitis: 7 months after start.

 

No follow-up attempts are possible; information about lot/batch number cannot be obtained. No further information is expected.
                                            </p>
                                            {/* <p className='mt-2  d-flex flex-wrap'>
                                                Drugs and latency:
                                                1. covid-19 vaccin pfizer orig/omic ba.1 injvlst
                                                chills: 10 hours after
                                                startheadache: 10 hours after
                                                startnausea: 10 hours after
                                                startmyalgia: 3 hours after start
                                                malaise: 5 hours after start
                                                fatigue: 10 hours after start
                                                generalized joint pain: 6 hours after start
                                                injection site warmth: 1 days after start
                                                injection site pain: 1 days after start
                                                injection site swelling: 1 days after start
                                                injection site inflammation: 1 days after start
                                                hyperpyrexia: 10 hours after start
                                            </p> */}
                                        </div>
                                        <div className='container1-compare ml-4 p-3 bg-white' style={{ border: "1px solid lightgrey" }}>

                                            <div className='mb-2 d-flex compare-row justify-content-between align-itens-center flex-wrap'>
                                                <div>Submitted Narrative</div>
                                                <img src={edit} alt="edit" onClick={() => editNarrative("EditGenarateNarrative")} />
                                            </div>
                                            <hr className='mb-0 mt-0' />
                                            {
                                                editGenerateNarrative === "EditGenarateNarrative"
                                                    ?
                                                    <textarea
                                                        className='form-control'
                                                        style={{ height: "98%", width: "100%", resize: "vertical", border: "none" }}
                                                        value={generatedNarrative}
                                                        onChange={handleInputChange}
                                                        rows={5}
                                                    />
                                                    // <input 
                                                    // style={{height:"100%", width:"100%", display:"flex", flexWrap:"wrap"}}
                                                    // value={`This spontaneous report from a consumer or other non-health professional concerns a female aged Year, headache, nausea, myalgia, malaise, fatigue, generalized, joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.`}/>


                                                    : <>
                                                        <p className='mt-2 d-flex flex-wrap'>
                                                        This is a spontaneous report received from a contactable reporter (Consumer or other non-health professional) from the European Medicines Agency (EMA) EudraVigilance-WEB. Regulatory number: NL-LRB-00844197 (LRB).

 

A 66-year-old male patient received AstraZeneca vaccin (Vaxzevria), on 06Jul2021 as dose 3, single (Batch/Lot number: unknown) for COVID-19 immunization. The patient's relevant medical history included polymyalgia rheumatica, pericarditis, and bursitis. There were no concomitant medications. Vaccination history included: AstraZeneca vaccin (Dose 1, Single, Strength: 0.5 ml), administration date: 01Jun2021, for COVID-19 immunization.

 

The patient experienced polymyalgia rheumatica, pericarditis, and bursitis after receiving the vaccine. The events were reported as non-serious. The patient was treated with fysiotherapy and a cortisone injection for bursitis, colchinine for pericarditis, and prednisolon for polymyalgia rheumatica. The patient has not recovered from bursitis, polymyalgia rheumatica, and pericarditis.

 

Laboratory results included a blood test that could not find anything. Diagnostic procedures included a visit to the family doctor and a cortisone injection. No follow-up attempts are possible; information about the lot/batch number cannot be obtained.

 

No further information is expected.
                                                        </p>
                                                    </>
                                            }

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default NarrativeCompare;