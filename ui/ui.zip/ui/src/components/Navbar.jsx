import React, { useState } from 'react';
import "./Navbar.css";
import { useAuth } from '../components/AuthContext';
import Ellipse from "../assets/Ellipse.svg";
import signOut from "../assets/SignOut.svg";
import {ReactComponent as SVGDownArrow} from "../assets/DownArrow.svg";
// import Logo from "../assets/logo.svg";
import {Link } from "react-router-dom";
import Logo from "../assets/logo_pfizer.svg";
import { useNavigate } from 'react-router-dom';


function Navbar() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const handleCaretClick = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  const { logout } = useAuth();

  const handleLogout = () => {
    logout()
  }
  const goToSelect = () => {
    navigate("/select")
  }
  return (
    <div className="navbar">
    <div className="company-logo">
      <img src={Logo} alt="Company Logo" onClick={goToSelect}/><div className='logo-title'> ICSR Extraction Sandbox</div>
    </div>
    {/* <div className="company-name">
      <h2>Company Name</h2>
    </div> */}
    {/* <div className="user-account" style={{display:"flex", cursor:"pointer"}} onClick={() => handleLogout()}> */}
    <div className="user-account" style={{display:"flex", }}>
      <div style={{marginTop:"3px", marginRight:"5px"}}>{localStorage.getItem("email")}</div>
      <div><img src={Ellipse} alt="User Icon" />
      <img style={{marginLeft:"10px", cursor:"pointer"}} src={signOut} onClick={() => handleLogout()} alt="User Icon" />

      {/* <button className="caret-button" onClick={handleCaretClick}>
         
          <img src={caretIcon} alt="User Icon" />
        </button>
        {isDropdownOpen && (
          <div className="dropdown">
            <button onClick={() => handleLogout()}>Logout</button>
          </div>
        )} */}
      </div>
    </div>
  </div>
  );
}

export default Navbar;
