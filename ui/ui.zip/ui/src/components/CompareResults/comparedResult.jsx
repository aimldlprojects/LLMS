import React from 'react';
import './compareResults.css';
import Navbar from '../Navbar';
import DataTable from "react-data-table-component";
import backArrow from '../../assets/backarrow.svg';
import ProgressSteps from '../../common/ProgressSteps/multiFileProgress';

import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';

const ComparedResult = () => {

    const navigate = useNavigate()
    
    const [response, setResponse] = useState({})
    const progress = 70;
    const columns = [
        {
            name: "Processed Document",
            selector: row => row.processedFile,
            center: true,
            wrap: true
        },
        {
            name: "MedDRACode",
            selector: row => row.processed_meddraCount,
            center: true
        },
        {
            name: "Submitted Document",
            selector: row => row.submittedFile,
            center: true,
            wrap: true
        },
        {
            name: "MedDRA Code",
            selector: row => row.submitted_meddraCount,
            center: true
        },
        {
            name: "Comparision Metrics",
            selector: row => (
                <div>
                    <div className='d-flex flex-row justify-content-between p-2'>
                        <div>Matching Codes : {row.matchedFiles_count}</div>
                        {/* <div>{row.matchedFiles_count}</div> */}
                        {/* <div>{row.matchedFiles_count}+"/"+{row.total_count}</div> */}
                    </div>
                    {/* <div className="compare-progress-bar">
                        <div
                            className="progress"
                            style={{ width: `${progress}%`, backgroundColor: '#007bff' }}
                        ></div>
                    </div> */}
                </div>
            ),
            center: true
        },
    ]

useEffect(() => {
    const responseData = JSON.parse(localStorage.getItem("comparedResultData"))

    setResponse(responseData)


}, [response])




const data = [
    {
        "submittedFile":response && response[0],
        "processedFile":localStorage.getItem("processed_filepath"),
        "processedFiles_count": 1,
        "submittedFiles_count": 1,
        "processed_meddraCount":response && response[1],
        "submitted_meddraCount":response && response[2],
        "matchedFiles_count":response && response[3],
        "total_count": parseInt(response && response[1]) + parseInt(response && response[2])

        
    }
]
const customStyles = {

    rows: {

        style: {
            border: 'none',
            ':nth-of-type(even)': {
                backgroundColor: "rgba(245, 245, 245, 1)"
            },
            fontFamily: "Poppins !important",

            borderRadius: 8,
            marginTop: 8
        }
    },

    headCells: {
        style: {
            backgroundColor: "#394356",
            color: "#fff",
            fontFamily: "Poppins !important",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 600
        },

    },
    cells: {
        style: {
            color: "#000000",
            fontFamily: "Poppins",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 400
        },

    },
};

    const goToPrevious =()=>{
        navigate("/viewOutput")
    }

    const goToPath =()=>{
        navigate("/documentAnalyze")
    }
    const goToAnalyze =()=>{
        navigate("/analyzedDocument")
    }



    return (
        <>
            <Navbar />
            <div className='compare-container col-12 pd20'>
                {/* <div className="header-comapre">
                    <div className="header-content-compare justify-content-between align-items-center">
                        <div className='d-flex flex-row'>
                            <img src={backArrow} alt="img" />
                            <div className='heading-text text-style-nowrap'>Compare Results</div>
                        </div>
                    </div>
                </div> */}
                <div className="header-analyze">
                    <div className="header-content" style={{ justifyContent: "space-between", alignItems: "center" }}>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                            {/* <img src={backArrow} alt="img" />
                            <div style={{ marginLeft: "10px", whiteSpace: "nowrap" }}>Analyzed Document</div> */}
                            <label className="Pfizer-bredcrumb" style={{marginBottom: "4px"}}><span onClick={() => goToPrevious()} style={{ cursor: "pointer", color:"rgba(51, 104, 206, 1)" }}>Output</span> /<span className="Pfizer-Active"> Compare</span></label>
                        </div>
                        {/* <div>
                            <button style={{ whiteSpace: "nowrap", color: "#999FAA", border: "1px solid #999FAA", padding: "10px", backgroundColor: "#FFF" }} onClick={compareData}>
                                Compare Data
                            </button>
                        </div> */}
                    </div>
                    <div className='mt-3'>
                        <ProgressSteps uploadColor="rgba(41, 188, 118, 1)" 
                        analyzeColor="rgba(41, 188, 118, 1)" 
                        successStatus={true} successAnalyzeStatus={true} entityStatus={true}
                        marginBottom="5px" 
                        viewColor="rgba(41, 188, 118, 1)" entityColor="rgba(51, 104, 206, 1)" 
                        cursor={true} 
                        progressStep1="Storage Path" progressStep2="Analyze" progressStep3="View Data" progressStep4="Compare"
                        onNavigate= {goToPath}
                        analyzeOnclick = {goToAnalyze}
                        entityOnclick = {goToPrevious}
                        
                        />
                    </div>               
                </div>
                <div className='d-flex mt-4 flex-row col-12'>
                    <div className='d-flex flex-column pl-0 pr-0 box-widthe'>
                        <div className='p-3 list-text-styles processed-background'>Number of Processed files</div>
                        <div className='p-3 list-result'>{data[0]?.processedFiles_count}</div>
                    </div>
                    <div className='d-flex flex-column pl-0 pr-0 ml-3 box-widthe'>
                        <div className='p-3 list-text-styles submitted-background'>Number of Submitted files</div>
                        <div className='p-3 list-result'>{data[0]?.submittedFiles_count}</div>
                    </div>
                    <div className='d-flex flex-column pl-0 pr-0 ml-3 box-widthe'>
                        <div className='p-3 list-text-styles medra-background'>Total MedDRA Codes</div>
                        <div className='p-3 list-result'>{data[0]?.total_count}</div>
                    </div>
                    <div className='d-flex flex-column pl-0 pr-0 ml-3 mr-3 box-widthe'>
                        <div className='p-3 list-text-styles progress-overall-background'>Overall Comparison Metrics</div>
                        <div>
                            <div className='d-flex flex-row justify-content-between p-2'>
                                <div>Matching Codes : </div>
                                <div className='list-result'>{`${data[0]?.matchedFiles_count}/${data[0]?.total_count}`}</div>
                            </div>
                            <div className="compare-progress-bar">
                                <div
                                    className="progress"
                                    style={{ width: `${progress}%`, backgroundColor: '#007bff' }}
                                ></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='mt-5'>
                    <DataTable
                        customStyles={customStyles}
                        columns={columns}
                        data={data}
                        pagination
                    />
                </div>
            </div>
        </>
    )
}
export default ComparedResult;