import React, { useState } from 'react';
import './compareResults.css';
import Navbar from '../Navbar';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import DataTable from "react-data-table-component";
import backArrow from '../../assets/backarrow.svg';

const data = [
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    },
    {
        documentName: "kqvdkjqDKqdkvdkevkjfvjwkefvk.xml",
        snom: "13",
        medra: "12",
        narrative: "View Narrative",
        xml: "XML Viewer",
        output: "View output"
    }
]
const customStyles = {

    rows: {

        style: {
            border: 'none',
            ':nth-of-type(even)': {
                backgroundColor: "rgba(245, 245, 245, 1)"
            },
            fontFamily: "Poppins !important",
            borderRadius: 8,
            marginTop: 8
        }
    },

    headCells: {
        style: {
            backgroundColor: "#394356",
            color: "#fff",
            fontFamily: "Poppins !important",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 600
        },

    },
    cells: {
        style: {
            color: "#000000",
            fontFamily: "Poppins",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 400
        },

    },
};

const CompareResult = () => {
    const navigate = useNavigate()
    const [processedFiles, setProcessedFiles] = useState([])
    const [submittedFiles, setSubmittedFiles] = useState([])
    const columns = [
        {
            name: "Document Name",
            selector: row => row.documentName,
            center: true
        },
        {
            name: "Snomed Code",
            selector: row => row.snom,
            center: true
        },
        {
            name: "MedDRA Code",
            selector: row => row.medra,
            center: true
        },
    ]

    const handleChange = ({ selectedRows }) => {
        setProcessedFiles(selectedRows)
    };

    const handleChangeFiles = ({ selectedRows }) => {
        setSubmittedFiles(selectedRows)
    };

    const compareFiles = () => {
        const format = [...processedFiles, ...submittedFiles]
        if (format.length >= 1) {
            navigate("/comparedResult")
        } else {
            toast.warning("Please select minimum one file from Processed & Selected Files", { position: toast.POSITION.TOP_CENTER });
        }
    }
    return (
        <>
            <Navbar />
            <div className='compare-container col-12 pd20'>
                <div className="header-comapre">
                    <div className="header-content-compare justify-content-between align-items-center">
                        <div className='d-flex flex-row'>
                            <img src={backArrow} alt="img" />
                            <div className="heading-text text-style-nowrap">Select Submitted files</div>
                        </div>
                        <div>
                            <button className='comapare-button-style' onClick={() => compareFiles()}>
                                Compare Results
                            </button>
                        </div>
                    </div>
                </div>
                <div className='col-12 d-flex flex-row mt-3'>
                    <div className='col-6 m-2'>
                        <div style={{ height: "50px", padding: "10px", borderRadius: "5px", display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFF", color: "#000", width: "250px", border: "1px solid rgba(57, 67, 86, 1)" }}>
                            <div>Processed files</div>
                            <div className='font-style'>25</div>
                        </div>
                        <div className='mt-3'>
                            <DataTable
                                customStyles={customStyles}
                                columns={columns}
                                data={data}
                                selectableRows
                                onSelectedRowsChange={handleChange}
                                pagination
                            />
                        </div>
                    </div>
                    <div className='col-6 m-2'>
                        <div style={{ height: "50px", padding: "10px", borderRadius: "5px", display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFF", color: "#000", width: "250px", border: "1px solid rgba(57, 67, 86, 1)" }}>
                            <div>Submitted files</div>
                            <div className='font-style'>20</div>
                        </div>
                        <div className='mt-3'>
                            <DataTable
                                customStyles={customStyles}
                                columns={columns}
                                data={data}
                                selectableRows
                                onSelectedRowsChange={handleChangeFiles}
                                pagination
                            />
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default CompareResult;