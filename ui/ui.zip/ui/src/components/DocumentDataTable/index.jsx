import React from 'react';
import './document.css';
import Navbar from '../Navbar';
import ModalPopUpTable from '../../common/NarrativeModal';
import DataTable from "react-data-table-component";
import backArrow from '../../assets/backarrow.svg';
import { useState } from 'react';
import { ClipLoader  } from 'react-spinners';
import { viewNarrativeEndpoint, getXMLContentEndpoint, viewOutEndpoint, submittedComparisionEndpoint} from '../../common/api-config';
import axios from "axios";
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import ProgressSteps from '../../common/ProgressSteps/multiFileProgress';


const data = JSON.parse(localStorage.getItem("analyzedDocData"))
const customStyles = {

    rows: {

        style: {
            border: 'none',
            ':nth-of-type(even)': {
                backgroundColor: "rgba(245, 245, 245, 1)"
            },
            fontFamily: "Poppins !important",

            borderRadius: 8,
            marginTop: 8
        }
    },

    headCells: {
        style: {
            backgroundColor: "#394356",
            color: "#fff",
            fontFamily: "Poppins !important",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 600
        },

    },
    cells: {
        style: {
            color: "#000000",
            fontFamily: "Poppins",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 400
        },

    },
};

const DocumentDataTable = () => {
    const navigate = useNavigate()
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [selectedNarrative, setSelectedNarrative] = useState("")    
    let [loading, setLoading] = useState(false);
    const [outputLoading, setOutputLoading] = useState(false);



    const closeModal = () => {
        setIsModalOpen(false);
    };


    const goToSelect = () => {
        navigate('/selectFiles')
    };


    const openNarrative = (filePath) => {

        try {            
            axios
            .post(viewNarrativeEndpoint(),{               
                "file_path": filePath               
            })
            .then((response) => {
                setSelectedNarrative(response?.data)             
            })
      
            // toast.success("fetched data successfully", { position: toast.POSITION.TOP_CENTER });
            setIsModalOpen(true)
          } catch (error) {
            console.error('Error', error);
          }

    }

    const openNewTab = (filePath) => {
        try {           
            axios
            .post(getXMLContentEndpoint(),{
                
                "file_path": filePath                 
            })
            .then((response) => {

                const responseData = JSON.stringify(response?.data)             
                const xmlBlob = new Blob([JSON.parse(responseData)], { type: 'application/xml' });
                const xmlUrl = URL.createObjectURL(xmlBlob);
                window.open(xmlUrl, '_blank');
            })
                
            // toast.success("fetched data successfully", { position: toast.POSITION.TOP_CENTER });
   
          } catch (error) {
            console.error('Error', error);
          }

    };
    const viewOutput = (filePath, snomed_codes, meddra_codes) => {
        setLoading(true)
        console.log("filePath:", filePath, "snomed_codes:", snomed_codes, "meddra_codes:", meddra_codes)
        try {
            
            axios
            .post(viewOutEndpoint(),{                
                "file_path": filePath
            })
            .then((response) => {
                localStorage.setItem("outputData", response?.data)
                localStorage.setItem("response_snomed_codes", snomed_codes)
                localStorage.setItem("response_meddra_codes", meddra_codes)
                localStorage.setItem("selected_xml_file", filePath)
                const currDate = new Date().toLocaleDateString();
                const currTime = new Date().toLocaleTimeString();
                const timestamp = `${currTime} ${currDate}`
                localStorage.setItem("current_time", timestamp)
                navigate("/viewOutput")
            })
            toast.success("fetched data successfully", { position: toast.POSITION.TOP_CENTER });

          } catch (error) {
            console.error('Error', error);
          }
          setLoading(false)
    }

    const comparedResult = (csvPath) => {
        setOutputLoading(true)
        try {
            
            axios
            .post(submittedComparisionEndpoint(),{                
                "file_path": csvPath
            })
            .then((response) => {

                console.log("response", response)
                localStorage.setItem("processed_filepath", csvPath)
                localStorage.setItem("comparedResultData", JSON.stringify(response?.data))
                toast.success("Compared data successfully", { position: toast.POSITION.TOP_CENTER })
                navigate("/comparedResult")
            })
           ;

          } catch (error) {
            console.error('Error', error);
          }
          setOutputLoading(false)
    }

    

    const columns = [
        {
            name: "Document Name",
            selector: row => row.file_name,
            center: true,
            wrap:true
        },
        {
            name: "Snomed Code",
            selector: row => row.snomed_codes,
            center: true
        },
        {
            name: "MedDRA Code",
            selector: row => row.meddra_codes,
            center: true
        },
        {
            name: "Narrative Data",
            cell: row => (
                <div style={{ color: "rgba(51, 104, 206, 1)", cursor:"pointer" }} onClick={() => openNarrative(row.file_name)}>{"View Narrative"}</div>
            )
        },
        {
            name: "XML Data",
            cell: row => (
                <div style={{ color: "rgba(51, 104, 206, 1)", cursor:"pointer" }} onClick={() => openNewTab(row.file_name)}>{"XML Viewer"}</div>
            )
        },
        {
            name: "Output",
            cell: row => (
                <div style={{ color: "rgba(51, 104, 206, 1)", cursor:"pointer" }}  onClick={() => viewOutput(row.output_file, row.snomed_codes, row.meddra_codes)}>{"View Output"}</div>
            ),
            center: true
        },

        {
            name: "Compare Data",
            cell: row => (
                <div style={{ color: "rgba(51, 104, 206, 1)", cursor:"pointer" }}  onClick={() => comparedResult(row.output_file)}>{"Compare"}</div>
            ),
            center: true
        }
    ]
    const goToPrevious = () =>{
        navigate("/documentAnalyze")
    }
    return (
        <>
            <Navbar />
            <div className='document-container' style={{ padding: "20px" }}>
                <div className="header-analyze">
                    <div className="header-content" style={{ justifyContent: "space-between", alignItems: "center" }}>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                            {/* <img src={backArrow} alt="img" />
                            <div style={{ marginLeft: "10px", whiteSpace: "nowrap" }}>Analyzed Document</div> */}
                            <label className="Pfizer-bredcrumb" style={{marginBottom: "4px"}}><span onClick={() => goToPrevious()} style={{ cursor: "pointer", color:"rgba(51, 104, 206, 1)" }}>URL</span> /<span className="Pfizer-Active"> Analyzed Document</span></label>
                           
                        </div>
                        
                        {/* <div>
                            <button style={{ whiteSpace: "nowrap", color: "#999FAA", border: "1px solid #999FAA", padding: "10px", backgroundColor: "#FFF" }} onClick={goToSelect}>
                                Compare Data
                            </button>
                        </div> */}
                    </div>
                    
                    <div className='mt-3'>
                        <ProgressSteps uploadColor="rgba(41, 188, 118, 1)" analyzeColor="rgba(51, 104, 206, 1)" successStatus={true} marginBottom="5px" viewColor="rgba(136, 136, 136, 1)" entityColor="rgba(136, 136, 136, 1)" cursor={true} progressStep1="Storage Path" progressStep2="Analyze" progressStep3="View Data" progressStep4="Compare"
                            onNavigate ={goToPrevious}

                        />
                    </div>
                </div>
                <div style={{ marginTop: "20px", alignItems: "center" }} className='header-content'>
                    <div style={{ height: "50px", padding: "10px", borderRadius: "5px", display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFCEAB", color: "#B29077", width: "200px" }}>
                        <div>Snomed Count</div>
                        <div className='font-style'>{data?.snomed_codes}</div>
                    </div>
                    <div style={{ height: "50px", padding: "10px", marginLeft: "20px", borderRadius: "5px", alignItems: "center", display: "flex", flexDirection: "row", justifyContent: "space-between", backgroundColor: "rgba(226, 190, 255, 1)", color: "#B29077", width: "200px" }}>
                        <div>MedDRA count</div>
                        <div className='font-style'>{data?.meddra_codes}</div>
                    </div>
                    <div style={{ height: "50px", padding: "10px", marginLeft: "20px", borderRadius: "5px", alignItems: "center", display: "flex", flexDirection: "row", justifyContent: "space-between", backgroundColor: "rgba(193, 217, 254, 1)", color: "#B29077", width: "200px" }}>
                        <div>Processed Files</div>
                        <div className='font-style'>{data?.processed_files}</div>
                    </div>

                    <div style={{ height: "50px", padding: "10px", marginLeft: "20px", borderRadius: "5px", alignItems: "center", display: "flex", flexDirection: "row", justifyContent: "space-between", backgroundColor: "rgba(193, 255, 144, 1)", color: "#B29077", width: "200px" }}>
                        <div>Overall Percentage</div>
                        <div className='font-style'>{data?.overall_percentage.toFixed(2)}</div>
                    </div>

                </div>
                <div style={{marginTop:"20px"}}>
                    <DataTable
                        customStyles={customStyles}
                        columns={columns}
                        data={data?.data}
                        pagination
                    />
                </div>
            </div>
            {loading && (
        <div
          style={{
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100%',
            height: '100%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            background: 'rgba(0, 0, 0, 0.5)',
            zIndex: '9999',
          }}
        >
          <ClipLoader  color="#ffffff" size={80} />
        </div>)}
        {outputLoading && (
        <div
          style={{
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100%',
            height: '100%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            background: 'rgba(0, 0, 0, 0.5)',
            zIndex: '9999',
          }}
        >
          <ClipLoader  color="#ffffff" size={80} />
        </div>)}
            <ModalPopUpTable
                    narrativeData ={selectedNarrative}
                    openModal={isModalOpen}
                    popupWidth={"600px"}
                    buttonTop={"4px"}
                    close={closeModal}
                    type="info"
                />
        </>
    )
}

export default DocumentDataTable;