import React, { useState, useEffect } from 'react';
import './document.css';
import Navbar from '../Navbar';
import ModalPopUpTable from '../../common/NarrativeModal';
import { ClipLoader  } from 'react-spinners';
import DataTable from "react-data-table-component";
import backArrow from '../../assets/backarrow.svg';
import { viewNarrativeEndpoint, getXMLContentEndpoint, viewOutEndpoint, submittedComparisionEndpoint } from '../../common/api-config';
import axios from "axios";
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import downloadSimple from "../../assets/DownloadSimple.svg";
import refreshIcon from "../../assets/Refresh.svg";
import funnelSimple from "../../assets/FunnelSimple.svg";
import Select, { components } from "react-select";
import ProgressSteps from '../../common/ProgressSteps/multiFileProgress';

const OutputDataTable = () => {
    const navigate = useNavigate()
    // localStorage.getItem("ghdvjdh", JSON.parse(localStorage.getItem("analyzedDocData")))
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [selectedNarrative, setSelectedNarrative] = useState("")
    const [tableData, setTableData] = useState(JSON.parse(localStorage.getItem("outputData")))
    const [filteredSearchData, setFilteredSearchData] = useState([])
    let [loading, setLoading] = useState(false);



    const [envType, setEnvType] = useState('');
    const refresh = () => {
        setOpen(false)
        setDropdownStatus(false);
        setDropdownSelectedValue("")

    };
    const [open, setOpen] = useState(false)
    const [dropdownStatus, setDropdownStatus] = useState(false)
    const [filteredTableData, setFilteredTableData] = useState(JSON.parse(localStorage.getItem("outputData")));
    const [dropdownSelectedValue, setDropdownSelectedValue] = useState("")
    const [searchText, setSearchText] = useState(null)

    const getEnvType = (event) => {
        if (event != null) {
            setEnvType(event);
            setDropdownStatus(true)
            if (event.value === "matched") {
                const filteredData = tableData.filter((item) => {
                    console.log("item", item.MedDRA_Code)
                    return item.Meddra_code === "No Meddra Mapping Found/desc Found";
                });
                setFilteredTableData(filteredData)
                // setTableData(filteredData)

            } else {

                const filteredData = tableData.filter((item) => {
                    return item.Meddra_code !== "No Meddra Mapping Found/desc Found";
                });
                setFilteredTableData(filteredData)
                // setTableData(filteredData)


            }

        } else {

            setEnvType([]);
        }
    }

    const customStyles = {

        rows: {

            style: {
                border: 'none',
                ':nth-of-type(even)': {
                    backgroundColor: "rgba(245, 245, 245, 1)"
                },
                fontFamily: "Poppins !important",

                borderRadius: 8,
                marginTop: 8
            }
        },

        headCells: {
            style: {
                backgroundColor: "#394356",
                color: "#fff",
                fontFamily: "Poppins !important",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 600
            },

        },
        cells: {
            style: {
                color: "#000000",
                fontFamily: "Poppins",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 400
            },

        },
    };

    const closeModal = () => {
        setIsModalOpen(false);
    };


    const goToSelect = () => {
        navigate('/selectFiles')
    };


    const openNarrative = (filePath) => {

        setSelectedNarrative(filePath)
        try {

            axios
                .post(viewNarrativeEndpoint(filePath))
                .then((response) => {

                    console.log(response.data)

                })

            toast.success("fetched data successfully", { position: toast.POSITION.TOP_CENTER });
            setIsModalOpen(true)
        } catch (error) {
            console.error('Error', error);
        }
        //   navigate('/analyzedDocument')

        // setIsModalOpen(true)
    }

    const openNewTab = (filePath) => {
        const xmlBlob = new Blob([JSON.parse(localStorage.getItem("xmlContent"))], { type: 'application/xml' });
        // try {

        //     axios
        //     .post(getXMLContentEndpoint(filePath))
        //     .then((response) => {

        //         console.log(response.data)

        //         const xmlBlob = new Blob([JSON.parse(response?.data)], { type: 'application/xml' });
        //     const xmlUrl = URL.createObjectURL(xmlBlob);
        //     window.open(xmlUrl, '_blank');
        //     })


        //     toast.success("fetched data successfully", { position: toast.POSITION.TOP_CENTER });

        //   } catch (error) {
        //     console.error('Error', error);
        //   }
        // const xmlBlob = new Blob([JSON.parse()], { type: 'application/xml' });
        const xmlUrl = URL.createObjectURL(xmlBlob);
        window.open(xmlUrl, '_blank');
    };
    const viewOutput = (filePath) => {

        try {

            axios
                .post(viewOutEndpoint(filePath))
                .then((response) => {

                    console.log(response.data)

                    const xmlBlob = new Blob([JSON.parse(response?.data)], { type: 'application/xml' });
                    const xmlUrl = URL.createObjectURL(xmlBlob);
                    window.open(xmlUrl, '_blank');
                })


            toast.success("fetched data successfully", { position: toast.POSITION.TOP_CENTER });

        } catch (error) {
            console.error('Error', error);
        }
        // const xmlBlob = new Blob([JSON.parse()], { type: 'application/xml' });
        // const xmlUrl = URL.createObjectURL(xmlBlob);
        // window.open(xmlUrl, '_blank');
    };



    // const columns = [
    //     {
    //         name: "Document Name",
    //         selector: row => row.file_name,
    //         center: true,
    //         wrap:true
    //     },
    //     {
    //         name: "Snomed Code",
    //         selector: row => row.snomed_codes,
    //         center: true
    //     },
    //     {
    //         name: "MedDra Code",
    //         selector: row => row.meddra_codes,
    //         center: true
    //     },
    //     {
    //         name: "Narrative Data",
    //         cell: row => (
    //             <div style={{ color: "rgba(51, 104, 206, 1)", cursor:"pointer" }} onClick={() => openNarrative(row.narrativeData)}>{"View Narrative"}</div>
    //         )
    //     },
    //     {
    //         name: "XML Data",
    //         cell: row => (
    //             <div style={{ color: "rgba(51, 104, 206, 1)", cursor:"pointer" }} onClick={() => openNewTab(row.file_name)}>{"XML Viewer"}</div>
    //         )
    //     },
    //     {
    //         name: "Output",
    //         cell: row => (
    //             <div style={{ color: "rgba(51, 104, 206, 1)", cursor:"pointer" }}  onClick={() => viewOutput(row.output_file)}>{"View Output"}</div>
    //         ),
    //         center: true
    //     }
    // ]
    const columns = [

        {
            name: "Text",
            // (
            //     <span style={{ display: "flex" }}>
            //         Text
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Text")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.Text,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            }

        },
        {
            name: "Type",
            // (
            //     <span style={{ display: "flex" }}>
            //         Type
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Type")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.Type,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            }
        },
        {
            name: "Category",
            // (
            //     <span style={{ display: "flex" }}>
            //         Category
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Category")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.Category,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            }
        },
        {
            name: "Description",
            selector: row => row.Description,
            sortable: true,

            style: {
                backgroundColor: '#fff',

            }
        },
        {
            name: "Snomed Code",
            // (
            //     <span style={{ display: "flex" }}>
            //         Snomed Code
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("Snowmed_Code")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.Snomed_code,
            sortable: true,
            style: {
                backgroundColor: '#fff',

            },
        },
        {
            name: "MedDRA Code",
            // (
            //     <span style={{ display: "flex" }}>
            //         MedDRA Code
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("MedDRA_Code")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.Meddra_code,
            sortable: true,
            // 'rgb(193, 217, 254)'
            style: {
                backgroundColor: "aliceblue",

            },

            conditionalCellStyles: [
                {
                    when: row => row.Meddra_code !== "No Meddra Mapping Found/desc Found",
                    style: {
                        backgroundColor: "#21AC69",
                        color: 'white',
                        '&:hover': {
                            cursor: 'pointer',
                        },
                    },
                },


            ],


        },
        {
            name: "MedDRA_pt_name",
            // (
            //     <span style={{ display: "flex" }}>
            //         MedDRA_pt_name
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("pt_name")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.pt_name,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",
                // color: 'white',
            },
        },
        {
            name: "MedDRA_hlt_name",
            // (
            //     <span style={{ display: "flex" }}>
            //         MedDRA_hlt_name
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hgt_name")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.hlt_name,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",
                // color: 'white',
            },
        },
        {
            name: "MedDRA_hlgt_name",
            //  (
            //     <span style={{ display: "flex" }}>
            //         MedDRA_hlgt_name
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("hlt_name")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.hlgt_name,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",
                // color: 'white',
            },
        },
        {
            name: "MedDRA_soc_name",
            // (
            //     <span style={{ display: "flex" }}>
            //         MedDRA_soc_name
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_name")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.soc_name,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",
                // color: 'white',
            },
        },
        {
            name: "MedDRA_soc_abbrev",
            // (
            //     <span style={{ display: "flex" }}>
            //         MedDRA_soc_abbrev
            //         <img src={funnelSimpleWhite} style={{ cursor: "pointer", marginLeft: "5px" }} height="22px" width="25px" onClick={() => openMultiDropdown("soc_abbrev")} alt="User Icon" />
            //     </span>
            // ),
            selector: row => row.soc_abbrev,
            sortable: true,
            style: {
                backgroundColor: "aliceblue",
                // color: 'white',
            },
        },


    ]

    const customStylesFiltered = {
        option: (provided, state) => ({
            ...provided,
            // borderBottom: '1px dotted pink',
            color: state.isSelected ? '#003152' : '#003152',
            width: 200,
        }),
        container: provided => ({
            ...provided,
            width: 200,
        }),
        control: () => ({
            border: 'none',
            display: 'none',
            width: 0,
        }),
    };

    const envOptions = [
        { value: 'noMatched', label: 'Mapped' },
        { value: 'matched', label: 'Un mapped' },

    ]
    const llmOptions = [
        { value: 'noMatched', label: 'LLM' },
        { value: 'matched', label: 'AWS COMPREHEND MEDICAL' },

    ]
    const goToPrevious = () => {
        navigate("/analyzedDocument")
    }
    const goToPath = () => {
        navigate("/documentAnalyze")
    }

    const compareData = () => {
        setLoading(true)
        try {

            axios
                .post(submittedComparisionEndpoint(), {
                    "file_path": localStorage.getItem("selected_xml_file")
                })
                .then((response) => {

                    console.log("response", response)
                    localStorage.setItem("processed_filepath", localStorage.getItem("selected_xml_file"))
                    localStorage.setItem("comparedResultData", JSON.stringify(response?.data))
                    toast.success("Compared data successfully", { position: toast.POSITION.TOP_CENTER })
                    navigate("/comparedResult")
                })
                ;

        } catch (error) {
            console.error('Error', error);
        }
        setLoading(false)
    }

    const searchSpace = (e) => {

        const keyword = e.target.value;
        if (keyword === "") {
            setSearchText(null);
            setFilteredSearchData(tableData);
        } else {
            let result = tableData;
            setSearchText(keyword);
            const filteredResult = result.filter((element) =>
                Object.values(element).some((value) => {
                    if (typeof value === 'string') {
                        const lowerCaseValue = value.toLowerCase();
                        return (
                            lowerCaseValue.startsWith(keyword.toLowerCase()) ||
                            lowerCaseValue.includes(keyword.toLowerCase())
                        );
                    } else if (typeof value === 'number') {
                        const stringValue = value.toString();
                        return (
                            stringValue.startsWith(keyword.toLowerCase()) ||
                            stringValue.includes(keyword.toLowerCase())
                        );
                    }
                    return false;
                })
            );
            setFilteredSearchData(filteredResult)
        }
    };

    return (
        <>
            <Navbar />
            <div className='document-container' style={{ padding: "20px" }}>
                {/* <div className="header-analyze">
                    <div className="header-content" style={{ justifyContent: "space-between", alignItems: "center" }}>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                            <img src={backArrow} alt="img" />
                            <div style={{ marginLeft: "10px", whiteSpace: "nowrap" }}>Analyzed Document</div>
                        </div>
                        <div>
                            <button style={{ whiteSpace: "nowrap", color: "#999FAA", border: "1px solid #999FAA", padding: "10px", backgroundColor: "#FFF" }} onClick={compareData}>
                                Compare Data
                            </button>
                        </div>
                    </div>
                </div> */}
                <div className="header-analyze">
                    <div className="header-content" style={{ justifyContent: "space-between", alignItems: "center" }}>
                        <div style={{ display: "flex", flexDirection: "row" }}>
                            {/* <img src={backArrow} alt="img" />
                            <div style={{ marginLeft: "10px", whiteSpace: "nowrap" }}>Analyzed Document</div> */}
                            <label className="Pfizer-bredcrumb" style={{ marginBottom: "4px" }}><span onClick={() => goToPrevious()} style={{ cursor: "pointer", color: "rgba(51, 104, 206, 1)" }}>Analyzed Document</span> /<span className="Pfizer-Active"> Output</span></label>
                        </div>
                        <div>
                            {/* <button style={{ whiteSpace: "nowrap", color: "#999FAA", border: "1px solid #999FAA", padding: "10px", backgroundColor: "#FFF" }} onClick={compareData}>
                                Compare Data
                            </button> */}
                            <button className='active-button' style={{ marginBottom: "10px", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", cursor: "pointer" }}
                                onClick={compareData}
                            >
                                Compare Data
                            </button>
                        </div>
                    </div>
                    <div className='mt-3'>
                        <ProgressSteps uploadColor="rgba(41, 188, 118, 1)" analyzeColor="rgba(41, 188, 118, 1)" successStatus={true} successAnalyzeStatus={true}
                            marginBottom="5px" viewColor="rgba(51, 104, 206, 1)" entityColor="rgba(136, 136, 136, 1)" cursor={true} progressStep1="Storage Path" progressStep2="Analyze" progressStep3="View Data" progressStep4="Compare"
                            onNavigate={goToPath}
                            analyzeOnclick={goToPrevious}

                        />
                    </div>
                </div>
                <div style={{ marginTop: "20px", alignItems: "center" }} className='header-content'>
                    <div style={{ height: "50px", padding: "10px", borderRadius: "5px", display: "flex", alignItems: "center", flexDirection: "row", justifyContent: "space-between", backgroundColor: "#FFCEAB", color: "#B29077", width: "200px" }}>
                        <div>Snomed Count</div>
                        <div className='font-style'>{localStorage.getItem("response_snomed_codes")}</div>
                    </div>
                    <div style={{ height: "50px", padding: "10px", marginLeft: "20px", borderRadius: "5px", alignItems: "center", display: "flex", flexDirection: "row", justifyContent: "space-between", backgroundColor: "rgba(226, 190, 255, 1)", color: "#B29077", width: "200px" }}>
                        <div>MedDRA count</div>
                        <div className='font-style'>{localStorage.getItem("response_meddra_codes")}</div>
                    </div>
                    {/* <div style={{ height: "50px", padding: "10px", marginLeft: "20px", borderRadius: "5px", alignItems: "center", display: "flex", flexDirection: "row", justifyContent: "space-between", backgroundColor: "rgba(193, 217, 254, 1)", color: "#B29077", width: "200px" }}>
                        <div>Processed Files</div>
                        <div className='font-style'>{data.processed_files}</div>
                    </div> */}
                </div>


                <div style={{ display: "flex", marginTop: "20px", marginBottom: "20px" }}>
                    <div style={{ height: "20px", display: "flex", alignItems: "center", width: "80%" }}>
                        <span style={{ color: "#003152", fontSize: "16px", fontWeight: 500, marginRight: "5px" }}>Processed File : </span>{localStorage.getItem("selected_xml_file")} <span style={{ color: "#003152", fontSize: "16px", fontWeight: 500, marginRight: "5px", marginLeft: "15px" }}>Processed At :</span> {localStorage.getItem("current_time")}

                        {/* <div className="project-search mb-0 mt-5">
                    <input
                      type="text"
                      placeholder="Search"
                      className="searchInputField"
                      onChange={(e) => searchSpace(e)}
                    />
                  </div> */}
                    </div>
                    <div style={{ width: "20%", marginTop: "-9px", display: "flex", justifyContent: "flex-end" }}>
                        {open &&

                            <Select

                                options={envOptions}

                                value={envType}

                                onChange={getEnvType}
                                styles={customStylesFiltered}
                                placeholder="Filter by"
                                menuIsOpen={open}

                            />}

                        <img src={refreshIcon} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => refresh()} height="30px" width="30px" alt="User Icon" />
                        <img src={funnelSimple} style={{ marginTop: "-6px", cursor: "pointer", marginRight: "20px" }} onClick={() => setOpen(!open)} height="30px" width="30px" alt="User Icon" />


                        <img src={downloadSimple} style={{ marginTop: "-6px", cursor: "pointer" }} height="30px" width="30px" alt="User Icon" />


                    </div>



                </div>

                <div style={{ marginTop: "10px" }}>
                    <DataTable
                        customStyles={customStyles}
                        columns={columns}
                        data={dropdownStatus ? filteredTableData : searchText !== null ? filteredSearchData : tableData}
                        pagination
                    />
                </div>
            </div>
            {loading && (
        <div
          style={{
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100%',
            height: '100%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            background: 'rgba(0, 0, 0, 0.5)',
            zIndex: '9999',
          }}
        >
          <ClipLoader  color="#ffffff" size={80} />
        </div>)}
            <ModalPopUpTable
                narrativeData={selectedNarrative}
                openModal={isModalOpen}
                popupWidth={"600px"}
                buttonTop={"4px"}
                close={closeModal}
                type="info"
            />
        </>
    )
}

export default OutputDataTable;