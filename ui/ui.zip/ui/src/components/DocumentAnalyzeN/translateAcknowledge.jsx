import React, { useState } from 'react';
import downloadIcon from '../../assets/DownloadSimple.svg';
import ProgressSteps from '../../common/ProgressSteps';
import listIcon from '../../assets/FunnelSimple.svg';
import backArrow from '../../assets/backarrow.svg';
import ModalPopup from '../../common/CommentsModal';
import DataTable from "react-data-table-component";
import upload from '../../assets/Upload (1).svg';
import Xcircle from '../../assets/XCircle.svg';
import { useNavigate } from 'react-router-dom';
import eye from '../../assets/eye.svg';
import XML from '../../assets/XML 1.svg';
import { toast } from 'react-toastify';
import Select from "react-select";
import Navbar from '../Navbar';
import './DocumentAnalyzeN.css';

import XMLIcon from "../../assets/XML_icon.svg";
import Eye_blue from "../../assets/Eye_blue.svg";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faTimes } from '@fortawesome/free-solid-svg-icons';
import ChartDonut from "../../assets/ChartDonut.svg";





const TranslateAcknowledge = () => {
    const navigate = useNavigate();
    const [isModalOpen, setIsModalOpen] = useState(false)
    const [isPopupVisible, setIsPopupVisible] = useState(false);

    const uploadNavigate = () => {
        navigate('/upload')
    }

    const translateOnclick = () => {
        navigate('/translate')
    }

    const selectOptions = [
        { value: 'noMatched', label: 'LLM' },
        { value: 'matched', label: 'AWS COMPREHEND MEDICAL' },

    ]
    const openPopup = (event) => {
        setIsPopupVisible(true)
    }
    const closePopup = (event) => {
        setIsPopupVisible(false)
    }

    const customStyles = {
        rows: {

            style: {
                border: 'none',
                ':nth-of-type(even)': {
                    backgroundColor: "#F1F7FF"
                },
                fontFamily: "Poppins !important",

                borderRadius: 8,
                marginTop: 8
            }
        },

        headCells: {
            style: {
                backgroundColor: "#394356",
                color: "#fff",
                fontFamily: "Poppins !important",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 600
            },

        },
        cells: {
            style: {
                color: "#000000",
                fontFamily: "Poppins",
                fontSize: "14px",
                fontStyle: "normal",
                fontWeight: 400
            },

        },
    };
    const commentModal = () => {
        setIsModalOpen(true)
    }
    const columns = [
        {
            name: "Entity Type",
            // selector: row => (
            //     <Select
            //         options={selectOptions}
            //         className='fullWidth'
            //         placeholder="Select Type"
            //     />
            // ),
            selector: row => row.entityName,
            center: true,
            wrap:true
        },
        {
            name: "Entity Source Value",
            selector: row => row.entityTest,
            center: true,
            wrap:true
        },
        {
            name: "Entity Translated Value",
            selector: row => row.entityValue,
            center: true,
            wrap:true
        },
        {
            name: "Entity Source",
            selector: row => row.sourceValue,
            center: true, 
            wrap:true
        },
        {
            name: "Actions",
            selector: row => (
                <div className='d-flex flex-row'>
                    <button className='bg-white button-accept' onClick={() => selectAccept()}>Accept</button>
                    <button className='ml-2 bg-white button-reject' onClick={() => selectReject()}>Reject</button>
                </div>
            ),
            center: true
        },
        {
            name: "Comment",
            selector: row => (
                <div style={{ cursor: "pointer" }} onClick={() => commentModal()}>{row.comments}</div>
            ),
            center: true
        }
    ]
    const tabColumns = [
        {
            name: "Text",
            selector: row => row.text
        },
        {
            name: "Type",
            selector: row => row.type
        },
        {
            name: "Category",
            selector: row => row.category
        },
        {
            name: "Description",
            selector: row => row.description
        },
        {
            name: "Snomed_Code",
            selector: row => row.snomedCode
        },
        {
            name: "MedDRA_Code",
            selector: row => row.medraCode
        }
    ]
    const tabData = [
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        },
        {
            text: "labs",
            type: "TEST_NAME",
            category: "TEST_TREATMENT_PROCEDURE",
            description: "Result, lab.- general (observable entity)",
            snomedCode: "275924004",
            medraCode: "No Matched code Found"
        }
    ]

    const data = [
        {
            entityName: "Reaction",
            entityTest: "Misselijkheid",
            entityValue: "Nausea",
            sourceValue:"primarysrcreactinnativelang", 
            comments: "Add Comments"
        },
        {
            entityName: "Reaction",
            entityTest: "Pijn in de gewrichten",
            entityValue: "Pain in the jointse",
            sourceValue:"primarysrcreactinnativelang",
            comments: "Add Comments"
        },
        {
            entityName: "Reaction",
            entityTest: "Koorts: 40.5 tot en met 42 graden Celcius",
            entityValue: "Fever: 40.5 to 42 degrees Celsius",
            sourceValue:"primarysrcreactinnativelang",
            comments: "Add Comments"
        },
        // {
        //     entityName: "Reporter Name",
        //     entityTest: "dwhdgwdgwd",
        //     comments: "Add Comments"
        // },
        // {
        //     entityName: "Reporter Name",
        //     entityTest: "dwhdgwdgwd",
        //     comments: "Add Comments"
        // },
        // {
        //     entityName: "Reporter Name",
        //     entityTest: "dwhdgwdgwd",
        //     comments: "Add Comments"
        // },
        // {
        //     entityName: "Reporter Name",
        //     entityTest: "dwhdgwdgwd",
        //     comments: "Add Comments"
        // },
        // {
        //     entityName: "Reporter Name",
        //     entityTest: "dwhdgwdgwd",
        //     comments: "Add Comments"
        // }
    ]

    const selectAccept = () => {
        toast.success("Entity Accepted", { position: toast.POSITION.TOP_CENTER });
    }
    const selectReject = () => {
        toast.warning("Entity Rejected", { position: toast.POSITION.TOP_CENTER });
    }
    const closeModal = () => {
        setIsModalOpen(false);
    };
    const goToSnomed = () => {
        navigate("/analyze")
    };
    const goToEntity = () => {
        navigate("/documentAnalyzeN")
    };
    const goToNarrative = () => {
        navigate("/narrativeInput")
    }


    return (
        <div className="document-main-container" style={{ height: data.length >= 0 ? "" : "100vh" }}>
            <Navbar />
            <div className='d-flex flex-column m-2'>
                <div className="d-flex analyze-row align-items-center mt-2 pl-3">
                    <img src={backArrow} alt="img" />
                    <div className='ml-3'>Document Analyze</div>
                </div>
                <div className='col-12 d-flex analyze-row mt-4 mb-4'>

                    <div className="first-half" style={{ border: "1px solid lightgrey", borderRadius: "4px" }}>


                        {localStorage.getItem("fileName") != "" ?
                            <>
                                <div style={{ marginTop: "20px" }}>
                                    <div style={{ border: "1px solid lightgrey", borderRadius: "8px", padding: "12px" }}>


                                        <div style={{ textAlign: "center" }}>
                                            <img src={XMLIcon} alt="User Icon" height="130px" />


                                        </div>
                                        <p style={{ textAlign: "center", wordWrap: "break-word" }}>{localStorage.getItem("fileName")}</p>

                                        <hr></hr>
                                        <p style={{ textAlign: "center", display: "flex", justifyContent: "center", alignItems: "center", color: "#3368CE", fontSize: "15px", color: "#003152", cursor: "pointer", fontWeight: 600 }} ><span style={{ marginRight: "10px" }}>
                                            <img src={Eye_blue} alt="User Icon" height="25px" width="25px" /></span>View Narrative</p>
                                      





                                    </div>


                                </div>
                                <div style={{ display: "flex", flexDirection: "column", marginTop: "10px" }}>
                                <button className='active-button' style={{ marginBottom: "10px", display: "flex", flexDirection: "row", justifyContent: "center", alignItems: "center", cursor: "pointer" }}
                                    onClick={goToEntity}
                                >
                                    <img src={ChartDonut} alt="User Icon" /><span style={{ marginLeft: "8px" }} onClick={goToEntity}>Entity Extraction</span>
                                </button>
                                <button className='border-button' style={{ cursor: "pointer" }}>XML Viewer</button>
                            </div>

                            </> : <></>}


                    </div>
                    <div className='col-10'>
                        <ProgressSteps marginBottom="20px" uploadColor="rgba(41, 188, 118, 1)" outputColor="rgba(136, 136, 136, 1)" entityColor="rgba(136, 136, 136, 1)" analyzeColor="rgba(51, 104, 206, 1)" viewColor="rgba(136, 136, 136, 1)" successStatus={true} 
                        onNavigate={uploadNavigate} cursor={true} 
                        entityOnclick ={goToEntity}
                        codingOnclick ={goToNarrative}
                        outputOnclick ={goToSnomed}
                        />
                        <div>
                            {/* <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                <li className="nav-item document-border-tab1">
                                    <a className="nav-link" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Entity Extraction</a>
                                </li>
                                <li className="nav-item document-border-tab2">
                                    <a className="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false" onClick={goToSnowmed}>Snomed to MedDra</a>
                                </li>
                                <li className="nav-item document-border-tab3">
                                    <a className="nav-link active" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Translate</a>
                                </li>
                            </ul> */}
                            <div className="tab-content mt-3" id="pills-tabContent">
                                <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                    <div className='d-flex analyze-row justify-content-between align-items-center bg-white p-2 document-dataTable'>
                                        <div className='document-fileName'>{localStorage.getItem("fileName")}</div>
                                        <div className='d-flex analyze-row'>
                                            <img src={listIcon} alt="list" />
                                            <img className="ml-3" src={downloadIcon} alt="download" />
                                        </div>
                                    </div>
                                    <div className='document-dataTable'>
                                        <DataTable
                                            customStyles={customStyles}
                                            columns={columns}
                                            data={data}
                                            pagination
                                        />
                                    </div>
                                </div>
                                <div className="tab-pane fade" id="pills-profile" role="tabpanel" onClick={()=>goToSnomed()} aria-labelledby="pills-profile-tab">
                                    {/* <div className='d-flex analyze-row justify-content-between align-items-center bg-white p-2 document-dataTable'>
                                        <div className='document-fileName'>Document12</div>
                                        <div className='d-flex analyze-row'>
                                            <img src={listIcon} alt="list" />
                                            <img className="ml-3" src={downloadIcon} alt="download" />
                                        </div>
                                    </div>
                                    <div className='document-dataTable'>
                                        <DataTable
                                            customStyles={customStyles}
                                            columns={tabColumns}
                                            data={tabData}
                                            pagination
                                        />
                                    </div> */}
                                </div>
                                <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">3</div>
                            </div>
                        </div>
                    </div>
                </div>
                {isPopupVisible && (
                    <div className="popup">
                        <div className="popup-content">
                            
                            <div className='narrative'>
                                <p style={{
                                    color: "#003152",
                                    fontSize: "18px",
                                    fontWeight: 600,
                                    textAlign: "center"
                                }}>Narrative Data</p>
                               
                                <div style={{
                                    border: "1px solid lightgrey",
                                    borderRadius: "4px",
                                    marginTop: "25px",
                                    height: "310px",
                                    overflowY: "auto"
                                }}>
                                    <p style={{ padding: "0px 10px 10px 10px", fontSize: "14px", lineHeight: "25px" }}>
                                        {localStorage.getItem("narrativeString")}
                                    </p>

                                </div>

                                <button className='button-popup' onClick={closePopup}><FontAwesomeIcon icon={faTimes} /></button>
                            </div>

                        </div>
                    </div>
                )}
            </div>
            <ModalPopup
                openModal={isModalOpen}
                popupWidth={"500px"}
                buttonTop={"4px"}
                close={closeModal}
                type="info"
            />
        </div>

    )
}

export default TranslateAcknowledge;