import React, {useState} from 'react';
import Navbar from '../Navbar';
import defaultImg from '../../assets/Frame 47.svg';
import { ClipLoader  } from 'react-spinners';
import ProgressSteps from '../../common/ProgressSteps/multiFileProgress';
import backArrow from '../../assets/backarrow.svg';
import { useNavigate } from 'react-router-dom';
import './documentAnalyze.css';
import { analyzedDocsEndPoint } from '../../common/api-config';
import axios from "axios";
import { toast } from 'react-toastify';
// import LoadingOverlay from 'react-loading-overlay';

const DocumentAnalyze = () => {
    const [path, setPath] = useState("")
    const [file, setFile] = useState("")
    const [isActive, setActive] = useState(false)
    let [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const selectPath = (event) => {
        setPath(event.target.value)
    }
    const selectFiles = (event) => {
        setFile(event.target.value)
    }
    const analyze = () => {
        navigate('/analyzedDocument')
    }
    const getAnalayzedDocs = async() =>{
       const folderPath =  path
       const noOfFiles = parseInt(file.trim(), 10);
        setActive(true)
        setLoading(true)
        try {
            await axios
            .post(analyzedDocsEndPoint(), {
                
                "file_path": folderPath,
                "num": noOfFiles
                  
            })
            .then((response) => {

                console.log(response.data)
                localStorage.setItem("analyzedDocData", JSON.stringify(response?.data))
                navigate('/analyzedDocument')
            })
      
            toast.success("fetched data successfully", { position: toast.POSITION.TOP_CENTER });
          } catch (error) {
            console.error('Error', error);
          }
          setActive(false)
          setLoading(false)
        //   navigate('/analyzedDocument')
    }
    const goToPrevious = () =>{
        navigate("/select")
    }
    return (
        <>
         {/* <LoadingOverlay
                active={isActive}
                spinner
                text='Loading ...'
            > */}
            <Navbar />
            <div className="analyze-container">
                <div className="headerS">
                    <div className="header-content">
                        {/* <img src={backArrow} alt="img" />
                        <div style={{ marginLeft: "10px" }}>Document Analyze</div> */}

                    <label className="Pfizer-bredcrumb" style={{marginBottom: "4px"}}><span onClick={() => goToPrevious()} style={{ cursor: "pointer", color:"rgb(51, 104, 206)" }}>Select</span> /<span className="Pfizer-Active"> URL</span></label>
                    </div>
                    <div className='mt-3'>
                    <ProgressSteps uploadColor="rgba(51, 104, 206, 1)"  analyzeColor="rgba(136, 136, 136, 1)" viewColor="rgba(136, 136, 136, 1)" entityColor="rgba(136, 136, 136, 1)" cursor={true} progressStep1="Storage Path" progressStep2="Analyze" progressStep3="View Data" progressStep4="Compare"
                    />
                    </div>
                    <div className="img-wrapper">
                        <div className='analyze-row'>
                        <div className="url-input">URL Path</div>
                        <input className="input-field" placeholder='For ex. https//.....' onChange={(event)=> selectPath(event)}/>
                        <div className="url-input" style={{marginLeft:"20px"}}>Number of files</div>
                        <input className="input-field" placeholder='Enter the number of files' onChange={(event)=> selectFiles(event)}/>
                        </div>
                        <button className="button" style={{opacity: file&&path ? 1 : 0.5}} onClick={()=> getAnalayzedDocs()}>Analyze</button>
                    </div>
                </div>
                <div className="content">
                    <img src={defaultImg} alt="img" style={{ height: "390px" }} />
                </div>
            </div>
            {loading && (
        <div
          style={{
            position: 'fixed',
            top: '0',
            left: '0',
            width: '100%',
            height: '100%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            background: 'rgba(0, 0, 0, 0.5)',
            zIndex: '9999',
          }}
        >
          <ClipLoader  color="#ffffff" size={80} />
        </div>)}
            {/* </LoadingOverlay> */}
        </>
    )
}

export default DocumentAnalyze;
