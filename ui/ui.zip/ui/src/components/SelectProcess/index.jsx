import React from 'react';
import ModalPopUpTable from '../../common/AnalyzeModal';
import Navbar from '../Navbar';
import { useState } from 'react';

const SelectProcess = () => {
    const [isModalOpen, setIsModalOpen] = useState(true)
    const closeModal = () => {
        setIsModalOpen(false);
    };
    return (
        <>
        <Navbar/>
        <ModalPopUpTable
        openModal={isModalOpen}
        popupWidth={"600px"}
        buttonTop={"4px"}
        close={closeModal}
        type="info"
    />
    </>
    )
}

export default SelectProcess;