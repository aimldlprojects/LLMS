
import { createContext, useContext, useState } from 'react';
import { toast } from 'react-toastify';


const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(localStorage.getItem('authenticated') === 'true');

  const login = (email, password, navigate) => {
    if(email === "venkatachandra.akuri@pfizer.com"&& password === "Random123@"){
      setAuthenticated(true)
      localStorage.setItem("authenticated", true)
      localStorage.setItem("email", email)
      toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
      navigate('/select');
  } else if(email === "sainath.kumar@pfizer.com"&& password === "Random123@"){
      setAuthenticated(true)
      localStorage.setItem("authenticated", true)
      localStorage.setItem("email", email)
      toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
      navigate('/select');
  } else if(email === "pranathi.depa@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/select');
  } else if(email === "nithin.makkina@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/select');
  } else if(email === "eswar.poluri@pfizer.com"&& password === "Random123@"){
    setAuthenticated(true)
    localStorage.setItem("authenticated", true)
    localStorage.setItem("email", email)
    toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
    navigate('/select');
  } else if(email === "sampath.k.chaparala@pfizer.com"&& password === "Random123@"){
      setAuthenticated(true)
      localStorage.setItem("authenticated", true)
      localStorage.setItem("email", email)
      toast.success("Logged in successfully", { position: toast.POSITION.TOP_CENTER });
      navigate('/select');
  } else {
      toast.warning("Please provide valid Email & Password", { position: toast.POSITION.TOP_CENTER });
  }
  };

  const logout = () => {
    setAuthenticated(false)
    localStorage.removeItem('authenticated');
  };

  return (
    <AuthContext.Provider value={{ authenticated, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
