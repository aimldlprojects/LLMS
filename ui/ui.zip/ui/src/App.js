import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import XMLFileUploader from './components/XMLLoader';
import Translate from './components/XMLLoader/translate';
import UploadFile from './components/XMLLoader/upload';
import SelectProcess from './components/SelectProcess';
import { AuthProvider } from './components/AuthContext';
import DocumentAnalyze from './components/DocumentAnalyze';
import DocumentDataTable from './components/DocumentDataTable';
import CompareResult from './components/CompareResults';
import DocumentAnalyzeN from './components/DocumentAnalyzeN';
import ComparedResult from './components/CompareResults/comparedResult';
import AuthWrapper from './components/AuthWrapper';
import Login from './components/Login';
import {ToastContainer } from 'react-toastify';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; 
import 'react-toastify/dist/ReactToastify.css';
import NarrativeCompare from './components/NarrativeCompare';
import OutputDataTable from './components/DocumentDataTable/outputDataTable';

import './App.css';
import TranslateCompare from './components/XMLLoader/TranslateCompare';
import NarrativeInput from './components/NarrativeInput';
import TranslateAcknowledge from './components/DocumentAnalyzeN/translateAcknowledge';
import EntityExtraction from './components/EntityExtraction';

 
function App() {
  return (
    <AuthProvider>
    <Router>
      <Routes>
        <Route path="/analyze" element={
              <AuthWrapper>
                <XMLFileUploader />
              </AuthWrapper>
            } />
             <Route path="/narrativeInput" element={
              <AuthWrapper>
                <NarrativeInput />
              </AuthWrapper>
            } />
             <Route path="/narrativeCompare" element={
              <AuthWrapper>
                <NarrativeCompare />
              </AuthWrapper>
            } />
             <Route path="/translate" element={
              <AuthWrapper>
                <Translate />
              </AuthWrapper>
            } />
            <Route path="/compare" element={
              <AuthWrapper>
                <TranslateCompare />
              </AuthWrapper>
            } />
        <Route path="/upload" element={
              <AuthWrapper>
                <UploadFile />
              </AuthWrapper>
            } />
        <Route path="/" element={
              <AuthWrapper>
                <Login />
              </AuthWrapper>
            }/>
          <Route path="/select" element={
              <AuthWrapper>
                <SelectProcess />
              </AuthWrapper>
            }/>
            <Route path="/documentAnalyze" element={
              <AuthWrapper>
                <DocumentAnalyze />
              </AuthWrapper>
            }/>
             <Route path="/analyzedDocument" element={
              <AuthWrapper>
                <DocumentDataTable />
              </AuthWrapper>
            }/>
               <Route path="/selectFiles" element={
              <AuthWrapper>
                <CompareResult />
              </AuthWrapper>
            }/>
             <Route path="/comparedResult" element={
              <AuthWrapper>
                <ComparedResult />
              </AuthWrapper>
            }/>

            <Route path="/viewOutput" element={
              <AuthWrapper>
                <OutputDataTable />
                </AuthWrapper>
             } />
            <Route path="/documentAnalyzeN" element={
              <AuthWrapper>
                <DocumentAnalyzeN />
              </AuthWrapper>
            }/>
            <Route path="/acknowledge" element={
              <AuthWrapper>
                <TranslateAcknowledge />
              </AuthWrapper>
            }/>
            <Route path="/entityExtraction" element={
              <AuthWrapper>
                <EntityExtraction />
              </AuthWrapper>
            }/>
      </Routes>
      <ToastContainer />
    </Router>
    </AuthProvider>
  );
}
 
export default App;