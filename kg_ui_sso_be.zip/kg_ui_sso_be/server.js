var express = require('express'),
    app = express(),
    port = process.env.PORT || 3000,
    bodyParser = require('body-parser');


app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


var routes = require('./api/routes/authRoutes'); //importing route
routes(app); //register the route

app.listen(port);

console.log('todo list RESTful API server started on: ' + port);



// const express = require("express");
// const bodyParser = require('body-parser');
// const cors = require("cors");
// const app = express();

// app.use(cors());
// app.use(express.json());
// app.use(bodyParser.json());

// app.get("/auth", (req, res) => {
//   res.json({ message: "SSO Server is running...." });
// });

// app.get("/auth", (req, res) => {
//   res.json({ message: "SSO Server is running...." });
// });

// app.listen(8000, () => {
//   console.log(`Server is running on port 8000.`);
// });