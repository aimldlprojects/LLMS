'use strict';
let config = require('../config');

exports.list_all_tasks = function (req, res) {
    res.json({ message: "SSO Server list_all_tasks is running...." });
};

exports.create_a_task = function (req, res) {
    res.json({ message: "SSO Server create_a_task is running...." });
};

exports.read_a_task = function (req, res) {
    res.json({ message: "SSO Server read_a_task is running...." });
};

exports.update_a_task = function (req, res) {
    res.json({ message: "SSO Server update_a_task is running...." });
};

exports.delete_a_task = function (req, res) {
    res.json({ message: "SSO Server delete_a_task is running...." });
};

exports.get_access_token = async function (req, res) {
    res.json({ message: "SSO Server delete_a_task is running...." });
    // const params = {
    //     // eslint-disable-next-line camelcase
    //     grant_type: "authorization_code",
    //     scope: config.scope[0],
    //     // eslint-disable-next-line camelcase
    //     client_id: this.config.clientId,
    //     // eslint-disable-next-line camelcase
    //     client_secret: this.config.clientSecret
    // };
    // const body = Object.entries(params)
    //     .map(p => `${encodeURIComponent(p[0])}=${encodeURIComponent(p[1])}`)
    //     .join("&");
    // const response = await this.http.fetch(`${this.config.issuer}/token`, {
    //     method: "POST",
    //     body: body,
    //     headers: {
    //         Accept: "application/json",
    //         "Content-Type": "application/x-www-form-urlencoded"
    //     }
    // });
    // const accessToken = await response.json();
    // if (!accessToken || !accessToken.access_token) {
    //     throw new Error("Could not get access_token");
    // } else {
    //     return accessToken.access_token;
    // }
};