import xml.etree.ElementTree as ET


def extract_narrative_from_xml(file_path):
    # Parse the XML file
    tree = ET.parse(file_path)
    root = tree.getroot()

    # Find the narrativeincludeclinical tag
    narrative_tag = root.find('.//narrativeincludeclinical')

    # Check if the tag is found
    if narrative_tag is not None:
        # Extract and print the text within the tag
        narrative_text = narrative_tag.text.strip() if narrative_tag.text else ''
        print(narrative_text)
        return narrative_text
    else:
        print("No <narrativeincludeclinical> tag found in the XML.")


paragraph = """This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. 
The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.\n\nDrugs and latency: \n1. covid-19 vaccin pfizer orig/omic ba.1 injvlst\nchills: 10 hours after start\nheadache: 10 hours after start\nnausea: 10 hours after start\nmyalgia: 3 hours after start\nmalaise: 5 hours after start\nfatigue: 10 hours after start\ngeneralized joint pain: 6 hours after start\ninjection site warmth: 1 days after start\ninjection site pain: 1 days after start\ninjection site swelling: 1 days after start\ninjection site inflammation: 1 days after start\nhyperpyrexia: 10 hours after start\n\n\n\n\nPast drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml"""

print(paragraph)