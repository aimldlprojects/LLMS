from fastapi import FastAPI,UploadFile
from pydantic import BaseModel
import os, shutil
from dotenv import load_dotenv
from app.pfizer_chunk import extract_from_xml
from app.pfizer_extract import extract_from_narrative
import uvicorn

#loading credentials
load_dotenv()


app = FastAPI()


class ExtractfromXml(BaseModel):
    file_path: str

@app.post("/upload",tags=["Upload File"])
def upload_file(file:UploadFile):
    try:
        file_path = f"./app/data/raw_xml/{file.filename}"
        if(not os.path.exists(file_path)):
            with open(file_path,"wb") as buffer:
                shutil.copyfileobj(fsrc= file.file,fdst= buffer)
            return {"status_code":"201","response_body":{"Xml_fileName":file_path}}
        else:
            return {"status_code":"400","Message":f"{file.filename} already exists",
                    "response_body":{"Xml_fileName":file_path}}
    except Exception as e:
        return {"status_code":"400","Message":f"Uploading the file {file.filename} failed", "Error":repr(e)}


@app.post('/extract/xml',tags=['Extract from XML'])
def entity_extraction_from_xml(details:ExtractfromXml):
    try:
        extracted_entities = extract_from_xml(file_path=details.file_path)
        return extracted_entities
    except Exception as e:
        return repr(e)
    

@app.post('/extract/narrative',tags=['Extract from Narrative'])
def entity_extraction_from_narrative():
    try:
        extracted_entities = extract_from_narrative()
        return extracted_entities
    except Exception as e:
        return repr(e)
    
# entity_extraction_from_xml(details=)

if(__name__=="__main__"):
    uvicorn.run('main:app',reload=True)