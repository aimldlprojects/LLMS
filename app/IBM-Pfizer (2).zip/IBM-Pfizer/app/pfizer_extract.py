from sagemaker.jumpstart.model import JumpStartModel
import os
import boto3,json
from app.bedrock_details import use_llm_with_aws_bedrock
from dotenv import load_dotenv
import xml.etree.ElementTree as ET


def extract_narrative_from_xml(file_path):
    # Parse the XML file
    tree = ET.parse(file_path)
    root = tree.getroot()

    # Find the narrativeincludeclinical tag
    narrative_tag = root.find('.//narrativeincludeclinical')

    # Check if the tag is found
    if narrative_tag is not None:
        # Extract and print the text within the tag
        narrative_text = narrative_tag.text.strip() if narrative_tag.text else ''
        # print(narrative_text)
        return narrative_text
    else:
        print("No <narrativeincludeclinical> tag found in the XML.")

def query_endpoint_with_json_payload(encoded_json, endpoint_name):

    client = boto3.client("runtime.sagemaker")
    response = client.invoke_endpoint(
        EndpointName=endpoint_name, ContentType="application/json", Body=encoded_json, CustomAttributes='accept_eula=true'
    )
    return response      

def parse_response_multiple_texts(query_response):
    model_predictions = json.loads(query_response["Body"].read())
    generated_text = model_predictions[0]['generation']["content"]
    return generated_text

def extract_from_narrative(file_path):
    try:
        NARRATIVE_ABSENT = "No <narrativeincludeclinical> tag found in the XML."
        paragraph = extract_narrative_from_xml(file_path=file_path)
        if(paragraph != NARRATIVE_ABSENT):
            prompt= """you are a service similar to Amazon Comprehend Medical that uses machine learning to extract medical information from unstructured text, such as physician notes, discharge summaries, test results, and case notes and I want you to extract following medical entities from given medical narratives
            medical Entities to be extracted: reporter, patient, drug, dosage information, test , history, events, symptoms
            Example 1:
            Medical Narrative: This serious spontaneous report from a consumer or other non-health professional concerns a male aged 69 years, with rash (life threatening), spinal cord injury (life threatening) following the third administration of covid-19 vaccin pfizer injvlst (action taken: not applicable) for covid 19 immunisation.
            Treatment:  Rash is treated with medicatie , ik sta weer en loop met hulpmiddelen, spinal cord injury is treated with medicatie  and ik sta weer en loop met hulpmiddelen. The patient is recovering from rash and is recovering from spinal cord injury.
            Drugs and latency:

            1. covid-19 vaccin pfizer injvlst
            rash: 8 months after start
            spinal cord injury: 8 months after start
            Medical history : covid 19 (in november 2019), covid 19 (15 august 2022 = same date as reactions), obesity (BMI 34.9)
            Past drug therapy :

            - first covid-19 vaccin niet gespecificeerd injvlst,

            - second covid-19 vaccin pfizer injvlst 0,3ml

            Medical Entity:
            {
                "Entities": [

                    {
                        "Id": 31,
                        "BeginOffset": 92,
                        "EndOffset": 96,
                        "Score": 0.9844712018966675,
                        "Text": "male",
                        "Category": "BEHAVIORAL_ENVIRONMENTAL_SOCIAL",
                        "Type": "GENDER",
                        "Traits": []
                    },
                    {
                        "Id": 23,
                        "BeginOffset": 102,
                        "EndOffset": 104,
                        "Score": 0.7370230555534363,
                        "Text": "69",
                        "Category": "PROTECTED_HEALTH_INFORMATION",
                        "Type": "AGE",
                        "Traits": []
                    },
                    {
                        "Id": 5,
                        "BeginOffset": 117,
                        "EndOffset": 121,
                        "Score": 0.9934624433517456,
                        "Text": "rash",
                        "Category": "MEDICAL_CONDITION",
                        "Type": "DX_NAME",
                        "Traits": [
                            {
                                "Name": "SYMPTOM",
                                "Score": 0.9543888568878174
                            }
                        ],
                        "Attributes": [
                            {
                                "Type": "QUALITY",
                                "Score": 0.8790790438652039,
                                "RelationshipScore": 1,
                                "RelationshipType": "QUALITY",
                                "Id": 6,
                                "BeginOffset": 123,
                                "EndOffset": 139,
                                "Text": "life threatening",
                                "Category": "MEDICAL_CONDITION",
                                "Traits": []
                            }
                        ]
                        }
            ]
            }
            please extract the medical entities for the below medical narrative.
            Medical Narrative: """ + paragraph

            # endpoint_name="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"

            # payload = {
            #     "inputs": [[
            #         {"role": "user", "content": prompt},
            #     ]],
            #     "parameters": {"max_new_tokens": 4000,  "top_p": 0.7, "temperature": 0.2}
            # }
            # query_response = query_endpoint_with_json_payload(
            #     json.dumps(payload).encode("utf-8"), endpoint_name=endpoint_name
            # )

            # generated_texts = parse_response_multiple_texts(query_response)
            generated_texts = use_llm_with_aws_bedrock(prompt=prompt)
            print("Generated Entities: ", generated_texts)
            return generated_texts
        else:
            return NARRATIVE_ABSENT
            
    
    except Exception as e:
        return repr(e)

def extract_from_narrative_test():
    try:
        # model_id="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"

        # model = JumpStartModel(model_id=model_id)
        paragraph = """This serious spontaneous report from a consumer or other non-health professional concerns a male aged 69 years, with rash (life threatening), spinal cord injury (life threatening) following the third administration of covid-19 vaccin pfizer injvlst (action taken: not applicable) for covid 19 immunisation.
        Treatment:  Rash is treated with medicatie , ik sta weer en loop met hulpmiddelen, spinal cord injury is treated with medicatie  and ik sta weer en loop met hulpmiddelen. The patient is recovering from rash and is recovering from spinal cord injury.
        
        Drugs and latency:
        1. covid-19 vaccin pfizer injvlst
        rash: 8 months after start
        spinal cord injury: 8 months after start
        Medical history : covid 19 (in november 2019), covid 19 (15 august 2022 = same date as reactions), obesity (BMI 34.9)
        
        Past drug therapy :
        - first covid-19 vaccin niet gespecificeerd injvlst,
        - second covid-19 vaccin pfizer injvlst 0,3ml"""

        prompt= """you are a service similar to Amazon Comprehend Medical that uses machine learning to extract medical information from unstructured text, such as physician notes, discharge summaries, test results, and case notes and I want you to extract following medical entities from given medical narratives
        medical Entities to be extracted: reporter, patient, drug, dosage information, test , history, events, symptoms
        Example 1:
        Medical Narrative: This serious spontaneous report from a consumer or other non-health professional concerns a male aged 69 years, with rash (life threatening), spinal cord injury (life threatening) following the third administration of covid-19 vaccin pfizer injvlst (action taken: not applicable) for covid 19 immunisation.
        Treatment:  Rash is treated with medicatie , ik sta weer en loop met hulpmiddelen, spinal cord injury is treated with medicatie  and ik sta weer en loop met hulpmiddelen. The patient is recovering from rash and is recovering from spinal cord injury.
        Drugs and latency:

        1. covid-19 vaccin pfizer injvlst
        rash: 8 months after start
        spinal cord injury: 8 months after start
        Medical history : covid 19 (in november 2019), covid 19 (15 august 2022 = same date as reactions), obesity (BMI 34.9)
        Past drug therapy :

        - first covid-19 vaccin niet gespecificeerd injvlst,

        - second covid-19 vaccin pfizer injvlst 0,3ml

        Medical Entity:
        {
            "Entities": [

                {
                    "Id": 31,
                    "BeginOffset": 92,
                    "EndOffset": 96,
                    "Score": 0.9844712018966675,
                    "Text": "male",
                    "Category": "BEHAVIORAL_ENVIRONMENTAL_SOCIAL",
                    "Type": "GENDER",
                    "Traits": []
                },
                {
                    "Id": 23,
                    "BeginOffset": 102,
                    "EndOffset": 104,
                    "Score": 0.7370230555534363,
                    "Text": "69",
                    "Category": "PROTECTED_HEALTH_INFORMATION",
                    "Type": "AGE",
                    "Traits": []
                },
                {
                    "Id": 5,
                    "BeginOffset": 117,
                    "EndOffset": 121,
                    "Score": 0.9934624433517456,
                    "Text": "rash",
                    "Category": "MEDICAL_CONDITION",
                    "Type": "DX_NAME",
                    "Traits": [
                        {
                            "Name": "SYMPTOM",
                            "Score": 0.9543888568878174
                        }
                    ],
                    "Attributes": [
                        {
                            "Type": "QUALITY",
                            "Score": 0.8790790438652039,
                            "RelationshipScore": 1,
                            "RelationshipType": "QUALITY",
                            "Id": 6,
                            "BeginOffset": 123,
                            "EndOffset": 139,
                            "Text": "life threatening",
                            "Category": "MEDICAL_CONDITION",
                            "Traits": []
                        }
                    ]
                    }
        ]
        }
        please extract the medical entities for the below medical narrative.
        If you are not able to extract anything or if you extract an empty string, please explain why.
        Medical Narrative: """ + paragraph + 'If you are not able to extract anything or if you extract an empty string, please explain why.'

        # endpoint_name="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"

        # payload = {
        #     "inputs": [[
        #         {"role": "user", "content": prompt},
        #     ]],
        #     "parameters": {"max_new_tokens": 4000,  "top_p": 0.7, "temperature": 0.2}
        # }
        # query_response = query_endpoint_with_json_payload(
        #     json.dumps(payload).encode("utf-8"), endpoint_name=endpoint_name
        # )

        # generated_texts = parse_response_multiple_texts(query_response)
        generated_texts = use_llm_with_aws_bedrock(prompt=prompt)
        print(generated_texts)
        return generated_texts
    
    except Exception as e:
        return repr(e)
    

paragraph = """This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. 
The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.\n\nDrugs and latency: \n1. covid-19 vaccin pfizer orig/omic ba.1 injvlst\nchills: 10 hours after start\nheadache: 10 hours after start\nnausea: 10 hours after start\nmyalgia: 3 hours after start\nmalaise: 5 hours after start\nfatigue: 10 hours after start\ngeneralized joint pain: 6 hours after start\ninjection site warmth: 1 days after start\ninjection site pain: 1 days after start\ninjection site swelling: 1 days after start\ninjection site inflammation: 1 days after start\nhyperpyrexia: 10 hours after start\n\n\n\n\nPast drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml"""

def extract_from_narrative_with_originalcontent():
    try:
        # model_id="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"

        # model = JumpStartModel(model_id=model_id)
        paragraph = """This spontaneous report from a consumer or other non-health professional concerns a female aged 21 Years, with chills, headache, nausea, myalgia, malaise, fatigue, generalized joint pain, injection site warmth, injection site pain, injection site swelling, injection site inflammation, hyperpyrexia following administration of covid-19 vaccin pfizer orig/omic ba.1 injvlst (action taken: not applicable) for covid 19 immunisation. 
                        The patient has not recovered from fatigue, has not recovered from generalized joint pain, has not recovered from headache, has not recovered from injection site inflammation, has not recovered from injection site pain, has not recovered from injection site swelling, has not recovered from injection site warmth, has not recovered from malaise, is recovering from chills, is recovering from hyperpyrexia, is recovering from myalgia and is recovering from nausea.\n\nDrugs and latency: \n1. covid-19 vaccin pfizer orig/omic ba.1 injvlst\nchills: 10 hours after start\nheadache: 10 hours after start\nnausea: 10 hours after start\nmyalgia: 3 hours after start\nmalaise: 5 hours after start\nfatigue: 10 hours after start\ngeneralized joint pain: 6 hours after start\ninjection site warmth: 1 days after start\ninjection site pain: 1 days after start\ninjection site swelling: 1 days after start\ninjection site inflammation: 1 days after start\nhyperpyrexia: 10 hours after start\n\n\n\n\nPast drug therapy : covid-19 vaccin astrazeneca injvlst, covid-19 vaccin astrazeneca injvlst, covid-19 vaccin pfizer injvlst 0,3ml"""


        prompt= """you are a service similar to Amazon Comprehend Medical that uses machine learning to extract medical information from unstructured text, such as physician notes, discharge summaries, test results, and case notes and I want you to extract following medical entities from given medical narratives
        medical Entities to be extracted: reporter, patient, drug, dosage information, test , history, events, symptoms
        Example 1:
        Medical Narrative: This serious spontaneous report from a consumer or other non-health professional concerns a male aged 69 years, with rash (life threatening), spinal cord injury (life threatening) following the third administration of covid-19 vaccin pfizer injvlst (action taken: not applicable) for covid 19 immunisation.
        Treatment:  Rash is treated with medicatie , ik sta weer en loop met hulpmiddelen, spinal cord injury is treated with medicatie  and ik sta weer en loop met hulpmiddelen. The patient is recovering from rash and is recovering from spinal cord injury.
        Drugs and latency:

        1. covid-19 vaccin pfizer injvlst
        rash: 8 months after start
        spinal cord injury: 8 months after start
        Medical history : covid 19 (in november 2019), covid 19 (15 august 2022 = same date as reactions), obesity (BMI 34.9)
        Past drug therapy :

        - first covid-19 vaccin niet gespecificeerd injvlst,

        - second covid-19 vaccin pfizer injvlst 0,3ml

        Medical Entity:
        {
            "Entities": [

                {
                    "Id": 31,
                    "BeginOffset": 92,
                    "EndOffset": 96,
                    "Score": 0.9844712018966675,
                    "Text": "male",
                    "Category": "BEHAVIORAL_ENVIRONMENTAL_SOCIAL",
                    "Type": "GENDER",
                    "Traits": []
                },
                {
                    "Id": 23,
                    "BeginOffset": 102,
                    "EndOffset": 104,
                    "Score": 0.7370230555534363,
                    "Text": "69",
                    "Category": "PROTECTED_HEALTH_INFORMATION",
                    "Type": "AGE",
                    "Traits": []
                },
                {
                    "Id": 5,
                    "BeginOffset": 117,
                    "EndOffset": 121,
                    "Score": 0.9934624433517456,
                    "Text": "rash",
                    "Category": "MEDICAL_CONDITION",
                    "Type": "DX_NAME",
                    "Traits": [
                        {
                            "Name": "SYMPTOM",
                            "Score": 0.9543888568878174
                        }
                    ],
                    "Attributes": [
                        {
                            "Type": "QUALITY",
                            "Score": 0.8790790438652039,
                            "RelationshipScore": 1,
                            "RelationshipType": "QUALITY",
                            "Id": 6,
                            "BeginOffset": 123,
                            "EndOffset": 139,
                            "Text": "life threatening",
                            "Category": "MEDICAL_CONDITION",
                            "Traits": []
                        }
                    ]
                    }
        ]
        }
        please extract the medical entities for the below medical narrative.
        Medical Narrative: """ + paragraph

        # endpoint_name="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"

        # payload = {
        #     "inputs": [[
        #         {"role": "user", "content": prompt},
        #     ]],
        #     "parameters": {"max_new_tokens": 4000,  "top_p": 0.7, "temperature": 0.2}
        # }
        # query_response = query_endpoint_with_json_payload(
        #     json.dumps(payload).encode("utf-8"), endpoint_name=endpoint_name
        # )

        # generated_texts = parse_response_multiple_texts(query_response)
        generated_texts = use_llm_with_aws_bedrock(prompt=prompt)
        print(generated_texts)
        return generated_texts
    
    except Exception as e:
        return repr(e)   
if(__name__=="__main__"):
    load_dotenv()
    # extract_from_narrative_test()
    extract_from_narrative_with_originalcontent()
    # extract_from_narrative(file_path=r'./app/data/raw_xml/xml_data.xml')