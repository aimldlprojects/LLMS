from fastapi import FastAPI
from pydantic import BaseModel
import xml.etree.ElementTree as ET
from sagemaker.jumpstart.model import JumpStartModel
from dotenv import load_dotenv
from botocore.config import Config
import os
import boto3, json
import uvicorn
from app.bedrock_details import use_llm_with_aws_bedrock


# app = FastAPI()



def read_xml_file(file_path):
    """
    The function `read_xml_file` reads the contents of an XML file and returns the text.
    
    :param file_path: The file path is the location of the XML file that you want to read. It should be
    a string that specifies the path to the file, including the file name and extension. For example,
    "C:/Users/username/Documents/file.xml" or "data/file.xml"
    :return: The function `read_xml_file` returns the content of the XML file as a string if the file is
    found and can be read successfully. If the file is not found, it returns a string indicating that
    the file was not found at the specified path. If any other error occurs during the file reading
    process, it returns a string indicating that an error occurred, along with the specific error
    message.
    """
    try:
        with open(file_path, "r", encoding="utf-8") as xml_file:
            xml_text = xml_file.read()
            return xml_text
    except FileNotFoundError:
        return f"XML file not found at '{file_path}'"
    except Exception as e:
        return f"An error occurred: {str(e)}"
    

def chunk_xml(xml_string, max_chunk_size, target_tags):
    root = ET.fromstring(xml_string)
    
    current_chunk = ET.Element(root.tag)
    current_chunk_size = 0
    chunks = []

    for element in root.iter():
        if element.tag in target_tags:
            element_str = ET.tostring(element, encoding='utf-8').decode('utf-8')

            # Check if adding the current element exceeds the max_chunk_size
            if current_chunk_size + len(element_str) > max_chunk_size:
                chunks.append(current_chunk)
                current_chunk = ET.Element(root.tag)
                current_chunk_size = 0

            # Append the current element to the current chunk
            current_chunk.append(element)
            current_chunk_size += len(element_str)

    # Append the last chunk if it's not empty
    if len(current_chunk) > 0:
        chunks.append(current_chunk)

    # Create XML strings for each chunk
    # The line `chunk_strings = [ET.tostring(chunk, encoding='utf-8').decode('utf-8') for chunk in
    # chunks]` is creating a list of XML strings for each chunk.
    chunk_strings = [ET.tostring(chunk, encoding='utf-8').decode('utf-8') for chunk in chunks]

    return chunk_strings

def write_chunks_to_files(chunks):
    """
    The function writes each chunk in a list to a separate file in XML format.
    
    :param chunks: The "chunks" parameter is a list of strings, where each string represents a chunk of
    data that needs to be written to a file
    """
    for i, chunk in enumerate(chunks):
        with open(f'./app/data/chunked_xml/output_chunk_{i + 1}.xml', 'w') as file:
            file.write(chunk)


def query_endpoint_with_json_payload(encoded_json, endpoint_name):

    client = boto3.client("runtime.sagemaker")
    response = client.invoke_endpoint(
        EndpointName=endpoint_name, ContentType="application/json", Body=encoded_json, CustomAttributes='accept_eula=true'
    )
    return response

def parse_response_multiple_texts(query_response):

    model_predictions = json.loads(query_response["Body"].read())
    generated_text = model_predictions[0]['generation']["content"]
    return generated_text


def extract_from_xml(file_path):
    try:
        # The code snippet `xml_data = open('xml_data.xml').read()` reads the contents of an XML file named
        # 'xml_data.xml' and stores it in the variable `xml_data`.
        # Example usage
        xml_data = open(file_path).read()
        max_chunk_size = 4090
        target_tags = ['patient', 'drug', 'test', 'drugeventmatrix', 'reporter', 'history']
        chunks = chunk_xml(xml_data, max_chunk_size, target_tags)

        # Write chunks to XML files
        write_chunks_to_files(chunks)

        # Fetch and print the content of each output XML file
        # The code snippet is iterating over each chunk of XML data and printing the content of each output
        # XML file.

        generated_text_list = []
        for i, chunk in enumerate(chunks):
            file_path = f'./app/data/chunked_xml/output_chunk_{i + 1}.xml'
            xml_content = read_xml_file(file_path)
            if not xml_content.startswith("XML file not found"):
                # print(xml_content)
                pass
            else:
                # print(xml_content)
                pass


            # prompt= """you are a service similar to Amazon Comprehend Medical that uses machine learning to extract medical information from unstructured text, such as physician notes, discharge summaries, test results, and case notes and I want you to extract following medical entities from given medical narratives
            # medical Entities to be extracted: reporter, patient, drug, dosage information, test , history, events
            # Extract all these diseases, drugs, medicines, patients name, past drug, present drug, diahhrea in json format
            # please extract the medical entities for the below medical narrative and give the output as json same as amazon comprehend medical.
            # Medical Narrative: """ + xml_content

            prompt = """
            [INST] <> 
            you are a service similar to Amazon Comprehend Medical that uses machine learning to extract medical information from unstructured text, such as physician notes, discharge summaries, test results, and case notes. 
            <>
            [SYSTEM PROMPT] <>
            I want you to extract following medical entities from given medical narratives
            medical Entities to be extracted: reporter, patient, drug, dosage information, test , history, events
            Extract all these diseases, drugs, medicines, patients name, past drug, present drug, diahhrea in json format
            please extract the medical entities for the below medical narrative and give the output as json same as amazon comprehend medical.
            <>

            [QUESTION] <>
            {xml_content}
            <>
    """.format(xml_content = xml_content)

            print(prompt)

            endpoint_name="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"

            # payload = {
            #     "inputs": [[
            #         {"role": "user", "content": prompt},
            #     ]],
            #     "parameters": {"max_new_tokens": 4000,  "top_p": 0.7, "temperature": 0.2}
            # }
            # query_response = query_endpoint_with_json_payload(
            #     json.dumps(payload).encode("utf-8"), endpoint_name=endpoint_name
            # )
            # generated_texts = parse_response_multiple_texts(query_response)
            generated_texts = use_llm_with_aws_bedrock(prompt=prompt)
            generated_text_list.append(generated_texts)
        print(generated_text_list)
        return generated_text_list
    except Exception as e:
        return repr(e)

if(__name__=='__main__'):
    #load env variables
    load_dotenv()
    extract_from_xml(file_path='/app/app/data/raw_xml/xml_data.xml')