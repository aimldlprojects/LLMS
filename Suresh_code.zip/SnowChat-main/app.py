import os
import io

import pandas as pd
import streamlit as st
import snowflake.connector

from gpt import OpenAIService


st.set_page_config(layout="wide")


with st.sidebar:
    st.caption("Snowflake Credentials")
    os.environ["SNOWFLAKE_USER"] = st.text_input("User", value="SAMARNATH")
    os.environ["SNOWFLAKE_PASSWORD"] = st.text_input("Password", value="Riemann123#root")
    os.environ["SNOWFLAKE_ACCOUNT"] = st.text_input("Account", value="randomtreespartner.east-us-2.azure")
    os.environ["SNOWFLAKE_WAREHOUSE"] = st.text_input("Warehouse", value="DEMO_WH")
    os.environ["SNOWFLAKE_SCHEMA"] = st.text_input("Schema", value="DATASETS")
    os.environ["SNOWFLAKE_DATABASE"] = st.text_input("Database", value="RUNML")

    st.write("---")
    api_key = st.text_input("OpenAI API Key", type="password")
    if api_key:
        os.environ["OPENAI_API_KEY"] = api_key
    else:
        st.info("Please enter OpenAI API Key")
        st.stop()


creds = {
    "user": os.environ["SNOWFLAKE_USER"],
    "password": os.environ["SNOWFLAKE_PASSWORD"],
    "account": os.environ["SNOWFLAKE_ACCOUNT"],
    "warehouse": os.environ["SNOWFLAKE_WAREHOUSE"],
    "schema": os.environ["SNOWFLAKE_SCHEMA"],
    "database": os.environ["SNOWFLAKE_DATABASE"]
}


@st.cache_resource
class SnowflakeDB:
    def __init__(self) -> None:
        self.conn = snowflake.connector.connect(
            account=os.environ["SNOWFLAKE_ACCOUNT"],
            user=os.environ["SNOWFLAKE_USER"],
            password=os.environ["SNOWFLAKE_PASSWORD"],
            database=os.environ["SNOWFLAKE_DATABASE"],
            schema=os.environ["SNOWFLAKE_SCHEMA"],
            warehouse=os.environ["SNOWFLAKE_WAREHOUSE"]
        )
        self.cursor = self.conn.cursor()


def read_prompt_file(fname):
    with open(fname, "r") as f:
        return f.read()


@st.cache_data
def query(_conn, query):
    try:
        return pd.read_sql(query, _conn)
    except Exception as e:
        st.warning("Error in query")
        st.error(e)


@st.cache_data
def ask(prompt):
    response = gpt.prompt(prompt)
    return response["choices"][0]["message"]["content"]


def get_tables_schema(_conn):
    with st.expander("View tables schema in database"):
        table_schemas = ""
        df = query(_conn, "show tables")
        print('dataframe:', df)
        st.write(df)
        for table in df["name"]:
            t = f"{DATABASE_NAME}.{SCHEMA_NAME}.{table}"
            df_result = query(sf.conn, f"select * from {t} limit 10;")
            ddl_query = f"select get_ddl('table', '{t}');"
            ddl = query(sf.conn, ddl_query)

            if ddl is not None and not ddl.empty:  # Check if ddl is not None and not empty
                print(ddl)
                schema = f"\n{ddl.iloc[0, 0]}\n"
                st.write(f"### {table}")
                st.markdown(f"```sql{schema}```")
                st.write("---")

                table_schemas = table_schemas + f"\n{table}\n"
                table_schemas = table_schemas + f"{schema}\n"
            else:
                print(f"No DDL found for table {table}")  # Print a message indicating no DDL found

    return table_schemas

def df_schema(df):
    # -- data schema

    sio = io.StringIO()
    df.info(buf=sio)
    df_info = sio.getvalue()
    return df_info


if __name__ == "__main__":
    st.title("Sample Bot")
    msg = "Connect to your Snowflake database and ask questions about your data and get answers in real-time Powered by `Streamlit` and `Open AI."
    st.write(msg)

    gpt = OpenAIService()
    sf = SnowflakeDB()
    print('sf',sf)

    SCHEMA_NAME = os.environ["SNOWFLAKE_SCHEMA"]
    DATABASE_NAME = os.environ["SNOWFLAKE_DATABASE"]
    WAREHOUSE_NAME = os.environ["SNOWFLAKE_WAREHOUSE"]

    # -- get tables DDL in schema
    table_schemas = get_tables_schema(sf.conn)


    st.write("---")

    # -- ask SQL question
    question = st.text_area(
        "Ask a question about the database data",
        placeholder="What is the total revenue?",
    )
    if question:
        # -- curate prompt
        prompt = read_prompt_file("sql_prompt.txt")
        prompt = prompt.replace("<<TABLES>>", table_schemas)
        prompt = prompt.replace("<<QUESTION>>", question)
        answer = ask(prompt)
        st.code(answer)
    else:
        st.stop()

    # -- parse response
    # if st.checkbox("Run", key="answer") and answer:
    df = query(sf.conn, answer)
    st.dataframe(df, use_container_width=True)

