import snowflake.connector

# Snowflake connection parameters
account = "randomtreespartner.east-us-2"
username = "SAMARNATH"
password = "Riemann123#root"
database = "RUNML"
schema = "DATASETS"
role = "RT_DEV_ROLE"
warehouse = "RT_DEV_WH"

try:
    # Establish connection
    conn = snowflake.connector.connect(
        account=account,
        user=username,
        password=password,
        database=database,
        schema=schema,
        role=role,
        warehouse=warehouse
    )

    # Create cursor
    cursor = conn.cursor()

    # Execute a sample query
    cursor.execute("SELECT count(*) FROM CA_HOUSING")

    # Fetch results
    rows = cursor.fetchall()

    # Process fetched data
    for row in rows:
        print(row)

    # Close cursor and connection
    cursor.close()
    conn.close()

except Exception as e:
    print("Error:", e)
