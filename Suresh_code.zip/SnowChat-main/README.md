# SnowChat

[![Open in Streamlit][share_badge]][share_link]

Connect to your Snowflake database to ask questions (in natural langauge) about your data, and get answers in real-time with visualization supported. Built with `Streamlit` and powered by `GPT-4`.


[share_badge]: https://static.streamlit.io/badges/streamlit_badge_black_white.svg
[share_link]: https://iamaziz-snowchat-app-optz30.streamlit.app




https://user-images.githubusercontent.com/3298308/236600071-57f7f49b-42ab-48b1-87e7-702bb10c0bdf.mov
